package com.thona.appthona.Ubicacion

import android.Manifest.permission.ACCESS_FINE_LOCATION
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.widget.Toast
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.core.app.ActivityCompat
import androidx.core.app.ActivityCompat.requestPermissions
import androidx.core.app.ActivityCompat.shouldShowRequestPermissionRationale
import androidx.core.content.ContextCompat
import com.google.android.gms.location.*
import com.thona.appthona.Funciones.funciones
import com.thona.appthona.ui.Plantillas.AlertaDialogo
import com.thona.appthona.ui.theme.Institucional1

private lateinit var fusedLocationClient: FusedLocationProviderClient

@Composable
fun permisoUbi(
    funciones: funciones,
    contexto: Context,
    actividad: Activity,
    clicMensaje: (opcion: Int) -> Unit,
): Boolean{
    fusedLocationClient = LocationServices.getFusedLocationProviderClient(actividad)
    var permiso = false
    val tieneDatos = remember { mutableStateOf(true)  }

    println("UBI UBICACION: ${PackageManager.PERMISSION_GRANTED} -- PERMISO SOLICITADO: ${ContextCompat.checkSelfPermission(contexto,
        ACCESS_FINE_LOCATION)}")
    when {
        ContextCompat.checkSelfPermission(
            contexto,
            ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED -> {
            println("Permiso concedido")
            permiso = true
            fusedLocationClient.lastLocation
                .addOnSuccessListener { location : Location? ->
                    funciones::datosUbicacion.invoke(location)
                    funciones::obtieneIP.invoke()
                    tieneDatos.value = location?.latitude != null
                }
            if(!tieneDatos.value){
                AlertaDialogo(
                    titulo = "Habilita tu ubicación",
                    mensaje = "Para poder continuar, es necesario tener activo el servicio de ubicación.",
                    clicAceptar = { clicMensaje(2) },
                    clicCancelar = { /*TODO*/ },
                    colorRol = Institucional1,
                    cantidadBotones = 1
                )
            }
        }
        shouldShowRequestPermissionRationale(actividad,ACCESS_FINE_LOCATION) -> {
            println("PERMISOS UBI UBICACION: NO SE DIO EL PERMISO")
            AlertaDialogo(
                titulo = "Concede permisos",
                mensaje = "Debes otorgar acceso a tu ubicación para iniciar sesión.",
                clicAceptar =  {clicMensaje(1)},
                clicCancelar = { clicMensaje(2) },
                colorRol = Institucional1,
                cantidadBotones = 2
            )
            pidePermiso(actividad)
        }
        else -> {
            println("PERMISOS UBI UBICACION: PASO A UN ULTIMO ELSE")
            //pidePermiso(actividad)
            checkPermission(actividad,ACCESS_FINE_LOCATION,1, clicMensaje)
        }
    }
    return permiso
}

fun pidePermiso(
    actividad: Activity
){
    println("PIDE PERMISOS UBI UBICACION: TE VA A PEDIR EL PERMISO ${actividad.title}")
    requestPermissions(
        actividad,
        arrayOf(
            ACCESS_FINE_LOCATION
        ),
        1
    )
}

@Composable
fun checkPermission(actividad: Activity, permission: String, requestCode: Int, clicMensaje: (opcion: Int) -> Unit) {
    if (ContextCompat.checkSelfPermission(actividad, permission) == PackageManager.PERMISSION_DENIED) {
        // Requesting the permission
        ActivityCompat.requestPermissions(actividad, arrayOf(permission), requestCode)
        AlertaDialogo(
            titulo = "Concede permisos",
            mensaje = "Debes otorgar acceso a tu ubicación para iniciar sesión.",
            clicAceptar =  {clicMensaje(1)},
            clicCancelar = { clicMensaje(2) },
            colorRol = Institucional1,
            cantidadBotones = 2
        )
    } else {
        Toast.makeText(actividad, "Permiso $permission ya se habia aceptado", Toast.LENGTH_SHORT).show()
    }
}