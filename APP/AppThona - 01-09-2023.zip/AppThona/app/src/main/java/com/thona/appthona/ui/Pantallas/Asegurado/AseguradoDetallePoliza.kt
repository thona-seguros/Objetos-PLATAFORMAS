package com.thona.appthona.ui.Pantallas.Asegurado

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import android.widget.Toast
import androidx.activity.compose.ManagedActivityResultLauncher
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AssignmentInd
import androidx.compose.material.icons.outlined.AttachEmail
import androidx.compose.material.icons.outlined.FactCheck
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment.Companion.CenterHorizontally
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.thona.appthona.Data.WebServices.Modelos.DetalleProducto
import com.thona.appthona.Data.WebServices.Modelos.InfoItem
import com.thona.appthona.Funciones.funciones
import com.thona.appthona.ui.Plantillas.AlertaDialogo
import com.thona.appthona.ui.Plantillas.MenuColapsable.ExpandableListViewModel
import com.thona.appthona.ui.Plantillas.MenuColapsable.ListadoMenu
import com.thona.appthona.ui.theme.Institucional3

@Composable
fun DetallePolizas(
    clicKEdicion: () -> Unit,
    usuario: InfoItem,
    detallePoliza: DetalleProducto,
    clickDescargaPoliza: (link: String, titulo: String, contexto: Context) -> Unit,
    clickDescargaCG: (link: String, titulo: String, contexto: Context) -> Unit,
    clickEnviaPorCorreo: () -> Unit,
    mensaje: String,
    muestraMensaje: Boolean,
    funciones: funciones
){
    var clickBoton by rememberSaveable { mutableIntStateOf(0) }
    Column(){
        Row (modifier = Modifier.offset(7.dp)) {
            Text(
                text = "Póliza ${detallePoliza.detalleProducto.idPoliza}",
                fontWeight = FontWeight.Bold
            )
        }
        Row (modifier = Modifier.offset(7.dp)) {
            Text(
                text = "Estatus: ${detallePoliza.detalleProducto.status}",
                fontWeight = FontWeight.Bold
            )
        }
        Row (modifier = Modifier.offset(7.dp),) {
            Text(
                text = "Periodicidad: ${detallePoliza.detalleProducto.codigoPlanPago}",
                fontWeight = FontWeight.Bold
            )
        }
        Row (modifier = Modifier.offset(7.dp),) {
            Text(
                text = "Vigencia: ${detallePoliza.detalleProducto.vicenciaInicial} - ${detallePoliza.detalleProducto.vigenciaFinal}",
                fontWeight = FontWeight.Normal
            )
        }
        Row (modifier = Modifier
            .offset(7.dp)
            .padding(5.dp),) {
            Text(
                text = detallePoliza.detalleProducto.descripcionSeguro,
                fontWeight = FontWeight.Light,
                fontSize = 15.sp
            )
        }
        Column() {
            Spacer(modifier = Modifier.height(15.dp))
            Divider(color = Institucional3, thickness = 1.dp)
            Column() {
                ListadoMenu(
                    clicKEdicion = clicKEdicion,
                    viewModel = ExpandableListViewModel(),
                    datos = detallePoliza
                )
            }
            Divider(color = Institucional3, thickness = 1.dp)
        }
        Spacer(modifier = Modifier.height(20.dp))
        val mContext = LocalContext.current
        Row (modifier = Modifier
            .fillMaxWidth(), horizontalArrangement = Arrangement.Center){
            Column(horizontalAlignment = CenterHorizontally) {
                OutlinedButton(
                    onClick = {
                         clickBoton = 1
                    },
                    modifier= Modifier.size(60.dp),
                    shape = CircleShape,
                    border= BorderStroke(width = 5.dp, color = Institucional3),
                    contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor =  Institucional3)
                ) {
                    Icon(imageVector = Icons.Outlined.AssignmentInd ,contentDescription = "", tint= Institucional3)
                }
                Spacer(modifier = Modifier.height(5.dp))
                Text(
                    text = "Descargar Póliza",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.width(15.dp))
            Column (horizontalAlignment = CenterHorizontally){
                OutlinedButton(
                    onClick = {
                        clickBoton = 2
                    },
                    modifier= Modifier.size(60.dp),
                    shape = CircleShape,
                    border= BorderStroke(width = 5.dp, color = Institucional3),
                    contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor =  Institucional3)
                ) {
                    Icon(imageVector = Icons.Outlined.FactCheck ,contentDescription = "", tint= Institucional3)
                }
                Spacer(modifier = Modifier.height(5.dp))
                Text(
                    text = "Descargar C.G.",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.width(15.dp))
            Column (horizontalAlignment = CenterHorizontally){
                OutlinedButton(
                    onClick = {
                        clickBoton = 3
                    },
                    modifier= Modifier.size(60.dp),
                    shape = CircleShape,
                    border= BorderStroke(width = 5.dp, color = Institucional3),
                    contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor =  Institucional3)
                ) {
                    Icon(imageVector = Icons.Outlined.AttachEmail ,contentDescription = "", tint= Institucional3)
                }
                Spacer(modifier = Modifier.height(5.dp))
                Text(
                    text = "Enviar Email",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            val requestPermissionLauncher =
                rememberLauncherForActivityResult(
                    ActivityResultContracts.RequestPermission()
                ){ isGranted: Boolean ->
                    if(isGranted){
                        Log.i("Permission: ", "Granted")
                        println("PERMISOS: sI TIENE PERMISOS")
                    }
                    else {
                        Log.i("Permission: ", "Denied")
                        println("PERMISOS: NO TIENE PERMISOS")
                    }
                }
            if(clickBoton != 0){
                when(clickBoton){
                    1->{
                        AlertaDialogo(
                            titulo = "Descargar póliza",
                            mensaje = "¿Deseas descargar la póliza ${detallePoliza.detalleProducto.idPoliza}?",
                            clicAceptar = { Toast.makeText(
                                    mContext,
                                    "Icono para descargar poliza",
                                    Toast.LENGTH_SHORT
                                    ).show(); clickBoton = 0; if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q){
                                if(ContextCompat.checkSelfPermission(mContext, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED){
                                    clickDescargaPoliza("https://thona01.azurewebsites.net/temp/701Poliza.pdf","Poliza",mContext)
                                    Toast.makeText(
                                        mContext,
                                        "La poliza se descargara",
                                        Toast.LENGTH_SHORT).show()
                                } else if(ContextCompat.checkSelfPermission(mContext, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED){
                                    requestPermissionLauncher.launch(
                                        Manifest.permission.WRITE_EXTERNAL_STORAGE
                                    )
                                }
                            } else{
                                clickDescargaPoliza("https://thona01.azurewebsites.net/temp/701Poliza.pdf","Poliza",mContext)
                                Toast.makeText(
                                    mContext,
                                    "La poliza se descargara2",
                                    Toast.LENGTH_SHORT).show()
                            }
                            },
                            clicCancelar = { clickBoton = 0 },
                            colorRol = Institucional3,
                            cantidadBotones = 2
                        )
                    }
                    2->{
                        AlertaDialogo(
                            titulo = "Descargar condiciones generales",
                            mensaje = "¿Deseas descargar las condiciones generales de la póliza ${detallePoliza.detalleProducto.idPoliza}?",
                            clicAceptar = { Toast.makeText(
                                mContext,
                                "Icono para descargar Condiciones Generales",
                                Toast.LENGTH_SHORT
                            ).show(); clickBoton = 0; clickDescargaCG("https://thona01.azurewebsites.net/temp/VI2019Condiciones_Generales.pdf", "Condiciones Generales", mContext) },
                            clicCancelar = { clickBoton = 0 },
                            colorRol = Institucional3,
                            cantidadBotones = 2
                        )
                    }
                    3->{
                        AlertaDialogo(
                            titulo = "Enviar documentación",
                            mensaje = "Se enviará al mail ${usuario.emailUsuario.first().email} los documentos de la póliza ${detallePoliza.detalleProducto.idPoliza}",
                            clicAceptar = { Toast.makeText(
                                mContext,
                                "Icono para enviar póliza y C.G por correo",
                                Toast.LENGTH_SHORT
                            ).show(); clickBoton = 0; clickEnviaPorCorreo() },
                            clicCancelar = { clickBoton = 0 },
                            colorRol = Institucional3,
                            cantidadBotones = 2
                        )
                    }
                }
                println("MUESTRA MENSAJE: $muestraMensaje")
                if(muestraMensaje){
                    AlertaDialogo(
                        titulo = "Se ha enviado la póliza por correo",
                        mensaje = mensaje,
                        clicAceptar = { Toast.makeText(
                            mContext,
                            "Envio de correo exitoso",
                            Toast.LENGTH_SHORT
                        ).show(); funciones.muestraMensaje.value = false },
                        clicCancelar = {  },
                        colorRol = Institucional3,
                        cantidadBotones = 1
                    )
                }
            }
        }
    }
}