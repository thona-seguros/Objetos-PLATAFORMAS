package com.thona.appthona.ui.Pantallas

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Cancel
import androidx.compose.material.icons.outlined.DeleteForever
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconToggleButton
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.thona.appthona.Constantes.Institucional3
import com.thona.appthona.Constantes.ThonaRojo
import com.thona.appthona.Constantes.ThonaVerde
import com.thona.appthona.Data.WebServices.Modelos.DetalleProducto
import com.thona.appthona.Data.WebServices.Modelos.ParentescoItem
import com.thona.appthona.ui.Plantillas.MenuColapsable.ExpandableListViewModel
import com.thona.appthona.ui.Plantillas.cajaTextoBeneficiarios

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EdicionBeneficiarios(producto: DetalleProducto, viewModel: ExpandableListViewModel, listaParentescos: List<ParentescoItem>){
    val mContext = LocalContext.current
    val scrollState = rememberScrollState()
    val default = 0
    var numBen by remember { mutableIntStateOf(value = producto.detalleBeneficiarios.count()) }
    var num: Int
    val benefIds by viewModel.benefIds.collectAsState()
    Spacer(Modifier.height(25.dp))
    Column(
        modifier = Modifier
            .verticalScroll(scrollState)
            .fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ){
        producto.detalleBeneficiarios.forEach{beneficiario ->
            println("BENEFICIARIO A AGREGAR: $beneficiario")
            viewModel.agregaBeneficiario(beneficiario)
        }
        benefIds.forEach{ beneficiario ->
            var expanded by remember { mutableStateOf(false) }
            //var selectedType by remember { mutableStateOf( listaParentescos[default].parentesco) }
            var selectedType by remember { mutableStateOf( beneficiario.parentescoBeneficiario) }
            Column {
                OutlinedCard(
                    modifier = Modifier.padding(5.dp),
                    shape = CardDefaults.outlinedShape,
                    colors = CardDefaults.outlinedCardColors(containerColor = Color.Transparent),
                    elevation = CardDefaults.outlinedCardElevation()
                ){
                    var cheked by remember { mutableStateOf(false) }
                    var eliminar by remember { mutableStateOf(false) }
                    num = producto.detalleBeneficiarios.indexOf(beneficiario)+1
                    Box(modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp)){
                        Column(modifier = Modifier.fillMaxSize()){
                            Box(modifier = Modifier.fillMaxWidth()){
                                Row(modifier = Modifier
                                    .align(Alignment.CenterStart)
                                    .padding(end = 80.dp),verticalAlignment = Alignment.CenterVertically){
                                    if(!cheked) Text(text = beneficiario.nombreBeneficiario)
                                    else Text(text = "Beneficiario $num")
                                }
                                Row(modifier = Modifier.align(Alignment.CenterEnd),verticalAlignment = Alignment.CenterVertically){
                                    IconToggleButton(
                                        checked = cheked,
                                        onCheckedChange = { _cheked ->
                                            cheked = _cheked
                                        }
                                    ) {
                                        Icon(
                                            imageVector = Icons.Outlined.Edit,
                                            contentDescription = "Editar",
                                            tint = if(cheked) ThonaVerde else Color.LightGray
                                        )
                                    }
                                    IconToggleButton(
                                        checked = eliminar,
                                        enabled = cheked,
                                        onCheckedChange = { _eliminar ->
                                            eliminar = _eliminar
                                        }
                                    ) {
                                        Icon(
                                            imageVector = Icons.Outlined.DeleteForever,
                                            contentDescription = "Borrar",
                                            tint = if(cheked) ThonaRojo else Color.LightGray
                                        )
                                    }
                                }
                            }
                            if(eliminar){
                                Toast.makeText(
                                    mContext,
                                    "Eliminar beneficiario ${beneficiario.nombreBeneficiario}",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                            if (cheked){
                                Column {
                                    cajaTextoBeneficiarios(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(start = 7.dp, end = 7.dp),
                                        dato = beneficiario.nombreBeneficiario,
                                        etiqueta = "Nombre",
                                        placeholder = "Nombre del beneficiario",
                                        editable = true,
                                        tipoTeclado = KeyboardType.Text
                                    )
                                    Spacer(modifier = Modifier.height(3.dp))
                                    Row(modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(start = 7.dp, end = 7.dp),horizontalArrangement = Arrangement.Center) {
                                        ExposedDropdownMenuBox(
                                            expanded = expanded,
                                            onExpandedChange = { expanded = !expanded },
                                            modifier = Modifier.width(200.dp)
                                        ) {
                                            TextField(
                                                readOnly = true,
                                                value = selectedType,
                                                onValueChange = {  },
                                                label = { Text("Parentesco") },
                                                trailingIcon = {
                                                    ExposedDropdownMenuDefaults.TrailingIcon(
                                                        expanded = expanded
                                                    )
                                                },
                                                colors = ExposedDropdownMenuDefaults.textFieldColors(),
                                                modifier = Modifier.menuAnchor()
                                            )
                                            ExposedDropdownMenu(
                                                expanded = expanded,
                                                onDismissRequest = {
                                                    expanded = false
                                                }
                                            ) {
                                                listaParentescos.forEach{ selectionOption ->
                                                    DropdownMenuItem(
                                                        text = { Text(text = selectionOption.parentesco) },
                                                        onClick = {
                                                            selectedType = selectionOption.parentesco
                                                            expanded = false
                                                        },
                                                        contentPadding = ExposedDropdownMenuDefaults.ItemContentPadding
                                                    )
                                                }
                                            }
                                        }
                                        Spacer(modifier = Modifier.width(6.dp))
                                        cajaTextoBeneficiarios(
                                            modifier = Modifier
                                                .width(100.dp)
                                                .height(60.dp),
                                            dato = beneficiario.porcentajeBeneficiario.toString(),
                                            etiqueta = "Porcentaje",
                                            placeholder = "100",
                                            editable = true,
                                            tipoTeclado = KeyboardType.Number
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(5.dp))
                                }
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
            }
        }
        var agrega by remember { mutableStateOf(value = false) }

        if(agrega){
            EspacioBeneficiario(
                num = numBen,
                listaParentescos = listaParentescos
            )
        }
        Spacer(Modifier.height(10.dp))
        Text(text = "Conteo: $numBen")
        Spacer(Modifier.height(10.dp))
        if(numBen<5){
            Button(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 10.dp, end = 10.dp),
                onClick = {
                    Toast.makeText(
                        mContext,
                        "Agrega beneficiario ${numBen+1}",
                        Toast.LENGTH_SHORT
                    ).show(); numBen++; agrega=true
                },
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Institucional3
                ),
                enabled = true
            ) {
                Text(
                    text = "Agregar beneficiario",
                    color = Color.White
                )
                Spacer(Modifier.size(ButtonDefaults.IconSpacing))
                Icon(
                    imageVector = Icons.Outlined.Add,
                    contentDescription = "Agregar",
                    tint = Color.White
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        if(true){
            Row(verticalAlignment = Alignment.CenterVertically){
                Button(
                    onClick = {
                        Toast.makeText(
                            mContext,
                            "Actualización cancelada",
                            Toast.LENGTH_SHORT
                        ).show()
                    },
                    shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Institucional3
                    ),
                    enabled = true
                ) {
                    Text(
                        text = "Cancelar",
                        color = Color.White
                    )
                    Spacer(Modifier.size(ButtonDefaults.IconSpacing))
                    Icon(
                        imageVector = Icons.Outlined.Cancel,
                        contentDescription = "Cancelar",
                        tint = Color.White
                    )
                }
                Spacer(modifier = Modifier.width(20.dp))
                Button(
                    onClick = {
                        Toast.makeText(
                            mContext,
                            "Datos a guardar",
                            Toast.LENGTH_SHORT
                        ).show()
                    },
                    shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Institucional3
                    ),
                    enabled = true
                ) {
                    Text(
                        text = "Guardar",
                        color = Color.White
                    )
                    Spacer(Modifier.size(ButtonDefaults.IconSpacing))
                    Icon(
                        imageVector = Icons.Outlined.Save,
                        contentDescription = "Guardar",
                        tint = Color.White
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EspacioBeneficiario(num: Int, listaParentescos: List<ParentescoItem>){

    var expanded by remember { mutableStateOf(false) }
    var selectedType by remember { mutableStateOf(listaParentescos[0].parentesco) }

    Column {
        OutlinedCard(
            modifier = Modifier.padding(5.dp),
            shape = CardDefaults.outlinedShape,
            colors = CardDefaults.outlinedCardColors(containerColor = Color.Transparent),
            elevation = CardDefaults.outlinedCardElevation()
        ){
            var cheked by remember { mutableStateOf(false) }
            var eliminar by remember { mutableStateOf(false) }

            Box(modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp)){
                Column(modifier = Modifier.fillMaxSize()){
                    Box(modifier = Modifier.fillMaxWidth()){
                        Row(modifier = Modifier
                            .align(Alignment.CenterStart)
                            .padding(end = 80.dp),verticalAlignment = Alignment.CenterVertically){
                            if(!cheked) Text(text = "")
                            else Text(text = "Beneficiario $num")
                        }
                        Row(modifier = Modifier.align(Alignment.CenterEnd),verticalAlignment = Alignment.CenterVertically){
                            IconToggleButton(
                                checked = cheked,
                                onCheckedChange = { _cheked ->
                                    cheked = _cheked
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.Edit,
                                    contentDescription = "Editar",
                                    tint = if(cheked) ThonaVerde else Color.LightGray
                                )
                            }
                            IconToggleButton(
                                checked = eliminar,
                                enabled = cheked,
                                onCheckedChange = { _eliminar ->
                                    eliminar = _eliminar
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.DeleteForever,
                                    contentDescription = "Borrar",
                                    tint = if(cheked) ThonaRojo else Color.LightGray
                                )
                            }
                        }
                    }
                    if (cheked){
                        Column {
                            cajaTextoBeneficiarios(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(start = 7.dp, end = 7.dp),
                                dato = "",
                                etiqueta = "Nombre",
                                placeholder = "Nombre del beneficiario",
                                editable = true,
                                tipoTeclado = KeyboardType.Text
                            )
                            Spacer(modifier = Modifier.height(3.dp))
                            Row(modifier = Modifier
                                .fillMaxWidth()
                                .padding(start = 7.dp, end = 7.dp),horizontalArrangement = Arrangement.Center) {
                                ExposedDropdownMenuBox(
                                    expanded = expanded,
                                    onExpandedChange = { expanded = !expanded },
                                    modifier = Modifier.width(200.dp)
                                ) {
                                    TextField(
                                        readOnly = true,
                                        value = selectedType,
                                        onValueChange = { },
                                        label = { Text("Parentesco") },
                                        trailingIcon = {
                                            ExposedDropdownMenuDefaults.TrailingIcon(
                                                expanded = expanded
                                            )
                                        },
                                        colors = ExposedDropdownMenuDefaults.textFieldColors(),
                                        modifier = Modifier.menuAnchor()
                                    )
                                    ExposedDropdownMenu(
                                        expanded = expanded,
                                        onDismissRequest = {
                                            expanded = false
                                        }
                                    ) {
                                        listaParentescos.forEach{ selectionOption ->
                                            DropdownMenuItem(
                                                text = { Text(text = selectionOption.parentesco) },
                                                onClick = {
                                                    selectedType = selectionOption.parentesco
                                                    expanded = false
                                                },
                                                contentPadding = ExposedDropdownMenuDefaults.ItemContentPadding
                                            )
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                cajaTextoBeneficiarios(
                                    modifier = Modifier
                                        .width(100.dp)
                                        .height(60.dp),
                                    dato = "100",
                                    etiqueta = "Porcentaje",
                                    placeholder = "100",
                                    editable = true,
                                    tipoTeclado = KeyboardType.Number
                                )
                            }
                            Spacer(modifier = Modifier.height(5.dp))
                        }
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(10.dp))
    }
}
