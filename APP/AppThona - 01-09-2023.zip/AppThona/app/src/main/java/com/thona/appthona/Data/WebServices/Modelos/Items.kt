package com.thona.appthona.Data.WebServices.Modelos

import com.google.gson.annotations.SerializedName

data class SesionItem(
    @SerializedName("idSession") val idSession: Int
)

data class idUnicoItem (
    @SerializedName("codAsegurado") val codAsegurado: String
)

data class LoginItem (
    @SerializedName("Usuario") val CodUsuario: String?,
    @SerializedName("Rol") val Rol: String?,
    @SerializedName("Nombre") val NomUsuario: String?,
    @SerializedName("ApellidoPaterno") val ApPatUsuario: String?
)

data class InfoItem (
    @SerializedName("NombreUser") val nombreUsuario: String?,
    @SerializedName("SexoUser") val sexoUsuario: String?,
    @SerializedName("NacimUser") val fechaNacimiento: String?,
    @SerializedName("DirecUser") val direccionUsuario: String?,
    @SerializedName("RFCUser") val rfcUsuario: String?,
    @SerializedName("CelUser") val celUsuario: List<telsItem>,
    @SerializedName("EmailUser") val emailUsuario: List<emailsItem>,
    @SerializedName("CURPUser") val curpUsuario: String?,
    @SerializedName("nPolizas") val cantidadPolizas: Int
)

data class emailsItem(
    @SerializedName("email") val email: String,
    @SerializedName("principal") val esPrincipal: String,
    @SerializedName("correlativo") val correlativo: Int
)

data class telsItem(
    @SerializedName("telefono") val tel: Long,
    @SerializedName("principal") val esPrincipal: String,
    @SerializedName("correlativo") val correlativo: Int
)

data class MyProdcutoItem (
    @SerializedName("IdPoliza") val idPoliza: String?,
    @SerializedName("FecVigencia") val fechaVigencia: String?,
    @SerializedName("IdTipoSeg") val idTipoSeguro: String?,
    @SerializedName("DescSeg") val descTipoSeguro: String?,
    @SerializedName("Status") val statusPoliza: String?
)

data class DetalleProductoItem (
    @SerializedName("IdPoliza") val idPoliza: String,
    @SerializedName("IdAsegurado") val idAsegurado: String,
    @SerializedName("IdTipoSeg") val idTipoSeguro: String,
    @SerializedName("VigenciaIni") val vicenciaInicial: String,
    @SerializedName("VigenciaFin") val vigenciaFinal: String,
    @SerializedName("FecRenovacion") val fechaRenovacion: String,
    @SerializedName("Status") val status: String,
    @SerializedName("DescSeg") val descripcionSeguro: String,
    @SerializedName("CodPlanPago") val codigoPlanPago: String,
    @SerializedName("SumaAseg") val sumaAsegurada: String,
    @SerializedName("CodCobertura") val codigoCobertura: String
)

data class DetalleMenuItem (
    @SerializedName("Titulo") val tituloMenu: String,
    @SerializedName("Estatus") val estatusMenu: Int
)

data class DetalleCoberturaItem (
    @SerializedName("codCobert") val codigoCobertura: String,
    @SerializedName("sumAsegurada") val sumaAsegurada: String,
    @SerializedName("descCobertura") val descripcionCobertura: String
)

data class DetalleBeneficiarioItem(
    @SerializedName("nombenef") val nombreBeneficiario: String,
    @SerializedName("porcentaje") val porcentajeBeneficiario: Int,
    @SerializedName("parentesco") val parentescoBeneficiario: String
)

data class facturaItem(
    @SerializedName("IdFactura") val idFactura: Int,
    @SerializedName("StsFactura") val statusFactura: String,
    @SerializedName("FechaFact") val fechaFactura: String,
    @SerializedName("MontoFactura") val montoFactura: Double,
    @SerializedName("IdRecibo") val idRecibo: String,
    @SerializedName("CuotaFact") val cuotaFactura: String,
    @SerializedName("IdTransaccion") val idTransaccion: Int,
    @SerializedName("vl_PlanPagoFact") val vl_PlanPagoFact: String
)

data class ParentescoItem(
    @SerializedName("codValor") val codParentesco: String,
    @SerializedName("descValor") val parentesco: String
)