package com.thona.appthona.Data.WebServices.Servicios

import com.thona.appthona.Data.WebServices.Modelos.ModeloCambioPassword
import com.thona.appthona.Data.WebServices.Modelos.ModeloCatalogoParentescos
import com.thona.appthona.Data.WebServices.Modelos.ModeloCierreSesion
import com.thona.appthona.Data.WebServices.Modelos.ModeloDetalleProducto
import com.thona.appthona.Data.WebServices.Modelos.ModeloLogin
import com.thona.appthona.Data.WebServices.Modelos.ModeloMyInformacion
import com.thona.appthona.Data.WebServices.Modelos.ModeloMyProducto
import com.thona.appthona.Data.WebServices.Modelos.ModeloObteieneIP
import com.thona.appthona.Data.WebServices.Modelos.ModeloPrueba
import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query
import retrofit2.http.Url

interface Metodos {
    @POST("login")
    suspend fun Login(@Body body: RequestBody): Response<ModeloLogin>

    @POST("cambioPassword")
    suspend fun CambioPassword(@Body body: RequestBody): Response<ModeloCambioPassword>

    @POST("cierreSesion")
    suspend fun CierreSesion(@Body body: RequestBody): Response<ModeloCierreSesion>

    @POST("MyInfo")
    suspend fun ConsultaInfo(@Body body: RequestBody): Response<ModeloMyInformacion>

    @POST("MyProduct")
    suspend fun ConsultaProductos(@Body body: RequestBody): Response<ModeloMyProducto>

    /*@GET("DetProducts")
    suspend fun DetalleProducto (@Query("Usuario") USUARIO: String, @Query("idPoliza") idPoliza: String, @Query("Session") idSession: Int): Response<ModeloDetalleProducto>*/
    @POST("DetProducts")
    suspend fun DetalleProducto(@Body body: RequestBody): Response<ModeloDetalleProducto>

    @POST("UpdMyInfo")
    suspend fun actualizaInfo(@Body body: RequestBody): Response<ModeloCambioPassword>

    @GET("catParentesco")
    suspend fun CatalogoParentescos(): Response<ModeloCatalogoParentescos>

    @GET
    suspend fun obtieneIP(@Url url: String): Response<ModeloObteieneIP>

    @GET("CorreoDocumentos")
    suspend fun Pruebalocal(@Query("idPoliza") idPoliza: String): Response<ModeloPrueba>
}