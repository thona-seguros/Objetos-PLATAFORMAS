package com.thona.appthona.Data.WebServices.Modelos

import com.google.gson.annotations.SerializedName

data class Control (
    @SerializedName("ReturnNumError") val NumeroRespuesta: String,
    @SerializedName("ReturnError") val TextoRespuesta: String,
)