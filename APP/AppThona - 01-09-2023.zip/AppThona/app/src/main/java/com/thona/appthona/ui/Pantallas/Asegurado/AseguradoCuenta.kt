package com.thona.appthona.ui.Pantallas.Asegurado

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Cancel
import androidx.compose.material.icons.outlined.Save
import androidx.compose.material.icons.rounded.AccountCircle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.thona.appthona.Constantes.Institucional1
import com.thona.appthona.Constantes.Institucional2
import com.thona.appthona.Constantes.Institucional3
import com.thona.appthona.Data.WebServices.Modelos.InfoItem
import com.thona.appthona.Data.WebServices.Modelos.Login
import com.thona.appthona.Data.WebServices.Modelos.MyProducto
import com.thona.appthona.ui.Plantillas.cajaTextoEditable

@Composable
fun AseguradoCuenta(
    usuario: Login,
    infoUsuario: InfoItem,
    productos: MyProducto,
    clickActualizacion: (correo: String?, cCorrelativo: Int, telefono: String?, tCorrelativo: Int) -> Unit,
    clickCancelar: () -> Unit
){
    val mContext = LocalContext.current
    val scrollState = rememberScrollState()
    Spacer(modifier = Modifier.height(10.dp))
    Row(
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        //TODO PONER LA IMAGEN DEL USUARIO
        Column{
            Icon(
                imageVector = Icons.Rounded.AccountCircle,
                contentDescription = "",
                modifier = Modifier.size(75.dp),
                tint = Institucional2
            )
        }
        Spacer(modifier = Modifier.width(15.dp))
        Column{
            Row {
                Text(text = "${usuario.Items.NomUsuario} ${usuario.Items.ApPatUsuario}", fontWeight = FontWeight.Bold, fontStyle = FontStyle.Italic)
            }
            Row {
                Text(text = "No. Asegurado: ", fontWeight = FontWeight.Bold)
                Text(text = productos.idAsegurado.codAsegurado)
            }
            Row{
                Text(text = "Pólizas Activas: ", fontWeight = FontWeight.Bold)
                Text(text = "${infoUsuario.cantidadPolizas}")
            }
        }
    }
    Spacer(modifier = Modifier.height(10.dp))
    Column (
        modifier = Modifier
            .verticalScroll(scrollState)
            .fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ){
        var edicion1 by rememberSaveable { mutableStateOf("") }
        var edicion2 by rememberSaveable { mutableStateOf("") }
        var edicion = false
        Row(modifier = Modifier
            .fillMaxWidth()
            .padding(start = 15.dp, end = 15.dp),horizontalArrangement = Arrangement.Center) {
            OutlinedTextField(
                modifier = Modifier
                    .width(160.dp)
                    .height(60.dp),
                value = "${infoUsuario.fechaNacimiento}",
                onValueChange = { },
                placeholder = { Text(text = "dd/mm/aaaa") },
                label = { Text(text = "Fecha de nacimiento") },
                readOnly = true,
                singleLine = true,
                shape = CircleShape,
                //isError = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Institucional2
                )
            )
            /*cajaTextoEditable(
                modifier = Modifier
                    .width(160.dp)
                    .height(60.dp),
                dato = "${infoUsuario.fechaNacimiento}",
                etiqueta = "Fecha de nacimiento",
                placeholder = "dd/mm/aaaa",
                puedeEditar = false,
                tipoTeclado = KeyboardType.Text
            )*/
            cajaTextoEditable(
                modifier = Modifier
                    .width(200.dp)
                    .height(60.dp),
                dato = "${infoUsuario.sexoUsuario}",
                etiqueta = "Sexo",
                placeholder = "H/M",
                puedeEditar = false,
                tipoTeclado = KeyboardType.Text
            )
        }
        Row(modifier = Modifier.fillMaxWidth(),horizontalArrangement = Arrangement.Start) {
            cajaTextoEditable(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 15.dp, end = 15.dp)
                    .height(60.dp),
                dato = "${infoUsuario.rfcUsuario}",
                etiqueta = "RFC",
                placeholder = "",
                puedeEditar = false,
                tipoTeclado = KeyboardType.Text
            )
        }
        Row(modifier = Modifier.fillMaxWidth(),horizontalArrangement = Arrangement.Start) {
            cajaTextoEditable(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 15.dp, end = 15.dp)
                    .height(60.dp),
                dato = "${infoUsuario.curpUsuario}",
                etiqueta = "CURP",
                placeholder = "",
                puedeEditar = false,
                tipoTeclado = KeyboardType.Text
            )
        }
        Row(modifier = Modifier.fillMaxWidth(),horizontalArrangement = Arrangement.Start) {
            cajaTextoEditable(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 15.dp, end = 15.dp),
                dato = "${infoUsuario.direccionUsuario}",
                etiqueta = "Dirección",
                placeholder = "Dirección completa",
                puedeEditar = false,
                tipoTeclado = KeyboardType.Text
            )
        }
        Row(modifier = Modifier.fillMaxWidth(),horizontalArrangement = Arrangement.Start) {
            edicion1 = cajaTextoEditable(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 15.dp, end = 15.dp)
                    .height(60.dp),
                dato = infoUsuario.emailUsuario.first().email,
                etiqueta = "Email*",
                placeholder = "correo@thonaseguros.mx",
                puedeEditar = true,
                tipoTeclado = KeyboardType.Email
            )
        }
        Row(modifier = Modifier.fillMaxWidth(),horizontalArrangement = Arrangement.Start, verticalAlignment = Alignment.CenterVertically){
            edicion2 = cajaTextoEditable(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 15.dp, end = 15.dp)
                    .height(60.dp)
                ,
                dato = "${infoUsuario.celUsuario.first().tel}",
                etiqueta = "Número de teléfono*",
                placeholder = "5588774455",
                puedeEditar = true,
                tipoTeclado = KeyboardType.Phone
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        if(edicion1 != "" && edicion2 != ""){
            if(edicion1 != infoUsuario.emailUsuario.first().email || edicion2 != infoUsuario.celUsuario.first().tel.toString()){
                edicion = true
            }
        }
        val envio1: String?; val correlativo1: Int
        val envio2: String?; val correlativo2: Int
        if(edicion){
            if(edicion1 == infoUsuario.emailUsuario.first().email){
                envio1 = null
                correlativo1 = 0
            }else{
                envio1 = edicion1
                correlativo1 = infoUsuario.emailUsuario.first().correlativo
            }
            if(edicion2 == infoUsuario.celUsuario.first().tel.toString()){
                envio2 = null
                correlativo2 = 0
            }else{
                envio2 = edicion2
                correlativo2 = infoUsuario.celUsuario.first().correlativo
            }
            Row(verticalAlignment = Alignment.CenterVertically){
                Button(
                    onClick = {
                        Toast.makeText(
                            mContext,
                            "Actualización cancelada",
                            Toast.LENGTH_SHORT
                        ).show(); clickCancelar()
                    },
                    shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Institucional3
                    ),
                    enabled = true
                ) {
                    Text(
                        text = "Cancelar",
                        color = Color.White
                    )
                    Spacer(Modifier.size(ButtonDefaults.IconSpacing))
                    Icon(
                        imageVector = Icons.Outlined.Cancel,
                        contentDescription = "Cancelar",
                        tint = Color.White
                    )
                }
                Spacer(modifier = Modifier.width(20.dp))
                Button(
                    onClick = {
                        Toast.makeText(
                            mContext,
                            "Actualización en curso",
                            Toast.LENGTH_SHORT
                        ).show(); clickActualizacion(envio1, correlativo1, envio2, correlativo2)
                        //TODO SI NO SE ACTUALIZA MOSTRAR EL MENSAJE
                    },
                    shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Institucional3
                    ),
                    enabled = true
                ) {
                    Text(
                        text = "Guardar",
                        color = Color.White
                    )
                    Spacer(Modifier.size(ButtonDefaults.IconSpacing))
                    Icon(
                        imageVector = Icons.Outlined.Save,
                        contentDescription = "Guardar",
                        tint = Color.White
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
            }
        }
    }
}