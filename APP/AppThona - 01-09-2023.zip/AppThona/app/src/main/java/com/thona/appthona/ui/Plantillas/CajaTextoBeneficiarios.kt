package com.thona.appthona.ui.Plantillas

import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import com.thona.appthona.Constantes.Institucional1

@Composable
fun cajaTextoBeneficiarios(modifier: Modifier, dato: String, etiqueta: String, placeholder: String, editable: Boolean, tipoTeclado: KeyboardType): Boolean{
    var Edito by rememberSaveable { mutableStateOf(value = false) }
    var texto by rememberSaveable { mutableStateOf(value = dato) }
    val textoAnterior = dato
    var distinto = false
    OutlinedTextField(
        value = texto,
        onValueChange = { texto = it; distinto = cambio(texto,textoAnterior) },
        modifier = modifier,
        label = { Text(text = etiqueta) },
        placeholder = { Text(text = placeholder) },
        textStyle = if(etiqueta == "Porcentaje") TextStyle(textAlign = TextAlign.End)
         else TextStyle(),
        enabled = editable,
        readOnly = !editable,
        keyboardOptions = KeyboardOptions(
            keyboardType = tipoTeclado
        ),
        shape = CircleShape,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Institucional1
        ),
        suffix = {
            if(etiqueta == "Porcentaje")
                Text(text = "%")
        },
    )
    Edito = distinto
    return Edito
}

fun cambio(nuevo: String, anterior: String): Boolean{
    println("Anterior: $anterior -- Nuevo $nuevo")
    var distinto = false
    if(nuevo != anterior){
        distinto = true
    }
    println("distindo? = $distinto")
    return distinto
}