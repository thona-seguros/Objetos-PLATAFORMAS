package com.thona.appthona.ui.Pantallas

import android.Manifest
import android.Manifest.permission.ACCESS_FINE_LOCATION
import android.app.Activity
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.thona.appthona.Data.WebServices.Modelos.Login
import com.thona.appthona.Data.WebServices.Modelos.ubicacion
import com.thona.appthona.Funciones.funciones
import com.thona.appthona.R
import com.thona.appthona.Ubicacion.checkPermission
import com.thona.appthona.Ubicacion.permisoUbi
import com.thona.appthona.Ubicacion.pidePermiso
import com.thona.appthona.ui.Pantallas.Agente.menuAgente
import com.thona.appthona.ui.Pantallas.Asegurado.AseguradoCuenta
import com.thona.appthona.ui.Pantallas.Asegurado.AseguradoPolizas
import com.thona.appthona.ui.Pantallas.Asegurado.AseguradoTramites
import com.thona.appthona.ui.Pantallas.Asegurado.DetallePolizas
import com.thona.appthona.ui.Pantallas.Cliente.menuCliente
import com.thona.appthona.ui.Plantillas.*
import com.thona.appthona.ui.Plantillas.MenuColapsable.ExpandableListViewModel
import com.thona.appthona.ui.Plantillas.TopBar.*
import com.thona.appthona.ui.theme.Institucional1
import com.thona.appthona.ui.theme.Institucional2
import com.thona.appthona.ui.theme.Institucional3

@Composable
fun AppThona(
    funciones: funciones,
    navController: NavHostController = rememberNavController()
){
    val ubicacion = funciones.ubicacion.value
    val loadingProgressBar = funciones.progressBar.value
    val mensajeRespuesta = funciones.MensajeRespuesta.value
    val rolSel = funciones.rolLogin.value
    val respuestaLogin = funciones.respuestaLogin.value
    val loginCorrecto = funciones.loginCorrecto.value
    val cambioContrasenaCorrecto = funciones.cambioCorrecto.value
    val seleccion = funciones.seleccionMenu.value
    val consultaInformacion = funciones.miInformacion.value
    val consultaProductos = funciones.misProductos.value
    val detalleProducto = funciones.detallesDePoliza.value
    val seleccionoPoliza = funciones.seleccionoPoliza.value
    val aceptoMensaje = funciones.opcionMensaje.value
    val listaParentescos = funciones.catalogoParentescos.value
    val seleccionoBeneficiario = funciones.seleccionoBeneficiario.value
    val actualizoInfo = funciones.actualizoInfo.value
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentScreen = DatosPantalla.valueOf(
        backStackEntry?.destination?.route?: DatosPantalla.Login.name
    )
    var colorRol = Institucional1
    var nFondo = 0
    if(currentScreen.name.contains("Cliente")){nFondo=1}
    if(currentScreen.name.contains("Agente")){nFondo=2}
    if(currentScreen.name.contains("Asegurado")){nFondo=3}
    when(nFondo){
        1 -> { colorRol = Institucional1 }
        2 -> { colorRol = Institucional2 }
        3 -> { colorRol = Institucional3 }
    }
    Scaffold(
        topBar = {
            TopBar(
                color = colorRol,
                pantallaActual = currentScreen,
                puedeRegresar = false,
                accionRegresar = { navController.navigateUp() },
                actionItems = itemsMenu,
                accionItem = funciones::SeleccionMenuTop,
                accionAgregarBenef = funciones::agregaEspacioBeneficiario
            )
        },
        bottomBar = {
            BottomBarNav(
                color = colorRol,
                navController = navController
            )
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = DatosPantalla.Login.name,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(route = DatosPantalla.Login.name) {
                BackHandler(
                    enabled = true,
                    onBack = {  }
                )
                Column(horizontalAlignment = Alignment.CenterHorizontally){
                    SeleccionRol(
                        click = funciones::SelecRol
                    )
                    if(rolSel.isNotEmpty()){
                        LaunchedEffect(key1 = Unit){
                            navController.navigate(route = rolSel){
                                funciones.Reiniciar()
                            }
                        }
                    }
                }
            }
            composable(route = DatosPantalla.Agente.name) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Agente(
                        login = funciones::Conexion,
                        click = funciones::SelecRol,
                        loadingProgressBar = loadingProgressBar,
                        loginCorrecto = loginCorrecto,
                        respuestaLogin = respuestaLogin,
                        clickMensaje = funciones::cierraSesion
                    )
                    if(loginCorrecto){
                        LaunchedEffect(key1 = Unit){
                            navController.navigate(route = DatosPantalla.MenuAgente.name){
                            }
                        }
                    }else if(rolSel.isNotEmpty()){
                        LaunchedEffect(key1 = Unit){
                            navController.navigate(route = rolSel){
                                funciones.Reiniciar()
                            }
                        }
                    }
                }
            }
            //var permiso: Boolean
            //var preunta = 0
            composable(route = DatosPantalla.Asegurado.name) {
                BackHandler(
                    enabled = true,
                    onBack = { navController.navigate(route = DatosPantalla.Login.name){funciones.rolLogin.value = ""} }
                )
                val permiso = permisoUbi(
                    funciones = funciones,
                    contexto = navController.context,
                    actividad = navController.context as Activity,
                    clicMensaje = funciones::clickMensaje
                )
                println("UBICACIÓN PERMISO: $permiso")
                println("DATOS DE UBICACIÓN: ${ubicacion.lon} - ${ubicacion.lat}")
                if(permiso){
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Asegurado(
                            login = funciones::Conexion,
                            click = funciones::SelecRol,
                            loadingProgressBar = loadingProgressBar,
                            loginCorrecto = loginCorrecto,
                            respuestaLogin = respuestaLogin,
                            clickMensaje = funciones::cierraSesion
                        )
                        if(loginCorrecto){
                            LaunchedEffect(key1 = Unit){
                                navController.navigate(route = DatosPantalla.AseguradoPolizas.name){
                                }
                            }
                        }else if(rolSel.isNotEmpty()){
                            LaunchedEffect(key1 = Unit){
                                navController.navigate(route = rolSel){
                                    funciones.Reiniciar()
                                }
                            }
                        }
                    }
                }else {
                    println("VA A REVISAR SI SE TIEME EL PERMISO")
                    checkPermission(navController.context as Activity, ACCESS_FINE_LOCATION,1,funciones::clickMensaje)
                    /*pidePermiso(
                        actividad = navController.context as Activity
                    )*/
                    /*LaunchedEffect(key1 = Unit){
                        navController.navigate(route = DatosPantalla.Asegurado.name){
                            pidePermiso(
                                actividad = navController.context as Activity
                            )
                        }
                    }
                    permiso = permisoUbi(funciones = funciones,
                        contexto = navController.context,
                        actividad = navController.context as Activity,
                        clicMensaje = funciones::clickMensaje)*/
                }

                when(aceptoMensaje){
                    1->{
                        pidePermiso(
                            actividad = navController.context as Activity
                        )
                        //checkPermission(navController.context as Activity, ACCESS_FINE_LOCATION,1)
                        LaunchedEffect(key1 = Unit){
                            navController.navigate(route = DatosPantalla.Asegurado.name){
                                funciones.Reiniciar()
                                funciones.opcionMensaje.value = 0
                            }
                        }
                    }
                    2->{
                        LaunchedEffect(key1 = Unit){
                            navController.navigate(route = DatosPantalla.Login.name){
                                funciones.Reiniciar()
                                funciones.opcionMensaje.value = 0
                            }
                        }
                    }
                }
            }
            composable(route = DatosPantalla.Cliente.name) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Cliente(
                        login = funciones::Conexion,
                        click = funciones::SelecRol,
                        loadingProgressBar = loadingProgressBar,
                        loginCorrecto = loginCorrecto,
                        respuestaLogin = respuestaLogin,
                        clickmensaje = funciones::cierraSesion
                    )
                    if(loginCorrecto){
                        LaunchedEffect(key1 = Unit){
                            navController.navigate(route = DatosPantalla.MenuCliente.name){
                            }
                        }
                    }else if(rolSel.isNotEmpty()){
                        LaunchedEffect(key1 = Unit){
                            navController.navigate(route = rolSel){
                                funciones.Reiniciar()
                            }
                        }
                    }
                }
            }
            composable(route = DatosPantalla.MenuAgente.name) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    menuAgente(
                        usuario = respuestaLogin
                    )
                }
            }
            composable(route = DatosPantalla.MenuCliente.name) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    menuCliente(
                        usuario = respuestaLogin
                    )
                }
            }
            composable(route = DatosPantalla.CambioContrasenaAgenteClienteAsegurado.name){
                Image(
                    painter = painterResource(id = R.drawable.thona_favicon_),
                    contentDescription = "Thona Seguros",
                    modifier = Modifier
                        .padding(2.dp)
                        .fillMaxSize()
                        .blur(20.dp),
                    alpha = 0.07F
                )
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CambioPassword(
                        rol = rolSel,
                        usuario = respuestaLogin,
                        cambiarContrasena = funciones::CambioContrasena,
                        loadingProgressBar = loadingProgressBar,
                        cambioCorrecto = cambioContrasenaCorrecto,
                        mensajeRespuesta = mensajeRespuesta,
                        clicMensaje = funciones::clickMensaje
                    )
                    if(cambioContrasenaCorrecto && respuestaLogin.Items.Rol == "ASEGURADO"){
                        if(aceptoMensaje == 1){
                            LaunchedEffect(key1 = Unit){
                                navController.navigate(route = DatosPantalla.AseguradoCuenta.name){
                                    funciones.cambioCorrecto.value = false
                                    funciones.MensajeRespuesta.value = ""
                                    funciones.opcionMensaje.value = 0
                                }
                            }
                        }
                    }
                }
            }
            //region ASEGURADO
            composable(route = DatosPantalla.AseguradoCuenta.name) {
                Image(
                    painter = painterResource(id = R.drawable.thona_favicon_),
                    contentDescription = "Thona Seguros",
                    modifier = Modifier
                        .padding(2.dp)
                        .fillMaxSize()
                        .blur(20.dp),
                    alpha = 0.07F
                )
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    AseguradoCuenta(
                        usuario = respuestaLogin,
                        infoUsuario = consultaInformacion,
                        productos = consultaProductos,
                        clickActualizacion = funciones::editaMailTel,
                        clickCancelar ={
                            navController.navigate(DatosPantalla.AseguradoCuenta.name) {
                                popUpTo(DatosPantalla.AseguradoCuenta.name) { inclusive = true }
                            }
                        }
                    )
                    println("Actualizo info: $actualizoInfo")
                    if(actualizoInfo){
                        AlertaDialogo(
                            titulo = "Actualización de información",
                            mensaje = mensajeRespuesta,
                            clicAceptar = { funciones.consultaInformacion(usuario = "${respuestaLogin.Items.CodUsuario}", session = respuestaLogin.session.idSession); funciones.actualizoInfo.value = false; funciones.MensajeRespuesta.value = "" },
                            clicCancelar = {  },
                            colorRol = Institucional3,
                            cantidadBotones = 1
                        )
                    }
                    if(seleccion == "Cambiar contraseña"){
                        LaunchedEffect(key1 = Unit){
                            navController.navigate(route = DatosPantalla.CambioContrasenaAgenteClienteAsegurado.name){
                                /*TODO REINICIAR VARIABLES*/
                                funciones.seleccionMenu.value = ""
                            }
                        }
                    }
                    if(seleccion == "Cerrar sesión"){
                        AlertaDialogo(
                            titulo = "Cerrar sesión",
                            mensaje = "¿Desea cerrar sesión?",
                            clicAceptar = { respuestaLogin.Items.CodUsuario?.let { it1 -> funciones.cierraSesion(usuario = it1, respuestaLogin.session.idSession) }; funciones.seleccionMenu.value = ""; funciones.MensajeRespuesta.value = "" },
                            clicCancelar = { funciones.seleccionMenu.value = "" },
                            colorRol = Institucional3,
                            cantidadBotones = 2
                        )
                    }
                    if(!funciones.sesionIniciada.value){
                        LaunchedEffect(key1 = Unit){
                            navController.navigate(route = DatosPantalla.Login.name){
                                funciones.Reiniciar()
                            }
                        }
                    }
                }
            }
            composable(route = DatosPantalla.AseguradoPolizas.name) {
                val mContext = LocalContext.current
                var backPressedCount by remember { mutableIntStateOf(0) }
                BackHandler(
                    enabled = true,
                    onBack = {
                        if(backPressedCount < 1){
                            Toast.makeText(
                                mContext,
                                "Pulsa de nuevo para salir",
                                Toast.LENGTH_SHORT
                            ).show()
                        }; backPressedCount += 1
                    }
                )
                if(backPressedCount > 1){
                    AlertaDialogo(
                        titulo = "Cerrar sesión",
                        mensaje = "¿Desea cerrar sesión?",
                        clicAceptar = { respuestaLogin.Items.CodUsuario?.let { it1 -> funciones.cierraSesion(usuario = it1, respuestaLogin.session.idSession) }; funciones.seleccionMenu.value = ""; funciones.MensajeRespuesta.value = "" },
                        clicCancelar = { funciones.seleccionMenu.value = "";  backPressedCount = 0},
                        colorRol = Institucional3,
                        cantidadBotones = 2
                    )
                }
                if(validaSesion(respuestaLogin)){
                    Image(
                        painter = painterResource(id = R.drawable.thona_favicon_),
                        contentDescription = "Thona Seguros",
                        modifier = Modifier
                            .padding(2.dp)
                            .fillMaxSize()
                            .blur(20.dp),
                        alpha = 0.07F
                    )
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        AseguradoPolizas(
                            usuario = respuestaLogin,
                            productos = consultaProductos,
                            clicPoliza = funciones::DetallePoliza
                        )
                    }
                } else{
                    LaunchedEffect(key1 = Unit){
                        navController.navigate(route = DatosPantalla.Asegurado.name){
                            funciones.Reiniciar()
                        }
                    }
                }
                if(seleccionoPoliza){
                    LaunchedEffect(key1 = Unit){
                        navController.navigate(route = DatosPantalla.AseguradoDetallePoliza.name){
                            funciones.seleccionoPoliza.value = false
                        }
                    }
                }
            }
            composable(route = DatosPantalla.AseguradoTramites.name) {
                Image(
                    painter = painterResource(id = R.drawable.thona_favicon_),
                    contentDescription = "Thona Seguros",
                    modifier = Modifier
                        .padding(2.dp)
                        .fillMaxSize()
                        .blur(20.dp),
                    alpha = 0.07F
                )
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    AseguradoTramites(
                        usuario = respuestaLogin,
                        productos = consultaProductos
                    )
                    if(!funciones.sesionIniciada.value){
                        LaunchedEffect(key1 = Unit){
                            navController.navigate(route = DatosPantalla.Login.name){
                                funciones.Reiniciar()
                            }
                        }
                    }
                }
            }
            composable(route = DatosPantalla.AseguradoDetallePoliza.name){
                if(validaSesion(respuestaLogin)){
                    Image(
                        painter = painterResource(id = R.drawable.thona_favicon_),
                        contentDescription = "Thona Seguros",
                        modifier = Modifier
                            .padding(2.dp)
                            .fillMaxSize()
                            .blur(20.dp),
                        alpha = 0.07F
                    )
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        DetallePolizas(
                            clicKEdicion = funciones::editaBeneficiario,
                            usuario = consultaInformacion,
                            detallePoliza = detalleProducto,
                            clickDescargaPoliza = funciones::descargaPoliza,
                            clickDescargaCG = funciones::descargaCG,
                            clickEnviaPorCorreo = funciones::enviaDocCorreo,
                            mensaje = funciones.MensajeRespuesta.value,
                            muestraMensaje = funciones.muestraMensaje.value,
                            funciones = funciones
                        )
                    }
                    if(seleccionoBeneficiario){
                        LaunchedEffect(key1 = Unit){
                            navController.navigate(route = DatosPantalla.AseguradoBeneficiarios.name){
                                funciones.seleccionoBeneficiario.value = false
                            }
                        }
                    }
                } else{
                    LaunchedEffect(key1 = Unit){
                        navController.navigate(route = DatosPantalla.Asegurado.name){
                            funciones.Reiniciar()
                        }
                    }
                }
            }
            composable(route = DatosPantalla.AseguradoBeneficiarios.name){
                Image(
                    painter = painterResource(id = R.drawable.thona_favicon_),
                    contentDescription = "Thona Seguros",
                    modifier = Modifier
                        .padding(2.dp)
                        .fillMaxSize()
                        .blur(20.dp),
                    alpha = 0.07F
                )
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    EdicionBeneficiarios(
                        producto = detalleProducto,
                        viewModel = ExpandableListViewModel(),
                        listaParentescos = listaParentescos
                    )
                }
            }
            //endregion
        }
    }
}

fun validaSesion(datosUsuario: Login): Boolean{
    return !datosUsuario.Items.NomUsuario.isNullOrEmpty()
}