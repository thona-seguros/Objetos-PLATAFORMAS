package com.thona.appthona.ui.theme

val Institucional1 = com.thona.appthona.Constantes.Institucional1
val Institucional2 = com.thona.appthona.Constantes.Institucional2
val Institucional3 = com.thona.appthona.Constantes.Institucional3