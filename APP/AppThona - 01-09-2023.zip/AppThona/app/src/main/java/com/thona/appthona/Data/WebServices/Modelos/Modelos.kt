package com.thona.appthona.Data.WebServices.Modelos

import com.google.gson.annotations.SerializedName
import org.simpleframework.xml.Element

data class ModeloLogin(
    @SerializedName("items") val Login: Login
)

data class ModeloCambioPassword(
    @SerializedName("items") val CambioPassword: CambioPassword
)

data class ModeloCierreSesion(
    @SerializedName("items") val CierraSesion: CierreSesion
)

data class ModeloMyInformacion(
    @SerializedName("items") val MyInfo: MyInfo
)

data class ModeloMyProducto(
    @SerializedName("items") val MyProducto: MyProducto
)

data class ModeloDetalleProducto(
    @SerializedName("items") val DetalleProducto: DetalleProducto
)

data class ModeloCatalogoParentescos(
    @SerializedName("items") val CatalogoParentescos: CatalogoParentescos
)

data class ModeloObteieneIP(
    @SerializedName("ip") var ip : String,
    /*@SerializedName("hostname") val hostname : String,
    @SerializedName("city") val city : String,
    @SerializedName("region") val region : String,
    @SerializedName("country") val country : String,
    @SerializedName("loc") val loc : String,
    @SerializedName("org") val org : String,
    @SerializedName("postal") val postal : String,
    @SerializedName("timezone") val timezone : String,
    @SerializedName("readme") val readme : String*/
)

data class ModeloPrueba(
    @Element(name = "ok")
    //@field: Element(name = "ok", required = false)
    //@param: Element(name = "ok", required = false)
    val ok: String? = null
    //val ok: String?
)