package com.thona.appthona.Constantes

import androidx.compose.ui.graphics.Color

val Institucional1 = Color(0xFF06559B)
val Institucional2 = Color (0xFFCB3333)
val Institucional3 = Color (0xFF201747)
val ThonaVerde = Color (124,185,87)
val ThonaRojo = Color (192,0,0)

val Institucional3light1 = Color(0xCC201747)
val Institucional3light2 = Color(0x80201747)
