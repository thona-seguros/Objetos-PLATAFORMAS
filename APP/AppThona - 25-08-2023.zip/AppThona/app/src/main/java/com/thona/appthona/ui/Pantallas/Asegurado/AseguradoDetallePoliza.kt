package com.thona.appthona.ui.Pantallas.Asegurado

import android.widget.Space
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowForward
import androidx.compose.material.icons.outlined.ArrowForwardIos
import androidx.compose.material.icons.outlined.AssignmentInd
import androidx.compose.material.icons.outlined.AttachEmail
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.FactCheck
import androidx.compose.material.icons.outlined.Mail
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Alignment.Companion.CenterHorizontally
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.thona.appthona.Constantes.Institucional1
import com.thona.appthona.Data.WebServices.Modelos.DetalleProducto
import com.thona.appthona.Data.WebServices.Modelos.InfoItem
import com.thona.appthona.Data.WebServices.Modelos.Login
import com.thona.appthona.ui.Plantillas.AlertaDialogo
import com.thona.appthona.ui.Plantillas.MenuColapsable.ExpandableListViewModel
import com.thona.appthona.ui.Plantillas.MenuColapsable.ListadoMenu
import com.thona.appthona.ui.theme.Institucional3

@Composable
fun DetallePolizas(
    clicKEdicion: () -> Unit,
    usuario: InfoItem,
    detallePoliza: DetalleProducto,
    clickDescargaPoliza: () -> Unit,
    clickDescargaCG: () -> Unit,
    clickEnviaPorCorreo: () -> Unit
){
    var clickBoton by rememberSaveable { mutableIntStateOf(0) }
    //val scrollState = rememberScrollState()
    Column(){
        Row (modifier = Modifier.offset(7.dp)) {
            Text(
                text = "Póliza ${detallePoliza.detalleProducto.idPoliza}",
                fontWeight = FontWeight.Bold
            )
        }
        Row (modifier = Modifier.offset(7.dp)) {
            Text(
                text = "Estatus: ${detallePoliza.detalleProducto.status}",
                fontWeight = FontWeight.Bold
            )
        }
        Row (modifier = Modifier.offset(7.dp),) {
            Text(
                text = "Vigencia: ${detallePoliza.detalleProducto.vicenciaInicial} - ${detallePoliza.detalleProducto.vigenciaFinal}",
                fontWeight = FontWeight.Normal
            )
        }
        Row (modifier = Modifier
            .offset(7.dp)
            .padding(5.dp),) {
            Text(
                text = detallePoliza.detalleProducto.descripcionSeguro,
                fontWeight = FontWeight.Light,
                fontSize = 15.sp
            )
        }
        Column() {
            Spacer(modifier = Modifier.height(15.dp))
            Divider(color = Institucional3, thickness = 1.dp)
            Column() {
                ListadoMenu(
                    clicKEdicion = clicKEdicion,
                    viewModel = ExpandableListViewModel(),
                    datos = detallePoliza
                )
            }
            Divider(color = Institucional3, thickness = 1.dp)
        }
        Spacer(modifier = Modifier.height(20.dp))
        val mContext = LocalContext.current
        Row (modifier = Modifier
            .fillMaxWidth(), horizontalArrangement = Arrangement.Center){
            Column(horizontalAlignment = CenterHorizontally) {
                OutlinedButton(
                    onClick = {
                         clickBoton = 1
                    },
                    modifier= Modifier.size(60.dp),
                    shape = CircleShape,
                    border= BorderStroke(width = 5.dp, color = Institucional3),
                    contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor =  Institucional3)
                ) {
                    Icon(imageVector = Icons.Outlined.AssignmentInd ,contentDescription = "", tint= Institucional3)
                }
                Spacer(modifier = Modifier.height(5.dp))
                Text(
                    text = "Descargar póliza",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.width(15.dp))
            Column (horizontalAlignment = CenterHorizontally){
                OutlinedButton(
                    onClick = {
                        clickBoton = 2
                    },
                    modifier= Modifier.size(60.dp),
                    shape = CircleShape,
                    border= BorderStroke(width = 5.dp, color = Institucional3),
                    contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor =  Institucional3)
                ) {
                    Icon(imageVector = Icons.Outlined.FactCheck ,contentDescription = "", tint= Institucional3)
                }
                Spacer(modifier = Modifier.height(5.dp))
                Text(
                    text = "Descargar C.G.",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.width(15.dp))
            Column (horizontalAlignment = CenterHorizontally){
                OutlinedButton(
                    onClick = {
                        clickBoton = 3
                    },
                    modifier= Modifier.size(60.dp),
                    shape = CircleShape,
                    border= BorderStroke(width = 5.dp, color = Institucional3),
                    contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor =  Institucional3)
                ) {
                    Icon(imageVector = Icons.Outlined.AttachEmail ,contentDescription = "", tint= Institucional3)
                }
                Spacer(modifier = Modifier.height(5.dp))
                Text(
                    text = "Enviar por mail",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            if(clickBoton != 0){
                when(clickBoton){
                    1->{
                        AlertaDialogo(
                            titulo = "Descargar póliza",
                            mensaje = "¿Deseas descargar la póliza ${detallePoliza.detalleProducto.idPoliza}?",
                            clicAceptar = { Toast.makeText(
                                mContext,
                                "Icono para descargar poliza",
                                Toast.LENGTH_SHORT
                            ).show(); clickBoton = 0; clickDescargaPoliza() },
                            clicCancelar = { clickBoton = 0 },
                            colorRol = Institucional3,
                            cantidadBotones = 2
                        )
                    }
                    2->{
                        AlertaDialogo(
                            titulo = "Descargar Condiciones generales",
                            mensaje = "¿Deseas descargar las condiciones generales de la póliza ${detallePoliza.detalleProducto.idPoliza}?",
                            clicAceptar = { Toast.makeText(
                                mContext,
                                "Icono para descargar Condiciones Generales",
                                Toast.LENGTH_SHORT
                            ).show(); clickBoton = 0; clickDescargaCG() },
                            clicCancelar = { clickBoton = 0 },
                            colorRol = Institucional3,
                            cantidadBotones = 2
                        )
                    }
                    3->{
                        AlertaDialogo(
                            titulo = "Enviar documentación",
                            mensaje = "se enviara al mail ${usuario.emailUsuario.first().email} los documentos de la póliza ${detallePoliza.detalleProducto.idPoliza}",
                            clicAceptar = { Toast.makeText(
                                mContext,
                                "Icono para enviar póliza y C.G por correo",
                                Toast.LENGTH_SHORT
                            ).show(); clickBoton = 0; clickEnviaPorCorreo() },
                            clicCancelar = { clickBoton = 0 },
                            colorRol = Institucional3,
                            cantidadBotones = 2
                        )
                    }
                }
            }
        }
    }
}