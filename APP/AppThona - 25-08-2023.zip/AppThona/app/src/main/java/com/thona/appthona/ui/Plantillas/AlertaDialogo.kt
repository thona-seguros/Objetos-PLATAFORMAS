package com.thona.appthona.ui.Plantillas

import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color

@Composable
fun AlertaDialogo(
    //muestraDialogo: Boolean,
    titulo: String,
    mensaje: String,
    clicAceptar: () -> Unit,
    clicCancelar: () -> Unit,
    colorRol: Color,
    cantidadBotones: Int,
){
    val openDialog = remember { mutableStateOf(false)  }

    openDialog.value = true
    androidx.compose.material3.AlertDialog(
        onDismissRequest = {
            // Dismiss the dialog when the user clicks outside the dialog or on the back
            // button. If you want to disable that functionality, simply use an empty
            // onCloseRequest.
            openDialog.value = false
        },
        title = {
            Text(text = titulo)
        },
        text = {
            Text(mensaje)
        },
        confirmButton = {
            Button(
                onClick = {
                    clicAceptar();openDialog.value=false
                },
                colors = ButtonDefaults.buttonColors(colorRol)
            ) {
                Text("Aceptar")
            }
        },
        dismissButton = {
            if(cantidadBotones == 2){
                Button(
                    onClick = {
                        clicCancelar();openDialog.value=false
                    },
                    colors = ButtonDefaults.buttonColors(colorRol)
                ) {
                    Text("Cancelar")
                }
            }
        }
    )
}