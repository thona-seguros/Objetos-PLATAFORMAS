package com.thona.appthona.Data.WebServices.Modelos

import com.google.gson.annotations.SerializedName

data class Login(
    @SerializedName("session") val session: SesionItem,
    @SerializedName("datos") val Items: LoginItem,
    @SerializedName("control") val Control: Control
)

data class CambioPassword(
    //@SerializedName("datos") val Items: CambioPasswordItem,
    @SerializedName("control") val Control: Control
)

data class CierreSesion(
    @SerializedName("control") val Control: Control
)

data class MyInfo(
    @SerializedName("datos") val Datos: InfoItem,
    @SerializedName("control") val Control: Control
)

data class MyProducto(
    @SerializedName("IdUnico") val idAsegurado: idUnicoItem,
    @SerializedName("productos") val Productos: List<MyProdcutoItem>,
    @SerializedName("control") val Control: Control
)

data class DetalleProducto(
    @SerializedName("productos") val detalleProducto: DetalleProductoItem,
    @SerializedName("Menus") val detalleMenu: List<DetalleMenuItem>,
    @SerializedName("cobertura") val detalleCoberturas: List<DetalleCoberturaItem>,
    @SerializedName("beneficiario") val detalleBeneficiarios: List<DetalleBeneficiarioItem>,
    @SerializedName("facturas") val facturas: List<facturaItem>,
    @SerializedName("control") val Control: Control
)

data class CatalogoParentescos(
    @SerializedName("datos") val ListaParentescos: List<ParentescoItem>,
    @SerializedName("control") val Control: Control
)