package com.thona.appthona.ui.Plantillas.MenuColapsable

import androidx.lifecycle.ViewModel
import com.thona.appthona.Data.WebServices.Modelos.DetalleBeneficiarioItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class ExpandableListViewModel : ViewModel() {

    private val itemIdsList = MutableStateFlow(listOf<Int>())
    val itemIds: StateFlow<List<Int>> get() = itemIdsList

    private val itemIdsList2 = MutableStateFlow(listOf<String>())
    val itemIds2: StateFlow<List<String>> get() = itemIdsList2

    fun onItemClicked(itemId: Int) {
        itemIdsList.value = itemIdsList.value.toMutableList().also { list ->
            if (list.contains(itemId)) {
                list.remove(itemId)
            } else {
                list.add(itemId)
            }
        }
    }

    fun onItemClicked2(itemId: String) {
        itemIdsList2.value = itemIdsList2.value.toMutableList().also { list ->
            if (list.contains(itemId)) {
                list.remove(itemId)
            } else {
                list.add(itemId)
            }
        }
    }
    fun limpia2(itemId: String) {
        itemIdsList2.value = itemIdsList2.value.toMutableList().also { list ->
            if (list.contains(itemId)) {
                list.remove(itemId)
            }
        }
    }

    private val benefIdsList = MutableStateFlow(listOf<DetalleBeneficiarioItem>())
    val benefIds: StateFlow<List<DetalleBeneficiarioItem>> get() = benefIdsList

    /*private val benefIdsList2 = MutableStateFlow(listOf<String>())
    val benefIds2: StateFlow<List<String>> get() = benefIdsList2*/

    fun agregaBeneficiario(beneficiario: DetalleBeneficiarioItem): Boolean{
        var inserto = false
        benefIdsList.value = benefIdsList.value.toMutableList().also { list ->
            if(list.isNotEmpty()){
                list.forEach{  dato ->
                    if(beneficiario.nombreBeneficiario == dato.nombreBeneficiario){
                        if(beneficiario.parentescoBeneficiario != dato.parentescoBeneficiario || beneficiario.porcentajeBeneficiario != dato.porcentajeBeneficiario){
                            quitaBeneficiario(dato)
                            list.add(beneficiario)
                            inserto = true
                        }
                    }
                }
                if (!list.contains(beneficiario) && !inserto) {
                    list.add(beneficiario)
                    inserto = true
                }
            }else{
                list.add(beneficiario)
                inserto = true
            }
        }
        return inserto
    }

    fun quitaBeneficiario(beneficiario: DetalleBeneficiarioItem){
        benefIdsList.value = benefIdsList.value.toMutableList().also { list ->
            if (list.contains(beneficiario)) {
                list.remove(beneficiario)
            }
        }
    }
}