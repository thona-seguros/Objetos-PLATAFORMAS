package com.thona.appthona.Data.WebServices.Modelos

import com.google.gson.annotations.SerializedName

data class ModeloLogin(
    @SerializedName("items") val Login: Login
)

data class ModeloCambioPassword(
    @SerializedName("items") val CambioPassword: CambioPassword
)

data class ModeloCierreSesion(
    @SerializedName("items") val CierraSesion: CierreSesion
)

data class ModeloMyInformacion(
    @SerializedName("items") val MyInfo: MyInfo
)

data class ModeloMyProducto(
    @SerializedName("items") val MyProducto: MyProducto
)

data class ModeloDetalleProducto(
    @SerializedName("items") val DetalleProducto: DetalleProducto
)

data class ModeloCatalogoParentescos(
    @SerializedName("items") val CatalogoParentescos: CatalogoParentescos
)