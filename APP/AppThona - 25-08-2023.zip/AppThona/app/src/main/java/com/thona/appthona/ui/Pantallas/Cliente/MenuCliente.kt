package com.thona.appthona.ui.Pantallas.Cliente

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import com.thona.appthona.Data.WebServices.Modelos.Login
import com.thona.appthona.Data.WebServices.Modelos.MyProducto

@Composable
fun menuCliente(
    usuario: Login
){
    Text(text = "Texto: ${usuario.Control.TextoRespuesta}, codigo: ${usuario.Control.NumeroRespuesta}")
    Text(text = "Datos: ${usuario.Items.Rol}")
}