package com.thona.appthona.ui.Pantallas.Asegurado

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowForwardIos
import androidx.compose.material.icons.outlined.Bolt
import androidx.compose.material.icons.outlined.Engineering
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Alignment.Companion.CenterVertically
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.thona.appthona.Constantes.Institucional2
import com.thona.appthona.Data.WebServices.Modelos.Login
import com.thona.appthona.Data.WebServices.Modelos.MyProducto
import com.thona.appthona.ui.theme.Institucional3

@Composable
fun AseguradoProductos(
    usuario: Login,
    productos: MyProducto,
    clicPoliza: (usuario: String?, idPoliza: String?, session: Int) -> Unit
){
    val scrollState = rememberScrollState()

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(color = Institucional3),
        horizontalArrangement = Arrangement.Center
    ) {
        Text(
            text = "No. Asegurado:${productos.idAsegurado.codAsegurado}",
            color = Color.White,
            fontSize = 11.sp
        )
    }

    Column(
        modifier = Modifier.verticalScroll(scrollState).fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if(productos.Productos.isNotEmpty()){
            productos.Productos.forEach {
                Spacer(modifier = Modifier.height(7.dp))
                Row(
                    verticalAlignment = CenterVertically,
                    modifier = Modifier.clickable { clicPoliza(usuario.Items.CodUsuario,it.idPoliza,usuario.session.idSession) }
                ){
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Row {
                            Text(text = "Póliza")
                        }
                        Row {
                            Text(text = "${it.idPoliza}")
                        }
                    }
                    Spacer(modifier = Modifier.width(20.dp))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Row {
                            Text(text = "Tipo")
                        }
                        Row {
                            Text(text = "${it.idTipoSeguro}")
                        }
                    }
                    Spacer(modifier = Modifier.width(20.dp))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Row {
                            Text(text = "Vigencia")
                        }
                        Row {
                            Text(text = "${it.fechaVigencia}")
                        }
                    }
                    Spacer(modifier = Modifier.width(25.dp))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Row {
                            IconButton(onClick = { clicPoliza(usuario.Items.CodUsuario,it.idPoliza,usuario.session.idSession) }) {
                                Icon(modifier = Modifier, imageVector = Icons.Outlined.ArrowForwardIos, contentDescription = "", tint = Institucional2)
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(7.dp))
                Divider(color = Institucional3, thickness = 0.5.dp)
            }
        }

    }
}