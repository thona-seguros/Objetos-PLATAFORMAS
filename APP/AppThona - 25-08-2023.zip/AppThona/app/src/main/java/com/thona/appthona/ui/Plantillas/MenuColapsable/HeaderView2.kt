package com.thona.appthona.ui.Plantillas.MenuColapsable
/*
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.thona.appthona.Constantes.Institucional1
import com.thona.appthona.Constantes.Institucional3
import com.thona.appthona.Constantes.Institucional3light
import com.thona.appthona.Data.WebServices.Modelos.DataModel
import com.thona.appthona.Data.WebServices.Modelos.DetalleBeneficiarioItem
import com.thona.appthona.Data.WebServices.Modelos.DetalleCoberturaItem
import com.thona.appthona.Data.WebServices.Modelos.DetalleProducto
import com.thona.appthona.Data.WebServices.Modelos.facturaItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.forEach
@Composable
fun ListadoMenu(viewModel: ExpandableListViewModel, datos: DetalleProducto) {

    val itemIds by viewModel.itemIds.collectAsState()
    val itemIds2 by viewModel.itemIds2.collectAsState()

    val menus = datos.detalleMenu
    val coberturas = datos.detalleCoberturas
    val beneficiarios = datos.detalleBeneficiarios
    val facturas = datos.facturas
    var conta: Int

    LazyColumn(modifier = Modifier.padding()){
        itemsIndexed(menus){ index, item ->
            Column {
                Box(modifier = Modifier) {
                    HeaderView(titulo = "${item.tituloMenu} - $index", onClickItem = { viewModel.onItemClicked(index) })
                }
                when(item.tituloMenu) {
                    "Coberturas" -> {
                        conta = 0
                        coberturas.forEach{
                            Box(modifier = Modifier.fillMaxSize()){
                                Box(
                                    modifier = Modifier
                                ) {
                                    Column {
                                        SubHeaderView(subtitulo = "${it.codigoCobertura} - $conta", onClickItem = { viewModel.onItemClicked2(it.codigoCobertura) }, visible = itemIds.contains(index))
                                        var visible2 = itemIds2.contains(it.codigoCobertura)
                                        if(!itemIds.contains(index)){
                                            visible2 = false
                                            viewModel.limpia2(it.codigoCobertura)
                                        }
                                        ExpandableView(contenido = "${it.descripcionCobertura} - $${it.sumaAsegurada}", isExpanded = visible2)
                                    }
                                }
                            }
                            conta++
                        }
                    }
                    "Beneficiarios" -> {
                        conta = 0
                        beneficiarios.forEach{
                            Box(modifier = Modifier.fillMaxSize()){
                                Box(
                                    modifier = Modifier
                                ) {
                                    Column {
                                        SubHeaderView(subtitulo = "${it.nombreBeneficiario} - $conta", onClickItem = { viewModel.onItemClicked2(it.nombreBeneficiario) }, visible = itemIds.contains(index))
                                        var visible2 = itemIds2.contains(it.nombreBeneficiario)
                                        if(!itemIds.contains(index)){
                                            visible2 = false
                                            viewModel.limpia2(it.nombreBeneficiario)
                                        }
                                        ExpandableView(contenido = "${it.porcentajeBeneficiario} - ${it.parentescoBeneficiario}", isExpanded = visible2)
                                    }
                                }
                            }
                            conta++
                        }
                    }
                    "Facturas" -> {
                        conta = 0
                        facturas.forEach{
                            Box(modifier = Modifier.fillMaxSize()){
                                Box(
                                    modifier = Modifier
                                ) {
                                    Column {
                                        SubHeaderView(subtitulo = "${it.idFactura} - ${it.statusFactura} - $conta", onClickItem = { viewModel.onItemClicked2(it.idFactura.toString()) }, visible = itemIds.contains(index))
                                        var visible2 = itemIds2.contains(it.idFactura.toString())
                                        if(!itemIds.contains(index)){
                                            visible2 = false
                                            viewModel.limpia2(it.idFactura.toString())
                                        }
                                        ExpandableView(contenido = "${it.fechaFactura} - \$${it.montoFactura} RECIBO: ${it.idRecibo} (\$${it.cuotaFactura}) - TRANSACCIÓN: ${it.idTransaccion}", isExpanded = visible2)
                                    }
                                }
                            }
                            conta++
                        }
                    }
                }
            }
        }
    }
}

/*
@Composable
fun AsignaMenu(menu: String, viewModel: ExpandableListViewModel, datos: DetalleProducto) {

    val coberturas = datos.detalleCoberturas
    val beneficiarios = datos.detalleBeneficiarios
    val facturas = datos.facturas

    val itemIds by viewModel.itemIds.collectAsState()

    when(menu){
        "Coberturas"->{
            LazyColumn(modifier = Modifier.padding(5.dp)){
                itemsIndexed(coberturas){ index, item ->
                    ExpandableContainerView(
                        titulo = item.codigoCobertura,
                        contenido = "${item.descripcionCobertura} - ${item.sumaAsegurada}",
                        onClickItem = { viewModel.onItemClicked(index) },
                        expanded = itemIds.contains(index)
                    )
                }
            }
        }
        "Beneficiarios"->{
            LazyColumn(modifier = Modifier.padding(5.dp)){
                itemsIndexed(beneficiarios){ index, item ->
                    ExpandableContainerView(
                        titulo = item.nombreBeneficiario,
                        contenido = "${item.porcentajeBeneficiario} - ${item.parentescoBeneficiario}",
                        onClickItem = { viewModel.onItemClicked(index) },
                        expanded = itemIds.contains(index)
                    )
                }
            }
        }
        "Facturas"->{
            LazyColumn(modifier = Modifier.padding(5.dp)){
                itemsIndexed(facturas){ index, item ->
                    ExpandableContainerView(
                        titulo = "${item.idFactura} - ${item.statusFactura}",
                        contenido = "${item.fechaFactura} - $${item.montoFactura} RECIBO: ${item.idRecibo} ($${item.cuotaFactura}) - TRANSACCIÓN: ${item.idTransaccion}",
                        onClickItem = { viewModel.onItemClicked(index) },
                        expanded = itemIds.contains(index)
                    )
                }
            }
        }
    }
}*/
/*
@Composable
fun ListadoCoberturas(viewModel: ExpandableListViewModel, datos: List<DetalleCoberturaItem>) {

    val itemIds by viewModel.itemIds.collectAsState()

    LazyColumn(modifier = Modifier.padding(5.dp)){
        itemsIndexed(datos){ index, item ->
            ExpandableContainerView(
                titulo = item.codigoCobertura,
                contenido = "${item.descripcionCobertura} - ${item.sumaAsegurada}",
                onClickItem = { viewModel.onItemClicked(index) },
                expanded = itemIds.contains(index)
            )
        }
    }

    /*Scaffold(
    ) { padding ->  // We need to pass scaffold's inner padding to the content
        LazyColumn(modifier = Modifier.padding(padding)) {
            itemsIndexed(viewModel.items.value) { index, item ->
                ExpandableContainerView(
                    titulo = titulo,
                    contenido = item,
                    onClickItem = { viewModel.onItemClicked(index) },
                    expanded = itemIds.contains(index)
                )
            }
        }
    }*/
}
*/
/*
@Composable
fun ListadoBeneficiarios(viewModel: ExpandableListViewModel, datos: List<DetalleBeneficiarioItem>) {

    val itemIds by viewModel.itemIds.collectAsState()

    LazyColumn(modifier = Modifier.padding(5.dp)){
        itemsIndexed(datos){ index, item ->
            ExpandableContainerView(
                titulo = item.nombreBeneficiario,
                contenido = "${item.porcentajeBeneficiario} - ${item.parentescoBeneficiario}",
                onClickItem = { viewModel.onItemClicked(index) },
                expanded = itemIds.contains(index)
            )
        }
    }
}
*/
/*
@Composable
fun ListadoFacturas(viewModel: ExpandableListViewModel, datos: List<facturaItem>) {

    val itemIds by viewModel.itemIds.collectAsState()

    LazyColumn(modifier = Modifier.padding(5.dp)){
        itemsIndexed(datos){ index, item ->
            ExpandableContainerView(
                titulo = "${item.idFactura} - ${item.statusFactura}",
                contenido = "${item.fechaFactura} - $${item.montoFactura} RECIBO: ${item.idRecibo} ($${item.cuotaFactura}) - TRANSACCIÓN: ${item.idTransaccion}",
                onClickItem = { viewModel.onItemClicked(index) },
                expanded = itemIds.contains(index)
            )
        }
    }
}
*/

/*private val itemIdsList2 = MutableStateFlow(listOf<Int>())
val itemIds2: StateFlow<List<Int>> get() = itemIdsList2

fun onItemClicked2(ite: Int) {
    itemIdsList2.value = itemIdsList2.value.toMutableList().also { list ->
        if (list.contains(ite)) {
            list.remove(ite)
        } else {
            list.add(ite)
        }
    }
}*/

@Composable
fun ExpandableContainerView(viewModel: ExpandableListViewModel, titulo: String, onClickItem: () -> Unit, expanded: Boolean, datos: DetalleProducto) {

    val coberturas = datos.detalleCoberturas
    val beneficiarios = datos.detalleBeneficiarios
    val facturas = datos.facturas

    Box(
        modifier = Modifier
            //.background(Color.White)
    ) {
        Column {
            HeaderView(titulo = titulo, onClickItem = onClickItem)

            when(titulo) {
                "Coberturas" -> {
                    /*val itemIds2 by viewModel.itemIds2.collectAsState()

                    LazyColumn(modifier = Modifier.padding()){
                        itemsIndexed(coberturas){ index, item ->
                            ExpandableContainerView2(
                                subtitulo = item.codigoCobertura,
                                contenido = datos,
                                onClickItem = { viewModel.onItemClicked2(index) },
                                expanded = itemIds2.contains(index)
                            )
                        }
                    }*/



                    //var orden = 0
                    //coberturas.forEach{
                        //CREAR OTRO CONTAINER POR CADA SUBTITULO


                        //SubHeaderView(subtitulo = it.codigoCobertura, onClickItem = onClickItem, visible = expanded)
                        //ExpandableView(contenido = "${it.descripcionCobertura} - $${it.sumaAsegurada}", isExpanded = expanded)
                        //orden++
                    //}

                    /*LazyColumn(modifier = Modifier.padding()){
                        itemsIndexed(coberturas){ index, item ->
                            SubHeaderView(
                                subtitulo = item.codigoCobertura,
                                onClickItem = { viewModel.onItemClicked(index) },
                                visible = expanded
                            )
                            ExpandableContainerView(
                                subtitulo = item.codigoCobertura,
                                contenido = "${item.descripcionCobertura} - \$${item.sumaAsegurada}",
                                onClickItem = { onItemClicked2(index) },
                                expanded = itemIds2.contains(index)
                            )
                        }
                    }*/
                }

                /*"Beneficiarios" -> {
                    beneficiarios.forEach{
                        SubHeaderView(subtitulo = it.nombreBeneficiario, onClickItem = onClickItem, visible = expanded)
                        ExpandableView(contenido = "${it.parentescoBeneficiario} - $${it.porcentajeBeneficiario}", isExpanded = expanded)
                    }
                }
                "Facturas" -> {
                    facturas.forEach{
                        SubHeaderView(subtitulo = "${it.idFactura} (${it.statusFactura})", onClickItem = onClickItem, visible = expanded)
                        ExpandableView(contenido = "${it.fechaFactura} - $${it.montoFactura} * ${it.idTransaccion}", isExpanded = expanded)
                    }
                }*/
            }
        }
    }
}

@Composable
fun ExpandableContainerView2(subtitulo: String, contenido: Any, onClickItem: () -> Unit, expanded: Boolean) {
    Box(
        modifier = Modifier.wrapContentSize(unbounded = true)
        //.background(Color.White)
    ) {
        Column {
            SubHeaderView(subtitulo = subtitulo, onClickItem = onClickItem, visible = expanded)
            ExpandableView(contenido = "AAA", isExpanded = expanded)
        }
    }
}

@Composable
fun HeaderView(titulo: String, onClickItem: () -> Unit) {
    Box(
        modifier = Modifier
            .background(Institucional3)
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() },
                onClick = onClickItem
            )
            .padding(5.dp)
    ) {
        Text(
            text = titulo,
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.Center)
        )
    }
}

@Composable
fun SubHeaderView(subtitulo: String, onClickItem: () -> Unit, visible: Boolean) {
    val expandTransition = remember {
        expandVertically(
            expandFrom = Alignment.Top,
            animationSpec = tween(300)
        ) + fadeIn(
            animationSpec = tween(300)
        )
    }
    val collapseTransition = remember {
        shrinkVertically(
            shrinkTowards = Alignment.Top,
            animationSpec = tween(300)
        ) + fadeOut(
            animationSpec = tween(300)
        )
    }
    AnimatedVisibility(
        visible = visible,
        enter = expandTransition,
        exit = collapseTransition
    ) {
        Box(
            modifier = Modifier
                .background(Institucional3light)
                .clickable(
                    indication = null, // Removes the ripple effect on tap
                    interactionSource = remember { MutableInteractionSource() }, // Removes the ripple effect on tap
                    onClick = onClickItem
                )
                .padding(10.dp)
        ) {
            Text(
                text = subtitulo,
                fontSize = 17.sp,
                color = Color.White,
                modifier = Modifier
                    .fillMaxWidth()
            )
        }
    }
}

@Composable
fun ExpandableView(contenido: Any, isExpanded: Boolean) {
    val expandTransition = remember {
        expandVertically(
            expandFrom = Alignment.Top,
            animationSpec = tween(300)
        ) + fadeIn(
            animationSpec = tween(300)
        )
    }
    val collapseTransition = remember {
        shrinkVertically(
            shrinkTowards = Alignment.Top,
            animationSpec = tween(300)
        ) + fadeOut(
            animationSpec = tween(300)
        )
    }
    AnimatedVisibility(
        visible = isExpanded,
        enter = expandTransition,
        exit = collapseTransition
    ) {
        Box(modifier = Modifier.padding(15.dp)) {
            Text(
                text = contenido.toString(),
                fontSize = 16.sp,
                fontWeight = FontWeight.Light,
                modifier = Modifier
                    .fillMaxWidth()
            )
        }
    }
}*///