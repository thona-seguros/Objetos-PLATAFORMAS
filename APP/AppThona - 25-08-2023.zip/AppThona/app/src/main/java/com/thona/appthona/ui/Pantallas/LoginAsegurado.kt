package com.thona.appthona.ui.Pantallas

import androidx.compose.runtime.Composable
import com.thona.appthona.Data.WebServices.Modelos.Login
import com.thona.appthona.Funciones.funciones
import com.thona.appthona.ui.Plantillas.ProgressBarLoading
import com.thona.appthona.ui.theme.Login

@Composable
fun Asegurado(
    login: (rol: String, usu: String, cont: String) -> Unit,
    click: (pant: String) -> Unit,
    loadingProgressBar: Boolean,
    loginCorrecto: Boolean,
    respuestaLogin: Login,
    clickMensaje: (usuario: String, idSession: Int) -> Unit
){
    Login(
        rol = "Asegurado",
        iniciarSesion = login ,
        texto1 = "Agente",
        texto2 = "Cliente",
        click = click,
        loadingProgressBar = loadingProgressBar,
        loginCorrecto = loginCorrecto,
        respuestaLogin = respuestaLogin,
        clickMensaje = clickMensaje
    )
}