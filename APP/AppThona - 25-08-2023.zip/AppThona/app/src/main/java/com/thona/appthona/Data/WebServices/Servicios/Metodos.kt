package com.thona.appthona.Data.WebServices.Servicios

import androidx.core.view.accessibility.AccessibilityEventCompat.ContentChangeType
import com.thona.appthona.Data.WebServices.Modelos.Control
import com.thona.appthona.Data.WebServices.Modelos.ModeloCambioPassword
import com.thona.appthona.Data.WebServices.Modelos.ModeloCatalogoParentescos
import com.thona.appthona.Data.WebServices.Modelos.ModeloCierreSesion
import com.thona.appthona.Data.WebServices.Modelos.ModeloDetalleProducto
import com.thona.appthona.Data.WebServices.Modelos.ModeloLogin
import com.thona.appthona.Data.WebServices.Modelos.ModeloMyInformacion
import com.thona.appthona.Data.WebServices.Modelos.ModeloMyProducto
import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

interface Metodos {
    /*@GET("login")
    suspend fun Login(@Query("ROL") ROL: String, @Query("USUARIO") USUARIO: String, @Query("CONTRASENA") CONTRASENA: String): Response<ModeloLogin>*/
    @POST("login")
    suspend fun Login(@Body body: RequestBody): Response<ModeloLogin>

    /*@GET("cambioPassword")
    suspend fun CambioPassword(@Query("Usuario") usuario: String, @Query("Rol") rol: String, @Query("Anterior") anterior: String, @Query("Nueva") nueva: String, @Query("Session") idSession: Int): Response<ModeloCambioPassword>*/
    @POST("cambioPassword")
    suspend fun CambioPassword(@Body body: RequestBody): Response<ModeloCambioPassword>

    /*@GET("cierreSesion")
    suspend fun CierreSesion(@Query("USUARIO") usuario: String, @Query("Session") idSession: Int): Response<ModeloCierreSesion>*/
    @POST("cierreSesion")
    suspend fun CierreSesion(@Body body: RequestBody): Response<ModeloCierreSesion>

    /*@GET("MyInfo")
    suspend fun ConsultaInfo(@Query("Usuario") usuario: String, @Query("Session") idSession: Int): Response<ModeloMyInformacion>*/
    @POST("MyInfo")
    suspend fun ConsultaInfo(@Body body: RequestBody): Response<ModeloMyInformacion>

    /*@GET("MyProduct")
    suspend fun ConsultaProductos(@Query("Usuario") usuario: String, @Query("Session") idSession: Int): Response<ModeloMyProducto>*/
    @POST("MyProduct")
    suspend fun ConsultaProductos(@Body body: RequestBody): Response<ModeloMyProducto>

    /*@GET("DetProducts")
    suspend fun DetalleProducto (@Query("Usuario") USUARIO: String, @Query("idPoliza") idPoliza: String, @Query("Session") idSession: Int): Response<ModeloDetalleProducto>*/
    @POST("DetProducts")
    suspend fun DetalleProducto(@Body body: RequestBody): Response<ModeloDetalleProducto>

    @POST("UpdMyInfo")
    suspend fun actualizaInfo(@Body body: RequestBody): Response<ModeloCambioPassword>

    @GET("catParentesco")
    suspend fun CatalogoParentescos(): Response<ModeloCatalogoParentescos>
}