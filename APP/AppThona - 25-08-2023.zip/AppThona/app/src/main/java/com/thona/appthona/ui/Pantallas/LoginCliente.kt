package com.thona.appthona.ui.Pantallas

import androidx.compose.runtime.Composable
import com.thona.appthona.Data.WebServices.Modelos.Login
import com.thona.appthona.ui.theme.Login

@Composable
fun Cliente(
    login: (rol: String, usu: String, cont: String) -> Unit,
    click: (pant: String) -> Unit,
    loadingProgressBar: Boolean,
    loginCorrecto: Boolean,
    respuestaLogin: Login,
    clickmensaje: (opc: String, idSession: Int) -> Unit
){
    Login(
        rol = "Cliente",
        iniciarSesion = login ,
        texto1 = "Agente",
        texto2 = "Asegurado",
        click = click,
        loadingProgressBar = loadingProgressBar,
        loginCorrecto = loginCorrecto,
        respuestaLogin = respuestaLogin,
        clickMensaje = clickmensaje
    )
}