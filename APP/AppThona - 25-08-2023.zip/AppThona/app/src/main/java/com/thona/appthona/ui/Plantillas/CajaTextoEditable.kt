package com.thona.appthona.ui.Plantillas

import android.widget.Toast
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.thona.appthona.Constantes.Institucional1
import com.thona.appthona.Constantes.Institucional2
import java.util.regex.Pattern

@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun cajaTextoEditable(modifier: Modifier, dato: String, etiqueta: String, placeholder: String, puedeEditar: Boolean, tipoTeclado: KeyboardType): String{

    var estaEditando by rememberSaveable { mutableStateOf(value = false) }

    var texto by rememberSaveable { mutableStateOf(value = dato) }
    var edicion by rememberSaveable { mutableStateOf(value = false) }

    var regreso = ""

    val keyboardController = LocalSoftwareKeyboardController.current

    var datoValido by rememberSaveable { mutableStateOf(value = true) }

    Column{
        OutlinedTextField(
            value = texto,
            onValueChange = {
                if(edicion){
                    if(etiqueta=="Número de teléfono*") {
                        if(it.length <= 10){
                            texto = it
                        }
                    } else{
                    texto = it
                    }
                } else{
                    texto = dato
                }; estaEditando = diferente(it,dato); datoValido = validaDatos(etiqueta = etiqueta, texto = texto)
            },
            modifier = modifier,
            label = { Text(text = etiqueta) },
            placeholder = { Text(text = placeholder) },
            trailingIcon = {
                if(puedeEditar){
                    IconButton(
                        onClick = {
                            edicion = !edicion
                        },
                        enabled = true
                    ){
                        if(edicion){
                            Icon(
                                imageVector = Icons.Filled.Cancel,
                                contentDescription = "Cancelar"
                            )
                        }
                        else{
                            Icon(
                                imageVector = Icons.Filled.Edit,
                                contentDescription = "Editar"
                            )
                        }
                    }
                }
            },
            //enabled = edicion,
            readOnly = !puedeEditar,
            //readOnly = !edicion ,
            singleLine = true,
            isError = !datoValido,
            keyboardOptions = KeyboardOptions(
                keyboardType = tipoTeclado
            ),
            /*keyboardActions = if(edicion){
                KeyboardActions(
                    keyboardController?.show()
                )
            }else{
                KeyboardActions(
                    keyboardController?.hide()
                )
            },*/
            shape = CircleShape,
            colors = if(!edicion){
                OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Institucional2
                )
            } else{
                OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Institucional1
                )
            }
        )
        if(puedeEditar){
            when(etiqueta){
                "Email*" -> {
                    val textoApoyo = "No es un correo valido."
                    if(estaEditando){
                        Text(
                            text = if(datoValido) "*Dato obligatorio" else textoApoyo,
                            color = if(datoValido) Color.LightGray else Color.Red,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(start = 25.dp)
                        )
                    }
                    else{
                        Text(
                            text = "*Obligatorio",
                            modifier = Modifier.padding(start = 25.dp),
                            fontSize = 11.sp,
                            color = Color.LightGray
                        )
                    }
                }
                "Número de teléfono*" -> {
                    val textoApoyo = "No es un telefono valido. (Debe ser de 10 digitos)"
                    Box(modifier = Modifier.fillMaxWidth()){
                        Row (Modifier.align(Alignment.CenterStart)){
                            if(estaEditando){
                                Text(
                                    text = if(validaTelefono(texto)) "*Dato obligatorio" else textoApoyo,
                                    color = if(validaTelefono(texto)) Color.LightGray else Color.Red,
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(start = 25.dp)
                                )
                            }
                            else{
                                Text(
                                    text = "*Obligatorio",
                                    modifier = Modifier.padding(start = 25.dp),
                                    fontSize = 11.sp,
                                    color = Color.LightGray
                                )
                            }
                        }
                        Row (Modifier.align(Alignment.CenterEnd)){
                            Text(
                                text = "${texto.length}/10",
                                color = if(validaTelefono(texto)) Color.LightGray else Color.Red,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(end = 25.dp)
                            )
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(5.dp))
        }
    }
    if(!estaEditando){
        regreso = dato
    }else if(datoValido){
        regreso = texto
    }
    return regreso
}

fun diferente(texto: String, textoAnterior: String): Boolean{
    println("Dato nuevo: $texto -- dato anteior: $textoAnterior")

    return texto!=textoAnterior
}

fun validaTelefono(datoTelefono: String): Boolean{
    var valido = false
    if(datoTelefono.length == 10 && !datoTelefono.startsWith("0")){
        valido = true
    }
    return valido
}

fun validaMail(datoMail: String) =
    Pattern.compile(
        "^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$",
        Pattern.CASE_INSENSITIVE
    ).matcher(datoMail).find()

fun validaDatos(etiqueta: String, texto: String): Boolean{
    var valido = false
    when(etiqueta){
        "Email*" -> {
            valido = validaMail(texto)
        }
        "Número de teléfono*" -> {
            valido = validaTelefono(texto)
        }
    }
    return valido
}