package com.thona.appthona.ui.Plantillas.MenuColapsable

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.Mail
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.thona.appthona.Constantes.Institucional2
import com.thona.appthona.Data.WebServices.Modelos.DataModel
import com.thona.appthona.Data.WebServices.Modelos.DetalleProducto
import com.thona.appthona.Data.WebServices.Modelos.facturaItem
import com.thona.appthona.ui.theme.Institucional1
import com.thona.appthona.ui.theme.Institucional3

/*object Data {
    val factura = "Datos de cada factura"
    val titulo = "Facturas"

    var items = arrayListOf(
        DataModel(
            titulo = titulo,
            contenido = factura
        ),
        DataModel(
            "Beneficiarios",
            "Datos de beneficiarios"
        ),
        DataModel(
            "Coberturas",
            "Datos de cada cobertura"
        )
    )
}*/

@Composable
fun Fact(detallePoliza: DetalleProducto){
    var colorStatus = Institucional1

    detallePoliza.facturas.forEach{
        if(it.statusFactura=="PAG"){
            colorStatus = Color.Green
        }
        else if(it.statusFactura=="ANU"){
            colorStatus = Color.Red
        }
        else if(it.statusFactura=="PEND"){
            colorStatus = Color.Yellow
        }
        Row (modifier = Modifier.fillMaxWidth(),horizontalArrangement = Arrangement.Center) {
            Spacer(modifier = Modifier.height(3.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Row {
                    Text(text = "No. Factura")
                }
                Row {
                    Text(text = it.idFactura.toString())
                }
                Spacer(modifier = Modifier.height(5.dp))
                Row {
                    Text(text = "Estatus")
                }
                Row {
                    Text(
                        text = it.statusFactura,
                        color = colorStatus
                    )
                }
            }
            Spacer(modifier = Modifier.width(5.dp))
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Row {
                    Text(text = "  Importe  ")
                }
                Row {
                    Text(text = it.montoFactura.toString())
                }
                Spacer(modifier = Modifier.height(5.dp))
                Row {
                    Text(text = "Fecha")
                }
                Row {
                    Text(text = it.fechaFactura)
                }
            }
            Column (horizontalAlignment = Alignment.CenterHorizontally) {
                IconButton(onClick = { /*TODO*/ }) {
                    Icon(modifier = Modifier, imageVector = Icons.Outlined.Download, contentDescription = "", tint = Institucional2)
                }
                IconButton(onClick = { /*TODO*/ }) {
                    Icon(modifier = Modifier, imageVector = Icons.Outlined.Mail, contentDescription = "", tint = Institucional2)
                }
            }
            Spacer(modifier = Modifier.height(3.dp))
        }
        Divider(color = Institucional3, thickness = 0.5.dp)
    }
}