package com.thona.appthona.ui.Plantillas.MenuColapsable

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.ArrowDropDown
import androidx.compose.material.icons.outlined.ArrowDropUp
import androidx.compose.material.icons.outlined.ArrowForward
import androidx.compose.material.icons.outlined.ArrowForwardIos
import androidx.compose.material.icons.outlined.ArrowUpward
import androidx.compose.material.icons.outlined.KeyboardArrowUp
import androidx.compose.material.icons.outlined.Minimize
import androidx.compose.material.icons.outlined.ModeEdit
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.thona.appthona.Constantes.Institucional1
import com.thona.appthona.Constantes.Institucional2
import com.thona.appthona.Constantes.Institucional3light1
import com.thona.appthona.Constantes.Institucional3light2
import com.thona.appthona.Constantes.ThonaRojo
import com.thona.appthona.Constantes.ThonaVerde
import com.thona.appthona.Data.WebServices.Modelos.DetalleBeneficiarioItem
import com.thona.appthona.Data.WebServices.Modelos.DetalleCoberturaItem
import com.thona.appthona.Data.WebServices.Modelos.DetalleProducto
import com.thona.appthona.Data.WebServices.Modelos.facturaItem
import com.thona.appthona.Funciones.funciones
import com.thona.appthona.ui.theme.Institucional3

@Composable
fun ListadoMenu(
    clicKEdicion: () -> Unit,
    viewModel: ExpandableListViewModel,
    datos: DetalleProducto
) {
    val itemIds by viewModel.itemIds.collectAsState()
    val menus = datos.detalleMenu
    LazyColumn(modifier = Modifier.padding()){
        itemsIndexed(menus){ index, item ->
            Column {
                Box(modifier = Modifier) {
                    TituloViewer(titulo = item.tituloMenu, onClickItem = { viewModel.onItemClicked(index) }, abierto = itemIds.contains(index))
                }
                Subtitulo(
                    clicKEdicion = clicKEdicion,
                    itemIds = itemIds,
                    titulo = item.tituloMenu,
                    index = index,
                    datos = datos
                )
            }
        }
    }
}

@Composable
fun Subtitulo(clicKEdicion: () -> Unit, itemIds: List<Int>, titulo: String, index: Int, datos: DetalleProducto) {
    val coberturas = datos.detalleCoberturas
    val beneficiarios = datos.detalleBeneficiarios
    val facturas = datos.facturas
    //var conta: Int
    when(titulo) {
        "Coberturas" -> {
            //conta = 0
            coberturas.forEach{
                ContenidoCoberturas(
                    clicKEdicion = clicKEdicion,
                    itemIds = itemIds,
                    viewModel = ExpandableListViewModel(),
                    cobertura = it,
                    index = index,
                    //conta = conta,
                    //abierto = itemIds.contains(index)
                )
                //conta++
            }
        }
        "Beneficiarios" -> {
            //conta = 0
            beneficiarios.forEach{
                ContenidoBeneficiarios(
                    clicKEdicion = clicKEdicion,
                    itemIds = itemIds,
                    viewModel = ExpandableListViewModel(),
                    beneficiario = it,
                    index = index,
                    //conta = conta
                )
            //    conta++
            }
        }
        "Facturas" -> {
            //conta = 0
            facturas.forEach{
                ContenidoFacturas(
                    clicKEdicion = clicKEdicion,
                    itemIds = itemIds,
                    viewModel = ExpandableListViewModel(),
                    factura = it,
                    index = index,
                    //conta = conta
                )
                //conta++
            }
        }
    }
}

@Composable
fun ContenidoCoberturas(clicKEdicion: () -> Unit, itemIds: List<Int>, viewModel: ExpandableListViewModel, cobertura: DetalleCoberturaItem, index: Int){
    val itemIds2 by viewModel.itemIds2.collectAsState()
    Box(modifier = Modifier.fillMaxSize()){
        Column {
            SubTituloViewer(
                subtitulo1 = cobertura.codigoCobertura,
                subtitulo2 = "",
                color = Color.White,
                onClickItem = { viewModel.onItemClicked2(cobertura.codigoCobertura) },
                visible = itemIds.contains(index),
                abierto = itemIds2.contains(cobertura.codigoCobertura)
            )
            var visible2 = itemIds2.contains(cobertura.codigoCobertura)
            if(!itemIds.contains(index)){
                visible2 = false
                viewModel.limpia2(cobertura.codigoCobertura)
            }
            ExpandableView(
                clicKEdicion = clicKEdicion,
                seccion = "Coberturas",
                contenido = "${cobertura.descripcionCobertura} - $${cobertura.sumaAsegurada}",
                isExpanded = visible2
            )
        }
    }
}

@Composable
fun ContenidoBeneficiarios(clicKEdicion: () -> Unit, itemIds: List<Int>, viewModel: ExpandableListViewModel, beneficiario: DetalleBeneficiarioItem, index: Int){
    val itemIds2 by viewModel.itemIds2.collectAsState()
    Box(modifier = Modifier.fillMaxSize()){
        Column {
            SubTituloViewer(
                subtitulo1 = beneficiario.nombreBeneficiario,
                subtitulo2 = "",
                color = Color.White,
                onClickItem = { viewModel.onItemClicked2(beneficiario.nombreBeneficiario) },
                visible = itemIds.contains(index),
                abierto = itemIds2.contains(beneficiario.nombreBeneficiario)
            )
            var visible2 = itemIds2.contains(beneficiario.nombreBeneficiario)
            if(!itemIds.contains(index)){
                visible2 = false
                viewModel.limpia2(beneficiario.nombreBeneficiario)
            }
            ExpandableView(
                clicKEdicion = clicKEdicion,
                seccion = "Beneficiarios",
                contenido = "${beneficiario.parentescoBeneficiario} - ${beneficiario.porcentajeBeneficiario}",
                isExpanded = visible2
            )
        }
    }
}

@Composable
fun ContenidoFacturas(clicKEdicion: () -> Unit, itemIds: List<Int>, viewModel: ExpandableListViewModel, factura: facturaItem, index: Int){
    val itemIds2 by viewModel.itemIds2.collectAsState()
    Box(modifier = Modifier.fillMaxSize()){
        Column {
            /*TODO QUITAR EL WHEN Y RECIBIR EL ESTATUS COMPLETO*/
            var estatus = ""
            var color = Color.White
            when(factura.statusFactura){
                "PAG" ->{
                    estatus = "PAGADA"
                    color = ThonaVerde
                }
                "ANU"->{
                    estatus = "ANULADA"
                    color = ThonaRojo
                }
            }
            /*TODO DESCOMENTAR CUANDO SE RECIBA EL DATO COMPLETO*///SubTituloViewer(subtitulo = "${factura.idFactura} - ${factura.statusFactura}", onClickItem = { viewModel.onItemClicked2(factura.idFactura.toString()) }, visible = itemIds.contains(index), abierto = itemIds2.contains(factura.idFactura.toString()))
            SubTituloViewer(
                subtitulo1 = "${factura.idFactura} - ",
                subtitulo2 = estatus,
                color = color,
                onClickItem = { viewModel.onItemClicked2(factura.idFactura.toString()) },
                visible = itemIds.contains(index),
                abierto = itemIds2.contains(factura.idFactura.toString())
            )
            var visible2 = itemIds2.contains(factura.idFactura.toString())
            if(!itemIds.contains(index)){
                visible2 = false
                viewModel.limpia2(factura.idFactura.toString())
            }
            ExpandableView(
                clicKEdicion = clicKEdicion,
                seccion = "Facturas",
                contenido = "${factura.fechaFactura} - \$${factura.montoFactura} RECIBO: ${factura.idRecibo} (\$${factura.cuotaFactura}) - Transacción no. ${factura.idTransaccion}",
                isExpanded = visible2
            )
        }
    }
}

@Composable
fun TituloViewer(titulo: String, onClickItem: () -> Unit, abierto: Boolean) {
    Box(
        modifier = Modifier
            .background(Institucional3light1)
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() },
                onClick = onClickItem
            )
            .padding(5.dp)
    ) {
        Text(
            text = titulo,
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.Center)
        )
        if(abierto){
            Icon(
                modifier = Modifier.align(Alignment.TopEnd),
                imageVector = Icons.Outlined.Minimize,
                contentDescription = "",
                tint = Color.White
            )
        }
        else{
            Icon(
                modifier = Modifier.align(Alignment.TopEnd),
                imageVector = Icons.Outlined.Add,
                contentDescription = "",
                tint = Color.White)
        }
    }
    Divider(color = Color.White, thickness = 0.5.dp)
}

@Composable
fun SubTituloViewer(subtitulo1: String, subtitulo2: String, color: Color, onClickItem: () -> Unit, visible: Boolean, abierto: Boolean) {
    val expandTransition = remember {
        expandVertically(
            expandFrom = Alignment.Top,
            animationSpec = tween(300)
        ) + fadeIn(
            animationSpec = tween(300)
        )
    }
    val collapseTransition = remember {
        shrinkVertically(
            shrinkTowards = Alignment.Top,
            animationSpec = tween(300)
        ) + fadeOut(
            animationSpec = tween(300)
        )
    }
    AnimatedVisibility(
        visible = visible,
        enter = expandTransition,
        exit = collapseTransition
    ) {
        Box(
            modifier = Modifier
                .background(Institucional3light2)
                .clickable(
                    indication = null,
                    interactionSource = remember { MutableInteractionSource() },
                    onClick = onClickItem
                )
                .padding(10.dp)
        ) {
            Row (modifier = Modifier
                .fillMaxWidth()){
                Text(
                    text = subtitulo1,
                    fontSize = 17.sp,
                    color = Color.White,
                    //modifier = Modifier
                    //    .fillMaxWidth()
                )
                Text(
                    text = subtitulo2,
                    fontSize = 17.sp,
                    color = color,
                    //modifier = Modifier
                    //    .fillMaxWidth()
                )
            }
            if(abierto){
                Icon(
                    modifier = Modifier.align(Alignment.TopEnd),
                    imageVector = Icons.Outlined.ArrowDropUp,
                    contentDescription = "",
                    tint = Color.White
                )
            }
            else{
                Icon(
                    modifier = Modifier.align(Alignment.TopEnd),
                    imageVector = Icons.Outlined.ArrowDropDown,
                    contentDescription = "",
                    tint = Color.White
                )
            }
        }
    }
}

@Composable
fun ExpandableView(clicKEdicion: () -> Unit, seccion: String, contenido: Any, isExpanded: Boolean) {
    val expandTransition = remember {
        expandVertically(
            expandFrom = Alignment.Top,
            animationSpec = tween(300)
        ) + fadeIn(
            animationSpec = tween(300)
        )
    }
    val collapseTransition = remember {
        shrinkVertically(
            shrinkTowards = Alignment.Top,
            animationSpec = tween(300)
        ) + fadeOut(
            animationSpec = tween(300)
        )
    }
    AnimatedVisibility(
        visible = isExpanded,
        enter = expandTransition,
        exit = collapseTransition
    ) {
        /*val modifier = if(seccion == "Beneficiarios"){
            Modifier
                .clickable(
                    indication = null,
                    interactionSource = remember { MutableInteractionSource() },
                    onClick = { funciones().editaBeneficiario(1) }
                )
                .padding(10.dp)
        }else{
            Modifier.padding(15.dp)
        }*/
        Box(modifier = Modifier.padding(15.dp).fillMaxWidth()) {
            Text(
                text = contenido.toString(),
                fontSize = 16.sp,
                fontWeight = FontWeight.Light,
                modifier = Modifier
                    //.fillMaxWidth()
            )
            if(seccion == "Beneficiarios"){
                Icon(
                    modifier = Modifier.align(Alignment.CenterEnd).clickable(onClick = clicKEdicion) ,
                    imageVector = Icons.Outlined.ModeEdit,
                    contentDescription = "",
                    tint = ThonaVerde
                )
                /*IconButton(
                    onClick = clicKEdicion,
                ) {

                }*/
            }
        }
    }
}