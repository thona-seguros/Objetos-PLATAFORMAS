package com.thona.appthona.ui.Plantillas

import androidx.compose.runtime.Composable

@Composable
fun Drawer(){
    Drawer()
}