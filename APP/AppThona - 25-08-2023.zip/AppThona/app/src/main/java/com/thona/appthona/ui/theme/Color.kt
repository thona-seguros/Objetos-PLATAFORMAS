package com.thona.appthona.ui.theme

import androidx.compose.ui.graphics.Color

val Purple200 = Color(0xFFBB86FC)
val Purple500 = Color(0xFF6200EE)
val Purple700 = Color(0xFF3700B3)
val Teal200 = Color(0xFF03DAC5)

val Institucional1 = com.thona.appthona.Constantes.Institucional1
val Institucional2 = com.thona.appthona.Constantes.Institucional2
val Institucional3 = com.thona.appthona.Constantes.Institucional3