package com.thona.appthona.Ubicacion

import android.Manifest.permission.ACCESS_FINE_LOCATION
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.core.app.ActivityCompat.requestPermissions
import androidx.core.app.ActivityCompat.shouldShowRequestPermissionRationale
import androidx.core.content.ContextCompat
import com.google.android.gms.common.internal.GetServiceRequest
import com.google.android.gms.location.*
import com.thona.appthona.ui.Plantillas.AlertaDialogo
import com.thona.appthona.ui.theme.Institucional1

private lateinit var fusedLocationClient: FusedLocationProviderClient

@Composable
fun permisoUbi(
    contexto: Context,
    actividad: Activity,
    clicMensaje: (opcion: Int) -> Unit,
): Boolean{
    fusedLocationClient = LocationServices.getFusedLocationProviderClient(actividad)
    var permiso = false
    val tieneDatos = remember { mutableStateOf(true)  }
    when {
        ContextCompat.checkSelfPermission(
            contexto,
            ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED -> {
            println("Permiso concedido")
            permiso = true

            fusedLocationClient.lastLocation
                .addOnSuccessListener { location : Location? ->
                    println("UBICACIÓN: $location")
                    if (location?.latitude != null) {
                        tieneDatos.value = true
                        //permiso = true
                        println("UBICACIÓN latitud: ${location.latitude}")
                        println("UBICACIÓN longitud: ${location.longitude}")
                        println("UBICACIÓN accury: ${location.accuracy}")
                        println("UBICACIÓN altitud: ${location.altitude}")
                        println("UBICACIÓN bearing: ${location.bearing}")
                        println("UBICACIÓN speed: ${location.speed}")
                        println("UBICACIÓN extras: ${location.extras.toString()}")
                        println("UBICACIÓN provider: ${location.provider}")

                        println("DISPOSITIVO")
                        //val dispositivo = androidx.compose
                    }
                    else{
                        tieneDatos.value = false
                    }
                }
            println("Tiene datos?: ${tieneDatos.value}")
            if(!tieneDatos.value){
                AlertaDialogo(
                    titulo = "Habilita tu ubicación",
                    mensaje = "Para poder continuar, es necesario tener activo el servicio de ubicación.",
                    clicAceptar = { clicMensaje(2) },
                    clicCancelar = { /*TODO*/ },
                    colorRol = Institucional1,
                    cantidadBotones = 1
                )
            }
        }
        shouldShowRequestPermissionRationale(actividad,ACCESS_FINE_LOCATION) -> {
            AlertaDialogo(
                titulo = "Concede permisos",
                mensaje = "Debes otorgar acceso a tu ubicación para iniciar sesión.",
                clicAceptar =  {clicMensaje(1)},
                clicCancelar = { clicMensaje(2) },
                colorRol = Institucional1,
                cantidadBotones = 2
            )
            println("Permiso no concedido")
    }
        else -> {
            println("Pide permiso")
            pidePermiso(actividad)

        }
    }
    return permiso
}

fun pidePermiso(
    actividad: Activity
){
    requestPermissions(
        actividad,
        arrayOf(
            ACCESS_FINE_LOCATION
        ),
        1
    )
}

/*fun locacion(){
    locationCallback = object : LocationCallback() {
        override fun onLocationResult(locationResult: LocationResult?) {
            locationResult ?: return
            for (location in locationResult.locations){
                // Update UI with location data
                // ...
                println("DATOS DE UNA UBICACION OBTENIDA: $location")
            }
        }
    }
}*/