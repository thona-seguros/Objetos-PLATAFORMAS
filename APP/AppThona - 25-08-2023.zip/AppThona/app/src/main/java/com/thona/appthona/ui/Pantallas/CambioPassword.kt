package com.thona.appthona.ui.Pantallas

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.thona.appthona.Constantes.Institucional1
import com.thona.appthona.Constantes.Institucional2
import com.thona.appthona.Constantes.Institucional3
import com.thona.appthona.Data.WebServices.Modelos.Login
import com.thona.appthona.Funciones.funciones
import com.thona.appthona.ui.Plantillas.AlertaDialogo
import com.thona.appthona.ui.Plantillas.CampoContraseña
import com.thona.appthona.ui.Plantillas.ProgressBarLoading

@Composable
fun CambioPassword(
    rol: String,
    usuario: Login,
    cambiarContrasena: (usuario: String, rol: String, passAnterior: String, passNueva: String, idSession: Int) -> Unit,
    loadingProgressBar: Boolean,
    cambioCorrecto: Boolean,
    mensajeRespuesta: String,
    clicMensaje: (opcion: Int) -> Unit
){
    var Color1 = Institucional1
    when(usuario.Items.Rol){
        "CLIENTE" -> { Color1 = Institucional1 }
        "ASEGURADO" -> { Color1 = Institucional3 }
        "AGENTE" -> { Color1 = Institucional2 }
    }

    var passwordAnterior by rememberSaveable { mutableStateOf(value = "") }
    var passwordNuevo by rememberSaveable { mutableStateOf(value = "") }
    var passwordConfirmacion by rememberSaveable { mutableStateOf(value = "") }

    var passwordVisible1 by rememberSaveable { mutableStateOf(false) }
    var passwordVisible2 by rememberSaveable { mutableStateOf(false) }
    var passwordVisible3 by rememberSaveable { mutableStateOf(false) }

    var esIgual by rememberSaveable { mutableStateOf(false) }

    val isValidate by derivedStateOf { passwordAnterior.isNotBlank() && passwordNuevo.isNotBlank() && passwordConfirmacion.isNotBlank() && esIgual}
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "Para realizar el cambio de contraseña, ingresa tu contraseña actual, tu nueva contraseña y confirma tu nueva contraseña.",
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
            )
        }
        Spacer(Modifier.height(15.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            CampoContraseña(
                textValue = passwordAnterior,
                onValueChange = {passwordAnterior = it},
                onClickButton = { passwordVisible1 = !passwordVisible1 },
                texto = "Contraseña actual",
                tipo = KeyboardType.Password,
                passwordVisible = passwordVisible1,
                accionGo = {  },
                isLoading = loadingProgressBar
            )
        }
        Spacer(Modifier.height(5.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            CampoContraseña(
                textValue = passwordNuevo,
                onValueChange = {passwordNuevo = it; esIgual = igual(passwordNuevo,passwordConfirmacion) },
                onClickButton = { passwordVisible2 = !passwordVisible2 },
                texto = "Nueva contraseña",
                tipo = KeyboardType.Password,
                passwordVisible = passwordVisible2,
                accionGo = {  },
                isLoading = loadingProgressBar
            )
        }
        Spacer(Modifier.height(5.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            CampoContraseña(
                textValue = passwordConfirmacion,
                onValueChange = {passwordConfirmacion = it; esIgual = igual(passwordNuevo,passwordConfirmacion)},
                onClickButton = { passwordVisible3 = !passwordVisible3 },
                texto = "Confirma tu nueva contraseña",
                tipo = KeyboardType.Password,
                passwordVisible = passwordVisible3,
                accionGo = {  },
                isLoading = loadingProgressBar
            )
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Button(
                onClick = {
                    usuario.Items.CodUsuario?.let {
                        usuario.Items.Rol?.let {
                                it1 ->
                            cambiarContrasena(it, it1,passwordAnterior,passwordNuevo, usuario.session.idSession)
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(
                        start = 20.dp,
                        end = 20.dp
                    ),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 5.dp),
                enabled = isValidate,
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(
                    Color1
                )
            ) {
                Text(
                    text = "Aceptar",
                    fontSize = 20.sp,
                    color = Color.White
                )
            }
        }
        if(!esIgual && passwordConfirmacion.isNotBlank() && passwordNuevo.isNotBlank()){
            Text(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                text = "La nueva contraseña y la confirmación no coinciden.",
                fontSize = 10.sp,
                color = Color.Red
            )
        }
        if(!cambioCorrecto){
            Spacer(Modifier.height(25.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = mensajeRespuesta,
                    fontSize = 15.sp,
                    color = Color.Red
                )
            }
        } else{
            //openDialog.value = true
            AlertaDialogo(
                //muestraDialogo = openDialog,
                titulo = "Cambio de contraseña",
                mensaje = "La contraseña ha sido actualizada con éxito",
                clicAceptar = {clicMensaje(1)},
                clicCancelar = {},
                colorRol = Color1,
                cantidadBotones = 1
            )
        }

        //if(openDialog.value){
         //
           // openDialog.value = !openDialog.value
        //}

        ProgressBarLoading(isLoading = loadingProgressBar)
    }
}

fun igual(texto1: String, texto2: String): Boolean{
    return texto1 == texto2
}