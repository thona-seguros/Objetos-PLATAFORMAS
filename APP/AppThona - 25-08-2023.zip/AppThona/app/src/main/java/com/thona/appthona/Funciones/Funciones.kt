package com.thona.appthona.Funciones

import android.util.Log
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.thona.appthona.Data.WebServices.Modelos.*
import com.thona.appthona.Data.WebServices.Servicios.ConexionRetrofit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

class funciones: ViewModel(){
    val opcionMensaje = mutableIntStateOf(value = 0)

    val progressBar = mutableStateOf(value = false)
    var respuestaServicio = mutableStateOf(value = false)
    val MensajeRespuesta = mutableStateOf(value = "")
    //SELECCIÓN DE ROL
    val rolLogin = mutableStateOf(value = "")
    //SERVICIO DE LOGIN
    val respuestaLogin = mutableStateOf(value = Login(SesionItem(0),LoginItem("","","",""),Control("","")))
    val loginCorrecto = mutableStateOf(value = false)
    //SELECCION DEL MENU
    val seleccionMenu = mutableStateOf("")
    //SERVICIO DE CAMBIO DE CONTRASEÑA
    val respuestaCambioContrasena = mutableStateOf(value = Control("",""))
    val cambioCorrecto = mutableStateOf(value = false)
    //ESTADO DE LA SESIÓN
    val sesionIniciada = mutableStateOf(value = false)
    //CONSULTA DE MI INFORMACIÓN
    val miInformacion = mutableStateOf(value = InfoItem("","","","","",
        listOf(telsItem(0,"",0)), listOf(emailsItem("","",0)),"",0))
    //CONSULTA DE PRODUCTOS
    val misProductos = mutableStateOf(value = MyProducto(idUnicoItem(""), listOf(MyProdcutoItem("","","","","")),
        Control("","")))
    //DETALLES DE PRODUCTO
    val detallesDePoliza = mutableStateOf(value = DetalleProducto(DetalleProductoItem("","","","","","","","","","",""),
        listOf(DetalleMenuItem("",0)),
        listOf(DetalleCoberturaItem("","","")),
        listOf(DetalleBeneficiarioItem("",0,"")),
        listOf(facturaItem(0,"","",0.0,"",0,0,"")),
        Control("","")))
    //CATALOGO DE PARENTESCOS
    val catalogoParentescos = mutableStateOf(value = listOf(ParentescoItem("","")))
    //ACTUALIZA INFORMACIÓN
    val actualizoInfo = mutableStateOf(value = false)

    val seleccionoPoliza = mutableStateOf(value = false)

    val seleccionoBeneficiario = mutableStateOf(value = false)

    val agregaEspacioBeneficiario = mutableStateOf(value = false)

    private val loginRequestLiveData = MutableLiveData<Boolean>()
    //REINICIO DE VARIABLES
    fun Reiniciar(){
        rolLogin.value = ""
        respuestaLogin.value = Login(SesionItem(0),LoginItem("","","",""),Control("",""))
    }
    //SELECCIÓN DE ROL
    fun SelecRol(rol: String){
        progressBar.value = true
        rolLogin.value = rol
        progressBar.value = false
    }
    //CONEXIÓN PARA LOGIN
    fun Conexion(rol: String, usuario: String, contra: String){
        val jsonObject = JSONObject()
        jsonObject.put("Usuario",usuario)
        jsonObject.put("Contrasena",contra)
        jsonObject.put("Rol",rol)

        val jsonObjectString = jsonObject.toString()

        val requestBody = jsonObjectString.toRequestBody("application/json".toMediaTypeOrNull())

        viewModelScope.launch(Dispatchers.IO) {
            try {
                progressBar.value = true
                val authService = ConexionRetrofit.getAuthService()
                //val responseService = authService.Login(rol,usuario,contra)
                val responseService = authService.Login(requestBody)
                if (responseService.isSuccessful) {
                    respuestaServicio.value = true
                    delay(1500L)
                    respuestaLogin.value = responseService.body()!!.Login.copy()
                    //loginMensaje.value = respuestaLogin.value.Control.TextoRespuesta

                    if(respuestaLogin.value.Control.NumeroRespuesta == "1"){
                        loginCorrecto.value = true
                        respuestaLogin.value.Items.CodUsuario?.let { consultaInformacion(it, respuestaLogin.value.session.idSession) }
                        respuestaLogin.value.Items.CodUsuario?.let { consultaProductos(it,respuestaLogin.value.session.idSession) }
                        sesionIniciada.value = true
                    }
                } else {
                    responseService.errorBody()?.let { error ->
                        println("ERROR EN CONECTAR CON SERVICIO DE LUGARES OCUPADOS")
                        respuestaLogin.value = Login(SesionItem(0),LoginItem("","","",""),Control("88","Error al ejecutar el servicio"))
                        delay(1500L)
                        error.close()
                    }
                }
                loginRequestLiveData.postValue(responseService.isSuccessful)
                progressBar.value = false
            } catch (e: Exception) {
                Log.d("LOGIN", "Error DE CONEXIÓN", e)
                respuestaLogin.value = Login(SesionItem(0),LoginItem("","","",""),Control("99","No se realizó la conexión, verifica la conectividad."))
                progressBar.value = false
            }
        }
    }
    fun SeleccionMenuTop(opcion: String){
        progressBar.value = true
        seleccionMenu.value = opcion
        progressBar.value = false
    }
    fun CambioContrasena (usuario: String, rol: String, anterior: String, nueva: String, session: Int){
        val jsonObject = JSONObject()
        jsonObject.put("Usuario",usuario)
        jsonObject.put("Rol",rol)
        jsonObject.put("Anterior",anterior)
        jsonObject.put("Nueva",nueva)
        jsonObject.put("Session",session)

        val jsonObjectString = jsonObject.toString()

        val requestBody = jsonObjectString.toRequestBody("application/json".toMediaTypeOrNull())
        viewModelScope.launch(Dispatchers.IO) {
            try {
                progressBar.value = true
                val authService = ConexionRetrofit.getAuthService()
                //val responseService = authService.CambioPassword(usuario,rol,anterior,nueva, session)
                val responseService = authService.CambioPassword(requestBody)
                if (responseService.isSuccessful) {
                    respuestaServicio.value = true
                    delay(1500L)
                    MensajeRespuesta.value = responseService.body()!!.CambioPassword.Control.TextoRespuesta
                    respuestaCambioContrasena.value = responseService.body()!!.CambioPassword.Control.copy()

                    cambioCorrecto.value = respuestaCambioContrasena.value.NumeroRespuesta == "1"
                } else {
                    responseService.errorBody()?.let { error ->
                        println("ERROR EN CONECTAR CON SERVICIO DE LUGARES OCUPADOS")
                        //respuestaCambioContrasena.value =
                        MensajeRespuesta.value = "Error al ejecutar el servicio"
                        delay(1500L)
                        error.close()
                    }
                }
                loginRequestLiveData.postValue(responseService.isSuccessful)
                progressBar.value = false
            } catch (e: Exception) {
                Log.d("Cambio password", "Error DE CONEXIÓN", e)
                //respuestaLogin.value = Login(LoginItem("","","",""),Control("99","No se realizó la conexión, verifica la conectividad."))
                MensajeRespuesta.value = "No se realizó la conexión, verifica la conectividad."
                progressBar.value = false
            }
        }
    }

    fun cierraSesion (usuario: String, session: Int) {
        val jsonObject = JSONObject()
        jsonObject.put("Usuario",usuario)
        jsonObject.put("Session",session)

        val jsonObjectString = jsonObject.toString()

        val requestBody = jsonObjectString.toRequestBody("application/json".toMediaTypeOrNull())
        viewModelScope.launch(Dispatchers.IO) {
            try {
                progressBar.value = true
                val authService = ConexionRetrofit.getAuthService()
                //val responseService = authService.CierreSesion(usuario,session)
                val responseService = authService.CierreSesion(requestBody)

                if (responseService.isSuccessful){
                    respuestaServicio.value = true
                    delay(1500L)
                    //MensajeRespuesta.value = responseService.body()!!.CierraSesion.Control.TextoRespuesta

                    sesionIniciada.value = false
                    Reiniciar()
                    loginCorrecto.value = false
                    //TODO GUARDAR RESPUESTA DEL CIERRE DE SESION
                    //TODO CREAR Y ACTUALIZAR VARIABLE DE SESION CERRADA
                    progressBar.value = false
                }
                progressBar.value = false
            } catch (e: Exception) {
                Log.d("Cierre de sesión", "Error DE CONEXIÓN", e)
                MensajeRespuesta.value = "No se realizó la conexión, verifica la conectividad."
                progressBar.value = false
            }
        }
    }

    fun consultaInformacion (usuario: String, session: Int) {
        val jsonObject = JSONObject()
        jsonObject.put("Usuario",usuario)
        jsonObject.put("Session",session)

        val jsonObjectString = jsonObject.toString()

        val requestBody = jsonObjectString.toRequestBody("application/json".toMediaTypeOrNull())

        viewModelScope.launch(Dispatchers.IO) {
            try {
                progressBar.value = true
                val authService = ConexionRetrofit.getAuthService()

                //val responseService = authService.ConsultaInfo(usuario, session)
                val responseService = authService.ConsultaInfo(requestBody)

                if (responseService.isSuccessful){

                    miInformacion.value = responseService.body()!!.MyInfo.Datos.copy()

                    progressBar.value = false
                }
                progressBar.value = false
            }
            catch (e: Exception){
                Log.d("Consulta de información", "Error DE CONEXIÓN", e)
                MensajeRespuesta.value = "No se realizó la conexión, verifica la conectividad."
                progressBar.value = false
            }
        }
    }

    fun consultaProductos(usuario: String, session: Int){
        //ConsultaProductos
        val jsonObject = JSONObject()
        jsonObject.put("Usuario",usuario)
        jsonObject.put("Session",session)

        val jsonObjectString = jsonObject.toString()

        val requestBody = jsonObjectString.toRequestBody("application/json".toMediaTypeOrNull())
        viewModelScope.launch(Dispatchers.IO) {
            try {
                progressBar.value = true
                val authService = ConexionRetrofit.getAuthService()
                //val responseService = authService.ConsultaProductos(usuario,session)
                val responseService = authService.ConsultaProductos(requestBody)

                if (responseService.isSuccessful){

                    misProductos.value = responseService.body()!!.MyProducto.copy()

                    progressBar.value = false
                }
                progressBar.value = false
            }
            catch (e: Exception){
                Log.d("Consulta de productos", "Error DE CONEXIÓN", e)
                MensajeRespuesta.value = "No se realizó la conexión, verifica la conectividad."
                progressBar.value = false
            }
        }
    }

    fun DetallePoliza(usuario: String?, idPoliza: String?, idSession: Int) {
        listadoParentescos()
        val jsonObject = JSONObject()
        jsonObject.put("Usuario",usuario)
        jsonObject.put("idPoliza",idPoliza)
        jsonObject.put("Session",idSession)

        val jsonObjectString = jsonObject.toString()

        val requestBody = jsonObjectString.toRequestBody("application/json".toMediaTypeOrNull())
        viewModelScope.launch(Dispatchers.IO) {
            try {
                progressBar.value = true
                val authService = ConexionRetrofit.getAuthService()
                //val responseService = authService.DetalleProducto("$usuario", "$idPoliza", idSession)
                val responseService = authService.DetalleProducto(requestBody)

                if(responseService.isSuccessful){
                    detallesDePoliza.value = responseService.body()!!.DetalleProducto.copy()
                    seleccionoPoliza.value = true
                }

                progressBar.value = false
            } catch (e: Exception) {
                Log.d("Detalles de póliza", "Error DE CONEXIÓN", e)
                MensajeRespuesta.value = "No se realizó la conexión, verifica la conectividad."
                progressBar.value = false
            }
        }
    }

    fun editaMailTel(correo: String, cCorrelativo: Int, telefono: String, tCorrelativo: Int){
        val actualizacionObject = JSONObject()
        actualizacionObject.put("Usuario", respuestaLogin.value.Items.CodUsuario)
        actualizacionObject.put("Session", respuestaLogin.value.session.idSession)
        actualizacionObject.put("Telefono", telefono)
        actualizacionObject.put("CorrelativoTel", tCorrelativo)
        actualizacionObject.put("Correo", correo)
        actualizacionObject.put("CorrelativoMail", cCorrelativo)

        val jsonObjectString = actualizacionObject.toString()

        val requestBody = jsonObjectString.toRequestBody("application/json".toMediaTypeOrNull())
        Log.d("SERVICIO DE ACTUALIZACION MAIL", "JSON A ENVIAR: $jsonObjectString")

        viewModelScope.launch(Dispatchers.IO) {
            try {
                progressBar.value = true
                val authService = ConexionRetrofit.getAuthService()
                val responseService = authService.actualizaInfo(requestBody)

                println("Entro al servicio de actualización")
                if(responseService.isSuccessful){
                    println("Entro a la validación de conexión ---- valor de respuesta= ${responseService.body().toString()}")
                    if(responseService.body()?.CambioPassword?.Control?.NumeroRespuesta  == "1"){
                        println("Cambia la variable actualizo info a true --- \n Antes ${actualizoInfo.value}")
                        actualizoInfo.value = true
                        println("Actualizo info despues: ${actualizoInfo.value}")
                    }
                    MensajeRespuesta.value = responseService.body()?.CambioPassword?.Control?.TextoRespuesta.toString()
                }
                progressBar.value = false
            } catch (e: Exception) {
                Log.d("Actualización de información", "Error DE CONEXIÓN", e)
                MensajeRespuesta.value = "No se realizó la conexión, verifica la conectividad."
                progressBar.value = false
            }
        }
    }

    fun listadoParentescos(){
        viewModelScope.launch(Dispatchers.IO) {
            try {
                progressBar.value = true
                val authService = ConexionRetrofit.getAuthService()
                val responseService = authService.CatalogoParentescos()

                if(responseService.isSuccessful){
                    catalogoParentescos.value = responseService.body()!!.CatalogoParentescos.ListaParentescos
                }
                progressBar.value = false
            } catch (e: Exception) {
                Log.d("Catalogo de parentescos", "Error DE CONEXIÓN", e)
                MensajeRespuesta.value = "No se realizó la conexión, verifica la conectividad."
                progressBar.value = false
            }
        }
    }

    fun descargaPoliza(){
        /*TODO CONECTAR SERVICIO PARA DESCARGAR LA POLIZA*/
    }

    fun descargaCG(){
        /*TODO CONECTAR SERVICIO PARA DESCARGAR C.G.*/
    }

    fun enviaDocCorreo(){
        /*TODO CONECTAR SERVICIO PARA ENVIAR DOCUMENTOS POR CORREO*/
    }

    fun editaBeneficiario(){
        println("Va a editar beneficiarios")
        seleccionoBeneficiario.value = true
    }

    fun agregaEspacioBeneficiario(){
        agregaEspacioBeneficiario.value = true
    }

    fun clickMensaje(seleccion :Int){
        opcionMensaje.value = seleccion
    }
}