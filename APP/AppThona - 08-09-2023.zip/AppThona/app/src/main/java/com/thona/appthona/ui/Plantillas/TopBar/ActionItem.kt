package com.thona.appthona.ui.Plantillas.TopBar

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.DpOffset
import androidx.compose.ui.unit.dp

data class ActionItem(
    val nombre: String,
    val icono: ImageVector? = null,
    val accion: () -> Unit,
    val orden: Int
)

@Composable
fun OverflowMenuAction(
    expanded: Boolean,
    setExpanded: (Boolean) -> Unit,
    opciones: List<ActionItem>,
    click: (String) -> Unit
) {
    IconButton(onClick = { setExpanded(true) }) {
        Icon(imageVector = Icons.Filled.MoreVert, contentDescription = "Ver más", tint = Color.White)
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { setExpanded(false) },
            offset = DpOffset(x = 0.dp, y = 4.dp)
        ) {
            opciones.forEach { option ->
                DropdownMenuItem(
                    onClick = {
                         click(option.nombre);setExpanded(false)
                    },
                    text = {Text(text = option.nombre)}
                )
            }
        }
    }
}

val itemsMenu = listOf(
    ActionItem(
        "Cambiar contraseña",
        accion = {  },
        orden = 1
    ),
    ActionItem(
      nombre = "Cerrar sesión",
        accion = {  },
        orden = 2
    )
)