package com.thona.appthona.ui.Pantallas.Asegurado

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountBox
import androidx.compose.material.icons.outlined.AdminPanelSettings
import androidx.compose.material.icons.outlined.AttachMoney
import androidx.compose.material.icons.outlined.Bedtime
import androidx.compose.material.icons.outlined.Save
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.thona.appthona.Data.WebServices.Modelos.Login
import com.thona.appthona.Data.WebServices.Modelos.MyProducto
import com.thona.appthona.ui.theme.Institucional3

@Composable
fun AseguradoTramites(
    usuario: Login,
    productos: MyProducto,
){
    val mContext = LocalContext.current
    Box(
        Modifier
            //.padding(horizontal = 8.dp)
            .fillMaxWidth()
            .background(color = Institucional3)
    ) {
        Row(
            modifier = Modifier
                .padding(horizontal = 8.dp)
                .align(Alignment.CenterStart),
            horizontalArrangement = Arrangement.Center
        ) {
            Text(
                text = "${usuario.Items.NomUsuario}",
                color = Color.White,
                fontSize = 11.sp
            )
        }
        Row(
            modifier = Modifier
                .padding(horizontal = 8.dp)
                .align(Alignment.CenterEnd),
            horizontalArrangement = Arrangement.Center
        ) {
            Text(
                text = "No. Asegurado:${productos.idAsegurado.codAsegurado}",
                color = Color.White,
                fontSize = 11.sp
            )
        }
    }
    Spacer(modifier = Modifier.height(15.dp))
    Column (horizontalAlignment = Alignment.CenterHorizontally){
        Row {
            Column(){
                OutlinedButton(
                    onClick = {
                        Toast.makeText(
                            mContext,
                            "Acción tramite 1",
                            Toast.LENGTH_SHORT
                        ).show()
                    },
                    modifier= Modifier.size(60.dp),
                    shape = CircleShape,
                    border= BorderStroke(width = 5.dp, color = Institucional3),
                    contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor =  Institucional3)
                ) {
                    Icon(imageVector = Icons.Outlined.Save ,contentDescription = "", tint= Institucional3)
                }
                Spacer(modifier = Modifier.height(5.dp))
                Text(
                    text = "Tramite 1",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.width(30.dp))
            Column {
                OutlinedButton(
                    onClick = {
                        Toast.makeText(
                            mContext,
                            "Acción del tramite 2",
                            Toast.LENGTH_SHORT
                        ).show()
                    },
                    modifier= Modifier.size(60.dp),
                    shape = CircleShape,
                    border= BorderStroke(width = 5.dp, color = Institucional3),
                    contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor =  Institucional3)
                ) {
                    Icon(imageVector = Icons.Outlined.AccountBox ,contentDescription = "", tint= Institucional3)
                }
                Spacer(modifier = Modifier.height(5.dp))
                Text(
                    text = "Tramite 2",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.width(30.dp))
            Column {
                OutlinedButton(
                    onClick = {
                        Toast.makeText(
                            mContext,
                            "Acción del tramite 3",
                            Toast.LENGTH_SHORT
                        ).show()
                    },
                    modifier= Modifier.size(60.dp),
                    shape = CircleShape,
                    border= BorderStroke(width = 5.dp, color = Institucional3),
                    contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor =  Institucional3)
                ) {
                    Icon(imageVector = Icons.Outlined.AdminPanelSettings ,contentDescription = "", tint= Institucional3)
                }
                Spacer(modifier = Modifier.height(5.dp))
                Text(
                    text = "Tramite 3",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
        Spacer(modifier = Modifier.height(150.dp))
        Row {
            Column {
                OutlinedButton(
                    onClick = {
                        Toast.makeText(
                            mContext,
                            "Acción tramite 4",
                            Toast.LENGTH_SHORT
                        ).show()
                    },
                    modifier= Modifier.size(60.dp),
                    shape = CircleShape,
                    border= BorderStroke(width = 5.dp, color = Institucional3),
                    contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor =  Institucional3)
                ) {
                    Icon(imageVector = Icons.Outlined.AttachMoney ,contentDescription = "", tint= Institucional3)
                }
                Spacer(modifier = Modifier.height(5.dp))
                Text(
                    text = "Tramite 4",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.width(30.dp))
            Column {
                OutlinedButton(
                    onClick = {
                        Toast.makeText(
                            mContext,
                            "Acción del tramite 5",
                            Toast.LENGTH_SHORT
                        ).show()
                    },
                    modifier= Modifier.size(60.dp),
                    shape = CircleShape,
                    border= BorderStroke(width = 5.dp, color = Institucional3),
                    contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor =  Institucional3)
                ) {
                    Icon(imageVector = Icons.Outlined.Bedtime ,contentDescription = "", tint= Institucional3)
                }
                Spacer(modifier = Modifier.height(5.dp))
                Text(
                    text = "Tramite 5",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.width(30.dp))
            Column {
                OutlinedButton(
                    onClick = {
                        Toast.makeText(
                            mContext,
                            "Acción tramite 6",
                            Toast.LENGTH_SHORT
                        ).show()
                    },
                    modifier= Modifier.size(60.dp),
                    shape = CircleShape,
                    border= BorderStroke(width = 5.dp, color = Institucional3),
                    contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor =  Institucional3)
                ) {
                    Icon(imageVector = Icons.Outlined.AttachMoney ,contentDescription = "", tint= Institucional3)
                }
                Spacer(modifier = Modifier.height(5.dp))
                Text(
                    text = "Tramite 6",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.width(30.dp))
            Column {
                OutlinedButton(
                    onClick = {
                        Toast.makeText(
                            mContext,
                            "Acción del tramite 7",
                            Toast.LENGTH_SHORT
                        ).show()
                    },
                    modifier= Modifier.size(60.dp),
                    shape = CircleShape,
                    border= BorderStroke(width = 5.dp, color = Institucional3),
                    contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor =  Institucional3)
                ) {
                    Icon(imageVector = Icons.Outlined.Bedtime ,contentDescription = "", tint= Institucional3)
                }
                Spacer(modifier = Modifier.height(5.dp))
                Text(
                    text = "Tramite 7",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}