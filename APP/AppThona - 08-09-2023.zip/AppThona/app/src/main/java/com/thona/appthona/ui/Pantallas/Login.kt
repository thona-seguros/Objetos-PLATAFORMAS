package com.thona.appthona.ui.theme

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.thona.appthona.Constantes.Institucional1
import com.thona.appthona.Constantes.Institucional2
import com.thona.appthona.Constantes.Institucional3
import com.thona.appthona.Data.WebServices.Modelos.Login
import com.thona.appthona.Data.WebServices.Modelos.ubicacion
import com.thona.appthona.ui.Plantillas.CampoContraseña
import com.thona.appthona.ui.Plantillas.CampoTexto
import com.thona.appthona.R
import com.thona.appthona.ui.Plantillas.AlertaDialogo
import com.thona.appthona.ui.Plantillas.ProgressBarLoading

@Composable
fun Login(
    click: (pant: String) -> Unit,
    rol: String,
    iniciarSesion: (rol: String, cuenta: String, pass: String) -> Unit,
    texto1: String,
    texto2: String,
    loadingProgressBar: Boolean,
    loginCorrecto: Boolean,
    respuestaLogin: Login,
    clickMensaje: (opcion: String, idSession: Int) -> Unit
){
    var Modifier = Modifier.alpha(alpha = 1F)
    if(loadingProgressBar){
        Modifier = Modifier.alpha(alpha = 0.8F)
    }
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier, verticalArrangement = Arrangement.Center){
        var usuario by rememberSaveable { mutableStateOf(value = "") }
        var password by rememberSaveable { mutableStateOf(value = "") }
        var passwordVisible by rememberSaveable { mutableStateOf(false) }
        val isValidate by derivedStateOf { usuario.length>2 && password.isNotBlank() && !loadingProgressBar }
        var Color1 = Institucional1
        var Color2 = Institucional2
        var Color3 = Institucional3
        when(rol){
            "Cliente" -> {
                Color1 = Institucional1
                Color2 = Institucional2
                Color3 = Institucional3
            }
            "Asegurado" -> {
                Color1 = Institucional3
                Color2 = Institucional2
                Color3 = Institucional1
            }
            "Agente" -> {
                Color1 = Institucional2
                Color2 = Institucional1
                Color3 = Institucional3
            }
        }
        Spacer(modifier = Modifier.height(10.dp))
        Row{
            Image(
                painter = painterResource(id = R.drawable.thona_favicon_),
                contentDescription = "Thona Seguros",
                modifier = Modifier.size(150.dp)
            )
        }
        Spacer(modifier = Modifier.height(40.dp))
        Row{
            CampoTexto(
                textValue = usuario,
                onValueChange = {usuario = it},
                onClickButton = { usuario = "" },
                texto = "Usuario",
                tipo = KeyboardType.Text,
                isLoading = loadingProgressBar
            )
        }
        Spacer(modifier = Modifier.height(5.dp))
        Row{
            CampoContraseña(
                textValue = password,
                onValueChange = {password = it},
                onClickButton = { passwordVisible = !passwordVisible },
                texto = "Contraseña",
                tipo = KeyboardType.Password,
                passwordVisible = passwordVisible,
                accionGo = { iniciarSesion(rol.uppercase(),usuario,password) },
                isLoading = loadingProgressBar
            )
        }
        Spacer(modifier = Modifier.height(10.dp))
        Row{
            Button(
                onClick = { iniciarSesion(rol.uppercase(),usuario,password) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(
                        start = 20.dp,
                        end = 20.dp
                    ),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 5.dp),
                enabled = isValidate,
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(
                    Color1
                )
            ) {
                if(loadingProgressBar){
                    Text(
                        text = "Espera",
                        fontSize = 20.sp,
                        color = Color.White
                    )
                }
                else{
                    Text(
                        text = "Ingresar",
                        fontSize = 20.sp,
                        color = Color.White
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(5.dp))
        Row() {
            TextButton(
                onClick = { click(texto1) },
                colors = ButtonDefaults.buttonColors(
                    contentColor = Color2,
                    containerColor = Color.White
                ),
                enabled = !loadingProgressBar
            ) {
                Text(text = "Soy $texto1")
            }
            Spacer(modifier = Modifier.width(80.dp))
            TextButton(
                onClick = { click(texto2) },
                colors = ButtonDefaults.buttonColors(
                    contentColor = Color3,
                    containerColor = Color.White
                ),
                enabled = !loadingProgressBar
            ) {
                Text(text = "Soy $texto2")
            }
        }
        Spacer(modifier = Modifier.height(15.dp))
        if(!loginCorrecto){
            Row{
                Text(
                    text = respuestaLogin.Control.TextoRespuesta,
                    fontSize = 15.sp,
                    color = Color.Red
                )
            }
        }
        if (respuestaLogin.Control.TextoRespuesta == "Tienes una sesion activa."){
            AlertaDialogo(
                titulo = respuestaLogin.Control.TextoRespuesta,
                mensaje = "¿Deseas cerrar esa sesión?",
                clicAceptar = { clickMensaje(usuario, respuestaLogin.session.idSession); click(rol) },
                clicCancelar = { click("Login") },
                colorRol = Color1,
                cantidadBotones = 2
            )
        }
    }
    ProgressBarLoading(isLoading = loadingProgressBar)
}