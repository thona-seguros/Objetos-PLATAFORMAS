package com.thona.appthona.Ubicacion

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.pm.PackageManager
import android.location.Location
import android.os.Build
import android.widget.Toast
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.core.app.ActivityCompat.requestPermissions
import androidx.core.content.ContextCompat
import com.google.android.gms.location.*
import com.thona.appthona.Funciones.funciones
import com.thona.appthona.ui.Plantillas.AlertaDialogo
import com.thona.appthona.ui.theme.Institucional1

private lateinit var fusedLocationClient: FusedLocationProviderClient

fun pidePermiso(
    actividad: Activity,
    permiso: String
){
    println("TE VA A PEDIR EL PERMISO $permiso")
    requestPermissions( actividad, arrayOf(permiso), 0)
}

@Composable
fun CheckPermission(actividad: Activity, permiso: String, mensaje: String, clicMensaje: (opcion: Int) -> Unit) {
    println("Va a revisar si el permiso de $permiso esta concedido")
    if (ContextCompat.checkSelfPermission(actividad, permiso) == PackageManager.PERMISSION_DENIED) {
        AlertaDialogo(
            titulo = "Solicitud de permiso",
            mensaje = mensaje,
            clicAceptar =  {clicMensaje(1)},
            clicCancelar = { clicMensaje(2) },
            colorRol = Institucional1,
            cantidadBotones = 2
        )
    } else {
        Toast.makeText(actividad, "Permiso $permiso aceptado", Toast.LENGTH_SHORT).show()
    }
}

@Composable
fun permisos(funciones: funciones, actividad: Activity, permiso: String, clicMensaje: (opcion: Int) -> Unit): Boolean{
    var aceptoPermiso = false
    println("VERSION DE ANDROID A VALIDAR:: ${Build.VERSION.SDK_INT} COMPARACIÓN:: ${Build.VERSION_CODES.Q}")
    if(ContextCompat.checkSelfPermission(actividad, permiso) == PackageManager.PERMISSION_GRANTED){
        println("MODULO PERMISOS:: Se concedieron permisos de $permiso")
        aceptoPermiso = true
        when (permiso){
            Manifest.permission.ACCESS_FINE_LOCATION -> {
                Ubicacion(funciones = funciones, actividad = actividad, clicMensaje = clicMensaje)
            }
            Manifest.permission.WRITE_EXTERNAL_STORAGE -> {
                println("PERMISO DE ALMACENAMIENTO")
            }
        }
    }
    else if(ContextCompat.checkSelfPermission(actividad, permiso) == PackageManager.PERMISSION_DENIED){
        println("MODULO PERMISOS:: No se concedio el permiso de $permiso")
    }
    return aceptoPermiso
}

@SuppressLint("MissingPermission")
@Composable
fun Ubicacion (funciones: funciones, actividad: Activity, clicMensaje: (opcion: Int) -> Unit){
    fusedLocationClient = LocationServices.getFusedLocationProviderClient(actividad)
    val tieneDatos = remember { mutableStateOf(true)}
    fusedLocationClient.lastLocation
        .addOnSuccessListener { location : Location? ->
            funciones::datosUbicacion.invoke(location)
            funciones::obtieneIP.invoke()
            tieneDatos.value = location?.latitude != null
        }
    if(!tieneDatos.value){
        AlertaDialogo(
            titulo = "Habilita tu ubicación",
            mensaje = "Para poder continuar, es necesario tener activo el servicio de ubicación.\nPor favor activa tu ubicación y vuelve a intentar.\n\nLa puedes activar desde Ajustes > Ubicación. \n\n*NOTA: Una vez activado espera 3 minutos y vuelve a intentarlo.",
            clicAceptar = { clicMensaje(2) },
            clicCancelar = {  },
            colorRol = Institucional1,
            cantidadBotones = 1
        )
    }
}