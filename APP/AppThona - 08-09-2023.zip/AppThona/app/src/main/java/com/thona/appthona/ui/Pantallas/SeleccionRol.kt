package com.thona.appthona.ui.Pantallas

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.thona.appthona.R
import com.thona.appthona.ui.theme.Institucional1
import com.thona.appthona.ui.theme.Institucional2
import com.thona.appthona.ui.theme.Institucional3

@Composable
fun SeleccionRol(
    click: (pant: String) -> Unit
){
    Row{
        Image(
            painter = painterResource(id = R.drawable.thona_favicon_),
            contentDescription = "Thona Seguros",
            modifier = Modifier.size(150.dp)
        )
    }
    Spacer(modifier = Modifier.height(20.dp))
    Row(verticalAlignment = Alignment.CenterVertically){
        Text(
            text = "Bienvenid@",
            fontSize = 18.sp
        )
    }
    Row(verticalAlignment = Alignment.CenterVertically){
        Text(
            text = "Selecciona una opción",
            fontSize = 18.sp
        )
    }
    Spacer(modifier = Modifier.height(50.dp))
    Row{
        Button(
            onClick = { click("Cliente") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(
                    start = 80.dp,
                    end = 80.dp
                ),
            elevation = ButtonDefaults.buttonElevation(defaultElevation = 5.dp),
            enabled = true,
            shape = CircleShape,
            colors = ButtonDefaults.buttonColors(
                Institucional1
            )
        ) {
            Text(
                text = "Soy Cliente",
                fontSize = 20.sp,
                color = Color.White
            )
        }
    }
    Spacer(modifier = Modifier.height(20.dp))
    Row{
        Button(
            onClick = { click("Asegurado") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(
                    start = 80.dp,
                    end = 80.dp
                ),
            elevation = ButtonDefaults.buttonElevation(defaultElevation = 5.dp),
            enabled = true,
            shape = CircleShape,
            colors = ButtonDefaults.buttonColors(
                Institucional3
            )
        ) {
            Text(
                text = "Soy Asegurado",
                fontSize = 20.sp,
                color = Color.White
            )
        }
    }
    Spacer(modifier = Modifier.height(20.dp))
    Row{
        Button(
            onClick = { click("Agente") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(
                    start = 80.dp,
                    end = 80.dp
                ),
            elevation = ButtonDefaults.buttonElevation(defaultElevation = 5.dp),
            enabled = true,
            shape = CircleShape,
            colors = ButtonDefaults.buttonColors(
                Institucional2
            )
        ) {
            Text(
                text = "Soy Agente",
                fontSize = 20.sp,
                color = Color.White
            )
        }
    }
}