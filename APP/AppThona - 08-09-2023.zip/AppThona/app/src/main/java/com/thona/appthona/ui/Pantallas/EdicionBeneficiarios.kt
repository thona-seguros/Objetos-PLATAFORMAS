package com.thona.appthona.ui.Pantallas

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Cancel
import androidx.compose.material.icons.outlined.DeleteForever
import androidx.compose.material.icons.outlined.Done
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.KeyboardArrowUp
import androidx.compose.material.icons.outlined.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconToggleButton
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.google.gson.JsonObject
import com.thona.appthona.Constantes.Institucional1
import com.thona.appthona.Constantes.Institucional3
import com.thona.appthona.Constantes.ThonaNaranja
import com.thona.appthona.Constantes.ThonaRojo
import com.thona.appthona.Constantes.ThonaVerde
import com.thona.appthona.Data.WebServices.Modelos.DetalleBeneficiarioItem
import com.thona.appthona.Data.WebServices.Modelos.DetalleProducto
import com.thona.appthona.Data.WebServices.Modelos.ParentescoItem
import com.thona.appthona.Funciones.funciones
import com.thona.appthona.ui.Plantillas.AlertaDialogo
import com.thona.appthona.ui.Plantillas.MenuColapsable.ExpandableListViewModel
import com.thona.appthona.ui.Plantillas.cajaTextoBeneficiarios
import com.thona.appthona.ui.Plantillas.cambio
import org.json.JSONArray
import org.json.JSONObject

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EdicionBeneficiarios(funciones: funciones, producto: DetalleProducto, viewModel: ExpandableListViewModel, listaParentescos: List<ParentescoItem>){
    val mContext = LocalContext.current
    val scrollState = rememberScrollState()
    var clicBoton by remember { mutableIntStateOf(value = 0) }
    //var numBen by remember { mutableIntStateOf(value = producto.detalleBeneficiarios.count()) }
    var num: Int
    val benefIds by viewModel.benefIds.collectAsState()
    Spacer(Modifier.height(25.dp))
    Column(
        modifier = Modifier
            .verticalScroll(scrollState)
            .fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ){
        benefIds.forEach{ beneficiario ->
            var expanded by remember { mutableStateOf(false) }
            //var selectedType by remember { mutableStateOf( listaParentescos[default].parentesco) }
            var selectedType by remember { mutableStateOf( beneficiario.parentescoBeneficiario) }
            var texto by remember { mutableStateOf(beneficiario.nombreBeneficiario) }
            var porcentaje by remember { mutableStateOf(beneficiario.porcentajeBeneficiario.toString()) }
            Column {
                OutlinedCard(
                    modifier = Modifier.padding(5.dp),
                    shape = CardDefaults.outlinedShape,
                    colors = CardDefaults.outlinedCardColors(containerColor = Color.Transparent),
                    elevation = CardDefaults.outlinedCardElevation()
                ){
                    var cheked by remember { mutableStateOf(false) }
                    var muestraMensaje by remember { mutableStateOf(false) }
                    //num = producto.detalleBeneficiarios.indexOf(beneficiario)+1
                    num = benefIds.indexOf(beneficiario)+1
                    Box(modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp)){
                        Column(modifier = Modifier.fillMaxSize()){
                            Box(modifier = Modifier.fillMaxWidth()){
                                Row(modifier = Modifier
                                    .align(Alignment.CenterStart)
                                    .padding(end = 80.dp),verticalAlignment = Alignment.CenterVertically){
                                    if(!cheked) Text(text = beneficiario.nombreBeneficiario)
                                    else Text(text = "Beneficiario $num")
                                }
                                Row(modifier = Modifier.align(Alignment.CenterEnd),verticalAlignment = Alignment.CenterVertically){
                                    IconToggleButton(
                                        checked = cheked,
                                        onCheckedChange = { _cheked ->
                                            cheked = _cheked
                                        }
                                    ) {
                                        var Edito by rememberSaveable { mutableStateOf(value = false) }
                                        if(cheked){
                                            val distinto1 = cambio(texto,beneficiario.nombreBeneficiario)
                                            val distinto2 = cambio(porcentaje,beneficiario.porcentajeBeneficiario.toString())
                                            val distinto3 = cambio(selectedType,beneficiario.parentescoBeneficiario)
                                            val distinto = (distinto1 || distinto2 || distinto3)
                                            Edito = distinto
                                            var valido by rememberSaveable { mutableStateOf(value = true) }
                                            println("VALORES:: DISTINTO:$distinto -- EDITO:$Edito")
                                            if(distinto){
                                                IconButton(
                                                    enabled = valido,
                                                    onClick = { Toast.makeText(
                                                    mContext,
                                                    "Beneficiario editado $texto - porc: $porcentaje parent: $selectedType",
                                                    Toast.LENGTH_SHORT
                                                ).show(); cheked=!cheked; viewModel.editaBeneficiario(index = benefIds.indexOf(beneficiario), beneficiarioNuevo = DetalleBeneficiarioItem(texto,porcentaje.toInt(),selectedType), beneficiarioAnterior = beneficiario) }) {
                                                    Icon(
                                                        imageVector = Icons.Outlined.Done,
                                                        contentDescription = "Guardar",
                                                        tint = ThonaNaranja
                                                    )
                                                }
                                            }else{
                                                IconButton(onClick = { cheked=!cheked }) {
                                                    Icon(
                                                        imageVector = Icons.Outlined.KeyboardArrowUp,
                                                        contentDescription = "Deseditar",
                                                        tint = ThonaVerde
                                                    )
                                                }
                                            }
                                        }else{
                                            Icon(
                                                imageVector = Icons.Outlined.Edit,
                                                contentDescription = "Editar",
                                                tint = ThonaVerde
                                            )
                                        }
                                    }
                                    IconButton(
                                        enabled = cheked,
                                        onClick = { muestraMensaje=true }
                                    ) {
                                        Icon(
                                            imageVector = Icons.Outlined.DeleteForever,
                                            contentDescription = "Borrar",
                                            tint = if(cheked) ThonaRojo else Color.LightGray
                                        )
                                    }
                                }
                            }
                            if(muestraMensaje){
                                AlertaDialogo(
                                    titulo = "Quitar beneficiario",
                                    mensaje = "¿Deseas quitar el beneficiario $num - ${beneficiario.nombreBeneficiario}?",
                                    clicAceptar = { Toast.makeText(
                                        mContext,
                                        "Eliminar beneficiario ${beneficiario.nombreBeneficiario}",
                                        Toast.LENGTH_SHORT
                                    ).show(); cheked=false; viewModel.quitaBeneficiario(index = benefIds.indexOf(beneficiario),beneficiario = beneficiario); muestraMensaje=false;
                                        if(benefIds.indexOf(beneficiario)!=0 && benefIds.indexOf(beneficiario)!= benefIds.lastIndex){
                                            selectedType=benefIds[benefIds.indexOf(beneficiario)+1].parentescoBeneficiario
                                        }
                                                  },
                                    clicCancelar = { muestraMensaje=false },
                                    colorRol = Institucional3,
                                    cantidadBotones = 2
                                )
                            }
                            if (cheked){
                                Column {
                                    texto = cajaTextoBeneficiarios(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(start = 7.dp, end = 7.dp),
                                        dato = beneficiario.nombreBeneficiario,
                                        etiqueta = "Nombre",
                                        placeholder = "Nombre del beneficiario",
                                        editable = true,
                                        tipoTeclado = KeyboardType.Text
                                    )
                                    Spacer(modifier = Modifier.height(3.dp))
                                    Row(modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(start = 7.dp, end = 7.dp),horizontalArrangement = Arrangement.Center) {
                                        ExposedDropdownMenuBox(
                                            expanded = expanded,
                                            onExpandedChange = { expanded = !expanded },
                                            modifier = Modifier.width(200.dp)
                                        ) {
                                            TextField(
                                                readOnly = true,
                                                value = selectedType,
                                                //value = beneficiario.parentescoBeneficiario,
                                                onValueChange = {  },
                                                label = { Text("Parentesco") },
                                                trailingIcon = {
                                                    ExposedDropdownMenuDefaults.TrailingIcon(
                                                        expanded = expanded
                                                    )
                                                },
                                                colors = ExposedDropdownMenuDefaults.textFieldColors(),
                                                modifier = Modifier.menuAnchor()
                                            )
                                            ExposedDropdownMenu(
                                                expanded = expanded,
                                                onDismissRequest = {
                                                    expanded = false
                                                }
                                            ) {
                                                listaParentescos.forEach{ selectionOption ->
                                                    DropdownMenuItem(
                                                        text = { Text(text = selectionOption.parentesco) },
                                                        onClick = {
                                                            selectedType = selectionOption.parentesco
                                                            expanded = false
                                                        },
                                                        contentPadding = ExposedDropdownMenuDefaults.ItemContentPadding
                                                    )
                                                }
                                            }
                                        }
                                        Spacer(modifier = Modifier.width(6.dp))
                                        println("PORCENTAJE A GUARDAR1: $porcentaje")
                                        porcentaje = cajaTextoBeneficiarios(
                                            modifier = Modifier
                                                .width(100.dp)
                                                .height(60.dp),
                                            dato = beneficiario.porcentajeBeneficiario.toString(),
                                            etiqueta = "Porcentaje",
                                            placeholder = "100",
                                            editable = true,
                                            tipoTeclado = KeyboardType.Number
                                        )
                                        println("PORCENTAJE A GUARDAR2: $porcentaje")
                                    }
                                    Spacer(modifier = Modifier.height(5.dp))
                                }
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(text = "Conteo: ${benefIds.count()}")
        Spacer(Modifier.height(10.dp))
        if(true){
            Button(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 10.dp, end = 10.dp),
                onClick = {
                    if(viewModel.agregaBeneficiario(beneficiario = DetalleBeneficiarioItem("Beneficiario ${benefIds.count()+1}",0,""))){
                        Toast.makeText(
                            mContext,
                            "Beneficiario ${benefIds.count()+1} agregado",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                },
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Institucional3
                ),
                enabled = true
            ) {
                Text(
                    text = "Agregar beneficiario",
                    color = Color.White
                )
                Spacer(Modifier.size(ButtonDefaults.IconSpacing))
                Icon(
                    imageVector = Icons.Outlined.Add,
                    contentDescription = "Agregar",
                    tint = Color.White
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        if(true){
            Row(verticalAlignment = Alignment.CenterVertically){
                Button(
                    onClick = {
                        clicBoton=2
                    },
                    shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Institucional3
                    ),
                    enabled = true
                ) {
                    Text(
                        text = "Cancelar",
                        color = Color.White
                    )
                    Spacer(Modifier.size(ButtonDefaults.IconSpacing))
                    Icon(
                        imageVector = Icons.Outlined.Cancel,
                        contentDescription = "Cancelar",
                        tint = Color.White
                    )
                }
                Spacer(modifier = Modifier.width(20.dp))
                Button(
                    onClick = {
                        clicBoton = 1
                    },
                    shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Institucional3
                    ),
                    enabled = true
                ) {
                    Text(
                        text = "Guardar",
                        color = Color.White
                    )
                    Spacer(Modifier.size(ButtonDefaults.IconSpacing))
                    Icon(
                        imageVector = Icons.Outlined.Save,
                        contentDescription = "Guardar",
                        tint = Color.White
                    )
                }
            }
        }
        when(clicBoton){
            1 -> {
                val json = JSONArray()
                benefIds.forEach {
                    var codParent = ""
                    listaParentescos.forEach{parent ->
                        if(parent.parentesco == it.parentescoBeneficiario){
                            codParent = parent.codParentesco
                        }
                    }
                    val aux = JSONObject()
                    aux.put("Nombre",it.nombreBeneficiario)
                    aux.put("Parentesco",codParent)
                    aux.put("Porcentaje",it.porcentajeBeneficiario)

                    json.put(aux)
                }
                val manda = JSONObject().put("Beneficiarios",json)
                AlertaDialogo(
                    titulo = "Guardar datos",
                    mensaje = "Se van a guardar los siguientes datos: -> $manda",
                    clicAceptar = {
                        Toast.makeText(
                            mContext,
                            "Guarda datos",
                            Toast.LENGTH_SHORT
                        ).show(); clicBoton = 0; funciones.actualizaBeneficiarios(producto.detalleProducto.idPoliza,manda.toString()); funciones.clickMensaje(10)
                    },
                    clicCancelar = { clicBoton = 0 },
                    colorRol = Institucional3,
                    cantidadBotones = 2
                )
            }
            2 -> {
                //BOTON CANCELA ACTUALIZACIÓN
                AlertaDialogo(
                    titulo = "Cancelar edición",
                    mensaje = "¿Deseas cancelar la edición de los beneficiarios para la póliza ${producto.detalleProducto.idPoliza}?",
                    clicAceptar = {
                        Toast.makeText(
                            mContext,
                            "Actualización cancelada",
                            Toast.LENGTH_SHORT
                        ).show(); clicBoton = 0; funciones.clickMensaje(11)
                    },
                    clicCancelar = { clicBoton=0 },
                    colorRol = Institucional3,
                    cantidadBotones = 2
                )
            }
        }
    }
}