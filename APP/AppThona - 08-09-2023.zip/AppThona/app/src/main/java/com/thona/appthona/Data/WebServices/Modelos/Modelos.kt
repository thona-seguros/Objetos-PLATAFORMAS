package com.thona.appthona.Data.WebServices.Modelos

import com.google.gson.annotations.SerializedName
import org.simpleframework.xml.Element
import org.simpleframework.xml.Root

data class ModeloLogin(
    @SerializedName("items") val Login: Login
)

data class ModeloCambioPassword(
    @SerializedName("items") val CambioPassword: CambioPassword
)

data class ModeloCierreSesion(
    @SerializedName("items") val CierraSesion: CierreSesion
)

data class ModeloMyInformacion(
    @SerializedName("items") val MyInfo: MyInfo
)

data class ModeloMyProducto(
    @SerializedName("items") val MyProducto: MyProducto
)

data class ModeloDetalleProducto(
    @SerializedName("items") val DetalleProducto: DetalleProducto
)

data class ModeloCatalogoParentescos(
    @SerializedName("items") val CatalogoParentescos: CatalogoParentescos
)

data class ModeloEnviaMail(
    @SerializedName("items") val EnvioMail: EnvioMail
)

data class ModeloRespuestaBeneficiarios(
    @SerializedName("items") val RespuestaBeneficiarios: RespuestaBeneficiarios
)

data class ModeloObteieneIP(
    @SerializedName("ip") var ip : String,
    /*@SerializedName("hostname") val hostname : String,
    @SerializedName("city") val city : String,
    @SerializedName("region") val region : String,
    @SerializedName("country") val country : String,
    @SerializedName("loc") val loc : String,
    @SerializedName("org") val org : String,
    @SerializedName("postal") val postal : String,
    @SerializedName("timezone") val timezone : String,
    @SerializedName("readme") val readme : String*/
)

//@Root (name = "ok", strict = false)
data class ModeloPrueba(
    @field: Element(name = "ok")
    @param: Element(name = "ok")
    val ok: String? = null
)

@Root (name = "DATA", strict = false)
data class Data @JvmOverloads constructor(
    @field:Element(name = "URL")
    @param:Element(name = "URL")
    var url: String? = null
)

/*data class ModeloPDF(
    @org.simpleframework.xml.
)*/