package com.thona.appthona.ui.Plantillas.TopBar

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.thona.appthona.Constantes.Institucional2
import com.thona.appthona.R

enum class DatosPantalla(val title: String) {
    Login(title = "Login"),
    CambioContrasenaAgenteClienteAsegurado(title = "Cambio de contraseña"),
    Cliente(title = "Login Cliente"),
    Agente(title = "Login Agente"),
    Asegurado(title = "Login Asegurado"),
    MenuAgente(title = "Menú Agente"),
    MenuCliente(title = "Menú Cliente"),
    AseguradoCuenta(title = "Cuenta"),
    AseguradoPolizas(title = "Pólizas"),
    AseguradoTramites(title = "Trámites"),
    AseguradoDetallePoliza(title = "Detalles de Póliza"),
    AseguradoBeneficiarios(title = "Edición de beneficiarios"),
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopBar(
    color: Color,
    pantallaActual: DatosPantalla,
    puedeRegresar: Boolean,
    accionRegresar: () -> Unit,
    modifier: Modifier = Modifier,
    actionItems: List<ActionItem>,
    accionItem: (String) -> Unit,
    accionAgregarBenef: () -> Unit
){
    CenterAlignedTopAppBar(
        title = {
            Text(
                text = pantallaActual.title,
                color = Color.White
            )
        },
        colors = TopAppBarDefaults.mediumTopAppBarColors(
            containerColor = color
        ),
        modifier = modifier,
        navigationIcon = {
            if (puedeRegresar) {
                IconButton(onClick = accionRegresar) {
                    Icon(
                        imageVector = Icons.Filled.ArrowBack,
                        contentDescription = "Atras"
                    )
                }
            }
            if(pantallaActual.title == "Cambio de contraseña" || pantallaActual.title == "Edición de beneficiarios"){
                IconButton(onClick = accionRegresar) {
                    Icon(
                        imageVector = Icons.Filled.ArrowBack,
                        contentDescription = "Atras",
                        tint = Color.White
                    )
                }
            } else if(!pantallaActual.title.contains("Login")){
                Image(
                    painter = painterResource(id = R.drawable.logothona),
                    contentDescription = "Thona Seguros",
                    modifier = Modifier
                        .size(50.dp)
                        .padding(6.dp),
                )
            }
            if(color == Institucional2 && !pantallaActual.title.contains("Login")){
                Image(
                    painter = painterResource(id = R.drawable.iconoblanco),
                    contentDescription = "Thona Seguros",
                    modifier = Modifier
                        .size(50.dp)
                        .padding(6.dp)
                )
            }
        },
        actions = {
            if(pantallaActual == DatosPantalla.AseguradoCuenta){
                val (iconos, opciones) = actionItems.partition { it.icono != null }
                iconos.forEach{
                    IconButton(onClick = { it.accion }, enabled = true) {
                        Icon(imageVector = it.icono!!, contentDescription = it.nombre, tint = Color.White)
                    }
                }
                val (isExpanded, setExpanded) = remember { mutableStateOf(false) }
                OverflowMenuAction(isExpanded,setExpanded,opciones,accionItem)
            }
        }
    )
}