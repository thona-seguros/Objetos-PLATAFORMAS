package com.thona.appthona.ui.Pantallas.Asegurado

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Circle
import androidx.compose.material.icons.outlined.ArrowForwardIos
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Alignment.Companion.CenterVertically
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.thona.appthona.Constantes.Institucional1
import com.thona.appthona.Constantes.Institucional2
import com.thona.appthona.Constantes.PolizaANU
import com.thona.appthona.Constantes.PolizaEMI
import com.thona.appthona.Constantes.PolizaPLD
import com.thona.appthona.Constantes.PolizaPRE
import com.thona.appthona.Constantes.PolizaREN
import com.thona.appthona.Constantes.PolizaSOL
import com.thona.appthona.Constantes.PolizaSUS
import com.thona.appthona.Constantes.PolizaXRE
import com.thona.appthona.Data.WebServices.Modelos.Login
import com.thona.appthona.Data.WebServices.Modelos.MyProducto
import com.thona.appthona.ui.theme.Institucional3

@Composable
fun AseguradoPolizas(
    usuario: Login,
    productos: MyProducto,
    clicPoliza: (usuario: String?, idPoliza: String?, session: Int) -> Unit
){
    val scrollState = rememberScrollState()
    Box(
        Modifier
            //.padding(horizontal = 8.dp)
            .fillMaxWidth()
            .background(color = Institucional3)
    ) {
        Row(
            modifier = Modifier
                .padding(horizontal = 8.dp)
                .align(Alignment.CenterStart),
            horizontalArrangement = Arrangement.Center
        ) {
            Text(
                text = "${usuario.Items.NomUsuario}",
                color = Color.White,
                fontSize = 11.sp
            )
        }
        Row(
            modifier = Modifier
                .padding(horizontal = 8.dp)
                .align(Alignment.CenterEnd),
            horizontalArrangement = Arrangement.Center
        ) {
            Text(
                text = "No. Asegurado:${productos.idAsegurado.codAsegurado}",
                color = Color.White,
                fontSize = 11.sp
            )
        }
    }

    Column(
        modifier = Modifier.verticalScroll(scrollState).fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        var colorEstatus = Institucional1
        if(productos.Productos.isNotEmpty()){
            productos.Productos.forEach {
                when (it.statusPoliza){
                    /*"ANU" -> {
                        colorEstatus = PolizaANU
                    }
                    "REN" -> {
                        colorEstatus = PolizaREN
                    }
                    "SUS" -> {
                        colorEstatus = PolizaSUS
                    }*/
                    "EMI" -> {
                        colorEstatus = PolizaEMI
                    }
                    "XRE" -> {
                        colorEstatus = PolizaXRE
                    }
                    /*"SOL" -> {
                        colorEstatus = PolizaSOL
                    }
                    "PLD" -> {
                        colorEstatus = PolizaPLD
                    }*/
                    "PRE" -> {
                        colorEstatus = PolizaPRE
                    }
                }
                Spacer(modifier = Modifier.height(7.dp))
                Row(
                    verticalAlignment = CenterVertically,
                    modifier = Modifier.clickable { clicPoliza(usuario.Items.CodUsuario,it.idPoliza,usuario.session.idSession) }
                ){
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Row {
                            Icon(modifier = Modifier, imageVector = Icons.Filled.Circle, contentDescription = "", tint = colorEstatus)
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Row {
                            Text(text = "Póliza")
                        }
                        Row {
                            Text(text = "${it.idPoliza}")
                        }
                    }
                    Spacer(modifier = Modifier.width(20.dp))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Row {
                            Text(text = "Tipo")
                        }
                        Row {
                            Text(text = "${it.idTipoSeguro}")
                        }
                    }
                    Spacer(modifier = Modifier.width(20.dp))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Row {
                            Text(text = "Vigencia")
                        }
                        Row {
                            Text(text = "${it.fechaVigencia}")
                        }
                    }
                    Spacer(modifier = Modifier.width(25.dp))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Row {
                            IconButton(onClick = { clicPoliza(usuario.Items.CodUsuario,it.idPoliza,usuario.session.idSession) }) {
                                Icon(modifier = Modifier, imageVector = Icons.Outlined.ArrowForwardIos, contentDescription = "", tint = Institucional2)
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(7.dp))
                Divider(color = Institucional3, thickness = 0.5.dp)
            }
        }
    }
}