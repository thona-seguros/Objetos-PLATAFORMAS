package com.thona.thonaseguros.ui.navegacion

import android.Manifest
import android.app.Activity
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.thona.thonaseguros.R
import com.thona.thonaseguros.datos.modelos.DetalleProducto
import com.thona.thonaseguros.datos.modelos.InfoItem
import com.thona.thonaseguros.datos.modelos.Login
import com.thona.thonaseguros.datos.modelos.MyProducto
import com.thona.thonaseguros.datos.modelos.ParentescoItem
import com.thona.thonaseguros.funciones.Funciones
import com.thona.thonaseguros.permisos.CheckPermission
import com.thona.thonaseguros.permisos.permisos
import com.thona.thonaseguros.permisos.pidePermiso
import com.thona.thonaseguros.ui.pantallas.asegurado.AseguradoCuenta
import com.thona.thonaseguros.ui.pantallas.asegurado.AseguradoDetalleFactura
import com.thona.thonaseguros.ui.pantallas.asegurado.AseguradoPolizas
import com.thona.thonaseguros.ui.pantallas.asegurado.DetallePolizas
import com.thona.thonaseguros.ui.pantallas.generales.Asegurado
import com.thona.thonaseguros.ui.pantallas.generales.EdicionBeneficiarios
import com.thona.thonaseguros.ui.pantallas.generales.PantallaPromocion
import com.thona.thonaseguros.ui.plantillas.AlertaPopUp
import com.thona.thonaseguros.ui.plantillas.ProgressBarLoading
import com.thona.thonaseguros.ui.plantillas.menu.DatosPantalla
import com.thona.thonaseguros.ui.plantillas.menu.ExpandableListViewModel
import com.thona.thonaseguros.ui.theme.Institucional2
import com.thona.thonaseguros.ui.theme.Institucional3
import com.thona.thonaseguros.ui.theme.existePromocion

@Composable
fun PomocionAsegurado(loadingProgressBar:Boolean, navController: NavController){
    Column(verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally){
        ProgressBarLoading(isLoading = loadingProgressBar)
    }
    BackHandler(
        enabled = !loadingProgressBar,
        onBack = { navController.navigate(route = DatosPantalla.AseguradoPolizas.name){} }
    )
    Column {
        PantallaPromocion(loadingProgressBar = loadingProgressBar)
    }
}

@Composable
fun LoginAsegurado(loadingProgressBar: Boolean, navController: NavController, funciones: Funciones, colorRol: Color, loginCorrecto: Boolean, respuestaLogin: Login, rolSel: String, aceptoMensaje: Int){
    BackHandler(
        enabled = !loadingProgressBar,
        onBack = { navController.navigate(route = DatosPantalla.Login.name){funciones.rolLogin.value = ""} }
    )
    Column(verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally){
        ProgressBarLoading(isLoading = loadingProgressBar)
    }
    val permiso = permisos(
        funciones = funciones,
        actividad = navController.context as Activity,
        permiso = Manifest.permission.ACCESS_FINE_LOCATION,
        clicMensaje = funciones::clickMensaje
    )
    if(permiso){
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Asegurado(
                login = funciones::conexion,
                click = funciones::selecRol,
                loadingProgressBar = loadingProgressBar,
                loginCorrecto = loginCorrecto,
                respuestaLogin = respuestaLogin,
                clickMensaje = funciones::cierraSesion,
                funciones = funciones,
                recupera = funciones::recuperaContrasenia
            )
            if(funciones.pideToken.value){
                LaunchedEffect(key1 = Unit){
                    navController.navigate(route = DatosPantalla.AgenteContratanteAseguradoAsignaToken.name){
                        funciones.pideToken.value = false
                    }
                }
            }
            if(loginCorrecto){
                LaunchedEffect(key1 = Unit){
                    navController.navigate(route = DatosPantalla.AseguradoPolizas.name){
                    }
                }
            }else if(rolSel.isNotEmpty()){
                LaunchedEffect(key1 = Unit){
                    navController.navigate(route = rolSel){
                        funciones.reiniciar()
                    }
                }
            }
        }
    }else {
        CheckPermission(
            actividad = navController.context as Activity,
            permiso = Manifest.permission.ACCESS_FINE_LOCATION,
            mensaje = "Debes otorgar acceso a tu ubicación para iniciar sesión.\nPuedes hacerlo desde Ajustes > Aplicaciones > Thona > Permisos > Permiso de ubicación > Permitir",
            clicMensaje = funciones::clickMensaje
        )
    }
    when(aceptoMensaje){
        1->{
            LaunchedEffect(key1 = Unit){
                navController.navigate(route = DatosPantalla.Asegurado.name){
                    funciones.reiniciar()
                    funciones.opcionMensaje.intValue = 0
                }
            }
            pidePermiso(
                actividad = navController.context as Activity,
                permiso = Manifest.permission.ACCESS_FINE_LOCATION
            )
        }
        2->{
            LaunchedEffect(key1 = Unit){
                navController.navigate(route = DatosPantalla.Login.name){
                    funciones.reiniciar()
                    funciones.opcionMensaje.intValue = 0
                }
            }
        }
    }
}

@Composable
fun CuentaAsegurado(loadingProgressBar: Boolean, respuestaLogin: Login, consultaInformacion: InfoItem, consultaProductos: MyProducto, funciones: Funciones, navController: NavController, actualizoInfo: Boolean, mensajeRespuesta: String, seleccion: String){
    Column(verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally){
        ProgressBarLoading(isLoading = loadingProgressBar)
    }
    BackHandler(
        enabled = !loadingProgressBar,
        onBack = {  }
    )
    Image(
        painter = painterResource(id = R.drawable.estrella_r),
        contentDescription = "Thona Seguros",
        modifier = Modifier
            .padding(2.dp)
            .fillMaxSize()
            .blur(4.dp),
        alpha = 0.07F
    )
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        AseguradoCuenta(
            usuario = respuestaLogin,
            infoUsuario = consultaInformacion,
            productos = consultaProductos,
            clickActualizacion = funciones::editaMailTel,
            clickCancelar ={
                navController.navigate(DatosPantalla.AseguradoCuenta.name) {
                    popUpTo(DatosPantalla.AseguradoCuenta.name) { inclusive = true }
                }
            },
            loadingProgressBar = loadingProgressBar
        )
        if(actualizoInfo){
            AlertaPopUp(
                titulo = "Actualización de información",
                mensaje = mensajeRespuesta,
                clicAceptar = { funciones.consultaInformacion(usuario = respuestaLogin.items.codUsuario, session = respuestaLogin.session.idSession); funciones.actualizoInfo.value = false; funciones.mensajeRespuesta.value = "" },
                clicCancelar = {  },
                colorRol = Institucional3,
                cantidadBotones = 1,
                texto1 = "Aceptar",
                texto2 = "Cancelar"
            )
        }
        if(seleccion == "Cambiar contraseña"){
            LaunchedEffect(key1 = Unit){
                navController.navigate(route = DatosPantalla.CambioContrasenaAgenteContratanteAsegurado.name){
                    funciones.seleccionMenu.value = ""
                }
            }
        }
        if(seleccion == "Cambiar token"){
            LaunchedEffect(key1 = Unit){
                navController.navigate(route = DatosPantalla.CambioTokenAgenteContratanteAsegurado.name){
                    funciones.seleccionMenu.value = ""
                    funciones.mensajeRespuesta.value = ""
                }
            }
        }
        if(seleccion == "Cerrar sesión"){
            AlertaPopUp(
                titulo = "Cerrar sesión",
                mensaje = "¿Desea cerrar sesión?",
                clicAceptar = { respuestaLogin.items.codUsuario.let { it1 -> funciones.cierraSesion(rol= respuestaLogin.items.rol,usuario = it1, respuestaLogin.session.idSession) }; funciones.seleccionMenu.value = ""; funciones.mensajeRespuesta.value = "" },
                clicCancelar = { funciones.seleccionMenu.value = "" },
                colorRol = Institucional3,
                cantidadBotones = 2,
                texto1 = "Aceptar",
                texto2 = "Cancelar"
            )
        }
        if(!funciones.sesionIniciada.value){
            LaunchedEffect(key1 = Unit){
                navController.navigate(route = DatosPantalla.Login.name){
                    funciones.reiniciar()
                }
            }
        }
    }
}

@Composable
fun PolizasAsegurado(loadingProgressBar: Boolean, respuestaLogin: Login, funciones: Funciones, consultaProductos: MyProducto, navController: NavController, seleccionoPoliza: Boolean){
    Column(verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally){
        ProgressBarLoading(isLoading = loadingProgressBar)
    }
    val mContext = LocalContext.current
    var backPressedCount by remember { mutableIntStateOf(0) }
    BackHandler(
        enabled = !loadingProgressBar,
        onBack = {
            if(!loadingProgressBar){
                if(backPressedCount < 1){
                    Toast.makeText(
                        mContext,
                        "Pulsa de nuevo para salir",
                        Toast.LENGTH_SHORT
                    ).show()
                }; backPressedCount += 1
            }
        }
    )
    if(backPressedCount > 1){
        AlertaPopUp(
            titulo = "Cerrar sesión",
            mensaje = "¿Desea cerrar sesión?",
            clicAceptar = { respuestaLogin.items.codUsuario.let { it1 -> funciones.cierraSesion(rol= respuestaLogin.items.rol,usuario = it1, respuestaLogin.session.idSession) }; funciones.seleccionMenu.value = ""; funciones.mensajeRespuesta.value = "" },
            clicCancelar = { funciones.seleccionMenu.value = "";  backPressedCount = 0},
            colorRol = Institucional3,
            cantidadBotones = 2,
            texto1 = "Aceptar",
            texto2 = "Cancelar"
        )
    }
    if(validaSesion(respuestaLogin)){
        Image(
            painter = painterResource(id = R.drawable.estrella_r),
            contentDescription = "Thona Seguros",
            modifier = Modifier
                .padding(2.dp)
                .fillMaxSize()
                .blur(4.dp),
            alpha = 0.07F
        )
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            if(existePromocion){
                var mostrar by remember { mutableStateOf(value = existePromocion) }
                if(mostrar){
                    AlertaPopUp(
                        titulo = "¡PROMOCIÓN UNICA!",
                        mensaje = "¡Contamos con una promoción unica para ti!\nDate prisa y obten un REGALO",
                        clicAceptar = { navController.navigate(route = DatosPantalla.PromocionAsegurado.name) },
                        clicCancelar = { mostrar = false },
                        colorRol = Institucional3,
                        cantidadBotones = 2,
                        texto1 = "Obtener",
                        texto2 = "Cancelar"
                    )
                }
            }
            AseguradoPolizas(
                usuario = respuestaLogin,
                productos = consultaProductos,
                clicPoliza = funciones::detallePoliza,
                loadingProgressBar = loadingProgressBar
            )
        }
    } else{
        LaunchedEffect(key1 = Unit){
            navController.navigate(route = DatosPantalla.Asegurado.name){
                funciones.reiniciar()
            }
        }
    }
    if(seleccionoPoliza){
        LaunchedEffect(key1 = Unit){
            navController.navigate(route = DatosPantalla.AseguradoDetallePoliza.name){
                funciones.seleccionoPoliza.value = false
            }
        }
    }
}

@Composable
fun DetalleFacturasAsegurado(loadingProgressBar: Boolean, navController: NavController, funciones: Funciones){
    Column(verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally){
        ProgressBarLoading(isLoading = loadingProgressBar)
    }
    BackHandler(
        enabled = !loadingProgressBar,
        onBack = { navController.navigate(route = DatosPantalla.AseguradoDetallePoliza.name) }
    )
    Image(
        painter = painterResource(id = R.drawable.estrella_r),
        contentDescription = "Thona Seguros",
        modifier = Modifier
            .padding(2.dp)
            .fillMaxSize()
            .blur(4.dp),
        alpha = 0.07F
    )
    Column {
        AseguradoDetalleFactura(
            loadingProgressBar = loadingProgressBar,
            funciones = funciones
        )
    }
}

@Composable
fun AseguradoTramites(loadingProgressBar: Boolean, respuestaLogin: Login, consultaProductos: MyProducto, funciones: Funciones, navController: NavController, tramite: (opTramite: Int)-> Unit){
    Column(verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally){
        ProgressBarLoading(isLoading = loadingProgressBar)
    }
    BackHandler(
        enabled = !loadingProgressBar,
        onBack = {  }
    )
    Image(
        painter = painterResource(id = R.drawable.estrella_r),
        contentDescription = "Thona Seguros",
        modifier = Modifier
            .padding(2.dp)
            .fillMaxSize()
            .blur(4.dp),
        alpha = 0.07F
    )
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        com.thona.thonaseguros.ui.pantallas.asegurado.AseguradoTramites(
            usuario = respuestaLogin,
            productos = consultaProductos,
            tramite = tramite,
            loadingProgressBar = loadingProgressBar
        )
        if(!funciones.sesionIniciada.value){
            LaunchedEffect(key1 = Unit){
                navController.navigate(route = DatosPantalla.Login.name){
                    funciones.reiniciar()
                }
            }
        }
    }
}

@Composable
fun DetalleDePolizasAsegurado(loadingProgressBar: Boolean, navController: NavController, funciones: Funciones, respuestaLogin: Login, consultaInformacion: InfoItem, detalleProducto: DetalleProducto, seleccionoBeneficiario: Boolean, seleccionoFactura: Boolean){
    Column(verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally){
        ProgressBarLoading(isLoading = loadingProgressBar)
    }
    BackHandler(
        enabled = !loadingProgressBar,
        onBack = { navController.navigate(route = DatosPantalla.AseguradoPolizas.name) }
    )
    if(validaSesion(respuestaLogin)){
        Image(
            painter = painterResource(id = R.drawable.estrella_r),
            contentDescription = "Thona Seguros",
            modifier = Modifier
                .padding(2.dp)
                .fillMaxSize()
                .blur(4.dp),
            alpha = 0.07F
        )
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            DetallePolizas(
                clicKEdicion = funciones::editaBeneficiario,
                clickFactura = funciones::seleccionaFactura,
                usuario = consultaInformacion,
                detallePoliza = detalleProducto,
                clickDescargaDocumento = funciones::descargaDocumento,
                clickEnviaPorCorreo = funciones::enviaDocCorreo,
                mensaje = funciones.mensajeRespuesta.value,
                muestraMensaje = funciones.muestraMensaje.value,
                funciones = funciones,
                loadingProgressBar = loadingProgressBar
            )
        }
        if(seleccionoBeneficiario){
            LaunchedEffect(key1 = Unit){
                navController.navigate(route = DatosPantalla.AseguradoBeneficiarios.name){
                    funciones.seleccionoBeneficiario.value = false
                }
            }
        }
        if(seleccionoFactura){
            LaunchedEffect(key1 = Unit){
                navController.navigate(route = DatosPantalla.AseguradoDetallesFacturas.name){
                    funciones.seleccionoFactura.value = false
                }
            }
        }
    } else{
        LaunchedEffect(key1 = Unit){
            navController.navigate(route = DatosPantalla.Asegurado.name){
                funciones.reiniciar()
            }
        }
    }
}
@Composable
fun BeneficiariosAsegurado(loadingProgressBar: Boolean, navController: NavController, detalleProducto: DetalleProducto, funciones: Funciones, listaParentescos: List<ParentescoItem>, aceptoMensaje: Int){
    Column(verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally){
        ProgressBarLoading(isLoading = loadingProgressBar)
    }
    BackHandler(
        enabled = !loadingProgressBar,
        onBack = { navController.navigate(route = DatosPantalla.AseguradoDetallePoliza.name) }
    )
    Image(
        painter = painterResource(id = R.drawable.estrella_r),
        contentDescription = "Thona Seguros",
        modifier = Modifier
            .padding(2.dp)
            .fillMaxSize()
            .blur(4.dp),
        alpha = 0.07F
    )
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        val viewModel = ExpandableListViewModel()
        detalleProducto.detalleBeneficiarios.forEach{beneficiario ->
            viewModel.agregaBeneficiario(beneficiario)
        }
        EdicionBeneficiarios(
            funciones = funciones,
            producto = detalleProducto,
            viewModel = viewModel,
            listaParentescos = listaParentescos,
            loadingProgressBar = loadingProgressBar
        )
    }
    if(aceptoMensaje == 10){
        AlertaPopUp(
            titulo = "Actualización de beneficiarios",
            mensaje = "Se concluyo con éxito la edición de beneficiarios",
            clicAceptar = { funciones.clickMensaje(11); funciones.muestraMensaje.value=false },
            clicCancelar = {  },
            colorRol = Institucional3,
            cantidadBotones = 1,
            texto1 = "Aceptar",
            texto2 = "Cancelar"
        )
    }
    if(aceptoMensaje == 11){
        LaunchedEffect(key1 = Unit){
            navController.navigate(route = DatosPantalla.AseguradoPolizas.name){
                funciones.opcionMensaje.intValue = 0
            }
        }
    }
}