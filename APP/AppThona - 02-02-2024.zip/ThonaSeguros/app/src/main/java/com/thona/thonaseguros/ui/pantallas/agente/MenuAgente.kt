package com.thona.thonaseguros.ui.pantallas.agente

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import com.thona.thonaseguros.datos.modelos.Login

@Composable
fun MenuAgente(
    usuario: Login
){
    Text(text = "Texto: ${usuario.control.textoRespuesta}, codigo: ${usuario.control.numeroRespuesta}")
    Text(text = "Datos: ${usuario.items.rol}")
}