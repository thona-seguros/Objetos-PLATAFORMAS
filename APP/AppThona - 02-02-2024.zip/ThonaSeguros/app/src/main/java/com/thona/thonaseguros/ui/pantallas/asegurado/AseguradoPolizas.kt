package com.thona.thonaseguros.ui.pantallas.asegurado

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Circle
import androidx.compose.material.icons.outlined.ArrowForwardIos
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.thona.thonaseguros.datos.modelos.Login
import com.thona.thonaseguros.datos.modelos.MyProducto
import com.thona.thonaseguros.ui.theme.Institucional1
import com.thona.thonaseguros.ui.theme.Institucional2
import com.thona.thonaseguros.ui.theme.Institucional3
import com.thona.thonaseguros.ui.theme.PolizaEMI
import com.thona.thonaseguros.ui.theme.PolizaPRE
import com.thona.thonaseguros.ui.theme.PolizaXRE

@Composable
fun AseguradoPolizas(
    usuario: Login,
    productos: MyProducto,
    clicPoliza: (usuario: String?, idPoliza: String?, session: Int) -> Unit,
    loadingProgressBar: Boolean
){
    var modifier = Modifier.alpha(alpha = 1F)
    if(loadingProgressBar){
        modifier = modifier.alpha(alpha = 0.8F)
    }
    val scrollState = rememberScrollState()
    Box(
        modifier
            .fillMaxWidth()
            .background(color = Institucional3)
    ) {
        Row(
            modifier = modifier
                .padding(horizontal = 8.dp)
                .align(Alignment.CenterStart),
            horizontalArrangement = Arrangement.Center
        ) {
            Text(
                text = usuario.items.nomUsuario,
                color = Color.White,
                fontSize = 11.sp
            )
        }
        Row(
            modifier = modifier
                .padding(horizontal = 8.dp)
                .align(Alignment.CenterEnd),
            horizontalArrangement = Arrangement.Center
        ) {
            Text(
                text = "No. Asegurado:${productos.idAsegurado.codAsegurado}",
                color = Color.White,
                fontSize = 11.sp
            )
        }
    }
    Column(
        modifier = modifier
            .verticalScroll(scrollState)
            .fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        var colorEstatus = Institucional1
        if(productos.productos.isNotEmpty()){
            productos.productos.forEach {
                when (it.statusPoliza){
                    "EMI" -> {
                        colorEstatus = PolizaEMI
                    }
                    "XRE" -> {
                        colorEstatus = PolizaXRE
                    }
                    "PRE" -> {
                        colorEstatus = PolizaPRE
                    }
                }
                Spacer(modifier = modifier.height(7.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = modifier.clickable { clicPoliza(usuario.items.codUsuario,it.idPoliza,usuario.session.idSession) }
                ){
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Row {
                            Icon(modifier = modifier, imageVector = Icons.Filled.Circle, contentDescription = "", tint = colorEstatus)
                        }
                    }
                    Spacer(modifier = modifier.width(10.dp))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Row {
                            Text(text = "Póliza")
                        }
                        Row {
                            Text(text = it.idPoliza)
                        }
                    }
                    Spacer(modifier = modifier.width(20.dp))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Row {
                            Text(text = "Tipo")
                        }
                        Row {
                            Text(text = it.idTipoSeguro)
                        }
                    }
                    Spacer(modifier = modifier.width(20.dp))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Row {
                            Text(text = "Vigencia")
                        }
                        Row {
                            Text(text = it.fechaVigencia)
                        }
                    }
                    Spacer(modifier = modifier.width(25.dp))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Row {
                            IconButton(onClick = { clicPoliza(usuario.items.codUsuario,it.idPoliza,usuario.session.idSession) }) {
                                Icon(modifier = modifier, imageVector = Icons.Outlined.ArrowForwardIos, contentDescription = "", tint = Institucional2)
                            }
                        }
                    }
                }
                Spacer(modifier = modifier.height(7.dp))
                Divider(color = Institucional3, thickness = 0.5.dp)
            }
        }
    }
}