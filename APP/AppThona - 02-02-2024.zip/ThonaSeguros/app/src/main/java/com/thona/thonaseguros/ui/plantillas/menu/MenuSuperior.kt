package com.thona.thonaseguros.ui.plantillas.menu

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.DpOffset
import androidx.compose.ui.unit.dp
import com.thona.thonaseguros.funciones.Funciones
import com.thona.thonaseguros.ui.plantillas.AlertaPopUp
import com.thona.thonaseguros.ui.theme.Institucional2
import com.thona.thonaseguros.ui.theme.tiempoMensaje
import com.thona.thonaseguros.ui.theme.tiempoSesion
import kotlinx.coroutines.delay


enum class DatosPantalla(val title: String) {
    Login(title = "Login"),
    CambioContrasenaAgenteContratanteAsegurado(title = "Cambio de contraseña"),
    CambioTokenAgenteContratanteAsegurado(title = "Cambio de token"),
    Contratante(title = "Login Contratante"),
    Agente(title = "Login Agente"),
    Asegurado(title = "Login Asegurado"),
    MenuAgente(title = "Menú Agente"),
    MenuContratante(title = "Menú Contratante"),
    AseguradoCuenta(title = "Cuenta"),
    AseguradoPolizas(title = "Pólizas"),
    AgenteContratanteAseguradoAsignaToken(title = "Asignación de token"),
    AseguradoTramites(title = "Trámites"),
    AseguradoDetallePoliza(title = "Detalles de Póliza"),
    AseguradoBeneficiarios(title = "Edición de beneficiarios"),
    AseguradoDetallesFacturas(title = "Detalles de facturas"),

    Registro(title = "Registro"),
    PromocionAsegurado(title = "Promoción única")

}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopBar(
    color: Color,
    pantallaActual: DatosPantalla,
    puedeRegresar: Boolean,
    accionRegresar: () -> Unit,
    modifier: Modifier = Modifier,
    actionItems: List<ActionItem>,
    accionItem: (String) -> Unit,
    funciones: Funciones
){
    /*Revisa si se esta tocando la pantalla*/
    /*val downTime = SystemClock.uptimeMillis()
    val eventTime = SystemClock.uptimeMillis() + 100
    val x = 0.0f
    val y = 0.0f
    val metaState = 0
    val motionEvent = MotionEvent.obtain(
        downTime,
        eventTime,
        MotionEvent.ACTION_MOVE,
        x,
        y,
        metaState
    )*/
    //val view = LocalView.current
    //val toca = view.dispatchTouchEvent(motionEvent)


    var timeLeft by remember { mutableIntStateOf(tiempoMensaje) }
    var isPaused by remember { mutableStateOf(true) }

    var tiempoSesion by remember { mutableIntStateOf(tiempoSesion) }
    var finaliza by remember { mutableStateOf(value = false) }

    isPaused = !funciones.loginCorrecto.value

    if(pantallaActual.title.contains("Login") || pantallaActual.title.contains("Registro") || pantallaActual.title.contains("Promoción")){
        timeLeft = tiempoMensaje
        tiempoSesion = com.thona.thonaseguros.ui.theme.tiempoSesion
        finaliza = false
    }

    LaunchedEffect(key1 = timeLeft, key2 = isPaused) {
        while (timeLeft > 0 && !isPaused) {
            delay(1000L)
            timeLeft--
        }
    }
    /*if(toca){
        timeLeft = tiempoMensaje
    }*/
    LaunchedEffect(key1 = tiempoSesion, key2 = isPaused){
        while (tiempoSesion > 0 && !finaliza){
            delay(1000L)
            tiempoSesion--
            if(tiempoSesion == 0) finaliza = true
        }
    }
    if(timeLeft == 0 && tiempoSesion != 0){
        isPaused = true
        AlertaPopUp(
            titulo = "¿Sigues ahí?",
            mensaje = "Tu sesión esta por finalizar. ¿Deseas continuar con la sesión?",
            clicAceptar = { timeLeft = tiempoMensaje },
            clicCancelar = { funciones.cierraSesion(rol = funciones.respuestaLogin.value.items.rol, usuario = funciones.respuestaLogin.value.items.codUsuario, session = funciones.respuestaLogin.value.session.idSession); funciones.seleccionMenu.value = ""; funciones.mensajeRespuesta.value = "" },
            colorRol = color,
            cantidadBotones = 2,
            texto1 = "Continuar",
            texto2 = "Cerrar sesión"
        )
    }
    if(tiempoSesion == 0){
        funciones.cierraSesion(rol = funciones.respuestaLogin.value.items.rol ,usuario = funciones.respuestaLogin.value.items.codUsuario, session = funciones.respuestaLogin.value.session.idSession); funciones.seleccionMenu.value = ""; funciones.mensajeRespuesta.value = ""
        AlertaPopUp(
            titulo = "Sesión finalizada",
            mensaje = "Por seguridad, tu sesión ha sido cerrada. Vuelva a iniciar sesión.",
            clicAceptar = {  },
            clicCancelar = {  },
            colorRol = color,
            cantidadBotones = 1,
            texto1 = "Aceptar",
            texto2 = ""
        )
    }

    CenterAlignedTopAppBar(
        title = {
            Text(
                text = pantallaActual.title,
                color = Color.White
            )
        },
        colors = TopAppBarDefaults.mediumTopAppBarColors(
            containerColor = color
        ),
        modifier = modifier,
        navigationIcon = {
            if (puedeRegresar) {
                IconButton(onClick = accionRegresar) {
                    Icon(
                        imageVector = Icons.Filled.ArrowBack,
                        contentDescription = "Atras"
                    )
                }
            }
            if(pantallaActual.title == "Cambio de contraseña" || pantallaActual.title == "Edición de beneficiarios"){
                IconButton(onClick = accionRegresar) {
                    Icon(
                        imageVector = Icons.Filled.ArrowBack,
                        contentDescription = "Atras",
                        tint = Color.White
                    )
                }
            } else if(!pantallaActual.title.contains("Login")){
                Image(
                    painter = painterResource(id = com.thona.thonaseguros.R.drawable.estrella_r),
                    contentDescription = "Thona Seguros",
                    modifier = Modifier
                        .size(50.dp)
                        .padding(6.dp),
                )
            }
            if(color == Institucional2 && !pantallaActual.title.contains("Login")){
                Image(
                    painter = painterResource(id = com.thona.thonaseguros.R.drawable.estrella_b),
                    contentDescription = "Thona Seguros",
                    modifier = Modifier
                        .size(50.dp)
                        .padding(6.dp)
                )
            }
        },
        actions = {
            if(pantallaActual == DatosPantalla.AseguradoCuenta){
                val (iconos, opciones) = actionItems.partition { it.icono != null }
                iconos.forEach{
                    IconButton(onClick = { it.accion }, enabled = true) {
                        Icon(imageVector = it.icono!!, contentDescription = it.nombre, tint = Color.White)
                    }
                }
                val (isExpanded, setExpanded) = remember { mutableStateOf(false) }
                OverflowMenuAction(isExpanded,setExpanded,opciones,accionItem)
            }
        }
    )
}


data class ActionItem(
    val nombre: String,
    val icono: ImageVector? = null,
    val accion: () -> Unit,
    val orden: Int
)

@Composable
fun OverflowMenuAction(
    expanded: Boolean,
    setExpanded: (Boolean) -> Unit,
    opciones: List<ActionItem>,
    click: (String) -> Unit
) {
    IconButton(onClick = { setExpanded(true) }) {
        Icon(imageVector = Icons.Filled.MoreVert, contentDescription = "Ver más", tint = Color.White)
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { setExpanded(false) },
            offset = DpOffset(x = 0.dp, y = 4.dp)
        ) {
            opciones.forEach { option ->
                DropdownMenuItem(
                    onClick = {
                        click(option.nombre);setExpanded(false)
                    },
                    text = {Text(text = option.nombre)}
                )
            }
        }
    }
}

val itemsMenu = listOf(
    ActionItem(
        "Cambiar contraseña",
        accion = {  },
        orden = 1
    ),
    ActionItem(
        "Cambiar token",
        accion = {  },
        orden = 2
    ),
    ActionItem(
        nombre = "Cerrar sesión",
        accion = {  },
        orden = 3
    )
)