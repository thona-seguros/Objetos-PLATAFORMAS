package com.thona.thonaseguros.funciones

import android.app.DownloadManager
import android.content.Context
import android.location.Location
import android.net.Uri
import android.os.Environment
import android.util.Log
import android.widget.Toast
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.thona.thonaseguros.datos.cipher.encriptar
import com.thona.thonaseguros.datos.cipher.textoAleatorio
import com.thona.thonaseguros.datos.modelos.AltaRegistro
import com.thona.thonaseguros.datos.modelos.Control
import com.thona.thonaseguros.datos.modelos.ControlRegistro
import com.thona.thonaseguros.datos.modelos.DetalleBeneficiarioItem
import com.thona.thonaseguros.datos.modelos.DetalleCoberturaItem
import com.thona.thonaseguros.datos.modelos.DetalleMenuItem
import com.thona.thonaseguros.datos.modelos.DetalleProducto
import com.thona.thonaseguros.datos.modelos.DetalleProductoItem
import com.thona.thonaseguros.datos.modelos.InfoItem
import com.thona.thonaseguros.datos.modelos.Login
import com.thona.thonaseguros.datos.modelos.LoginItem
import com.thona.thonaseguros.datos.modelos.ModeloObteieneIP
import com.thona.thonaseguros.datos.modelos.ModeloVerificaDato
import com.thona.thonaseguros.datos.modelos.MyProdcutoItem
import com.thona.thonaseguros.datos.modelos.MyProducto
import com.thona.thonaseguros.datos.modelos.ParentescoItem
import com.thona.thonaseguros.datos.modelos.Sesion
import com.thona.thonaseguros.datos.modelos.SesionItem
import com.thona.thonaseguros.datos.modelos.VerificaDatoItem
import com.thona.thonaseguros.datos.modelos.VerificaDatos
import com.thona.thonaseguros.datos.modelos.EmailsItem
import com.thona.thonaseguros.datos.modelos.FacturaItem
import com.thona.thonaseguros.datos.modelos.IdUnicoItem
import com.thona.thonaseguros.datos.modelos.LoginToken
import com.thona.thonaseguros.datos.modelos.TelsItem
import com.thona.thonaseguros.datos.modelos.Ubicacion
import com.thona.thonaseguros.datos.webServices.ConexionAPILocal
import com.thona.thonaseguros.datos.webServices.ConexionIP
import com.thona.thonaseguros.datos.webServices.ConexionRetrofit
import com.thona.thonaseguros.datos.webServices.ConexionRetrofit.url
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.time.LocalTime


class Funciones: ViewModel() {
    private val ubicacion = mutableStateOf(value = Ubicacion("", ""))
    private val ip = mutableStateOf(value = ModeloObteieneIP(""))

    val urlCaratula = mutableStateOf(value = "")

    val opcionMensaje = mutableIntStateOf(value = 0)
    val progressBar = mutableStateOf(value = false)
    private var respuestaServicio = mutableStateOf(value = false)
    val mensajeRespuesta = mutableStateOf(value = "")

    val facturaSeleccionada = mutableStateOf(value = FacturaItem(0,"","",0.0,"","",0,""))

    //SELECCIÓN DE ROL
    val rolLogin = mutableStateOf(value = "")

    //INGRESO CON BIOMETRICOS
    val biometricos = mutableStateOf(value = false)

    //SERVICIO DE LOGIN
    val respuestaLogin =
        mutableStateOf(value = Login(SesionItem(0), LoginItem("", "", "", "",""), Control("", "")))
    val loginCorrecto = mutableStateOf(value = false)

    val datosParaInicioToken = mutableStateOf(value = LoginToken("","",""))
    val pideToken = mutableStateOf(value = false)

    val asignaPassword = mutableStateOf(value = false)

    //HORA DEL CELULAR
    private val tiempoLocal = mutableStateOf(value = LocalTime.now())

    //SELECCION DEL MENU
    val seleccionMenu = mutableStateOf("")

    //SERVICIO DE CAMBIO DE CONTRASEÑA
    val respuestaCambioContrasena = mutableStateOf(value = Control("", ""))
    val cambioCorrecto = mutableStateOf(value = false)

    //SERVICIO DE CAMBIO DE TOKEN
    private val respuestaCambioToken = mutableStateOf(value = Control("", ""))
    val cambioCorrectoToken = mutableStateOf(value = false)

    //ESTADO DE LA SESIÓN
    val sesionIniciada = mutableStateOf(value = false)

    //CONSULTA DE MI INFORMACIÓN
    val miInformacion = mutableStateOf(
        value = InfoItem(
            "", "", "", "", "",
            listOf(TelsItem(0, "", 0)), listOf(EmailsItem("", "", 0)), "", 0
        )
    )

    /*DATOS DE OPENPAY PARA LA VALIDACIÓN*/
    val iDAntiFraude = mutableStateOf(value = "")
    val tokenPago = mutableStateOf(value = "")

    //CONSULTA DE PRODUCTOS
    val misProductos = mutableStateOf(
        value = MyProducto(
            IdUnicoItem(0), listOf(MyProdcutoItem("", "", "", "", "")),
            Control("", "")
        )
    )

    //DETALLES DE PRODUCTO
    val detallesDePoliza = mutableStateOf(
        value = DetalleProducto(
            DetalleProductoItem("", "", "", "", "", "", "", "", "", "", ""),
            listOf(DetalleMenuItem("", 0)),
            listOf(DetalleCoberturaItem("", "", "")),
            listOf(DetalleBeneficiarioItem("", 0, "")),
            listOf(FacturaItem(0, "", "", 0.0, "", "", 0, "")),
            Control("", "")
        )
    )

    //VERIFICACION DE RFC Y DATO UNICO
    val datosVerificacion = mutableStateOf(
        value = ModeloVerificaDato(VerificaDatos(
            VerificaDatoItem("","","","",""),
            Control("","")
        ))
    )

    //ALTA DE REGISTRO
    var registroConcluido = mutableStateOf(
        value = AltaRegistro(
            ControlRegistro("","","","")
        )
    )

    //CATALOGO DE PARENTESCOS
    val catalogoParentescos = mutableStateOf(value = listOf(ParentescoItem("", "")))

    //
    val muestraMensaje = mutableStateOf(value = false)

    //
    val opcionTramite = mutableIntStateOf(value = 0)

    //ACTUALIZA INFORMACIÓN
    val actualizoInfo = mutableStateOf(value = false)
    val seleccionoPoliza = mutableStateOf(value = false)
    val seleccionoBeneficiario = mutableStateOf(value = false)
    val seleccionoFactura = mutableStateOf(value = false)
    private val loginRequestLiveData = MutableLiveData<Boolean>()

    //REINICIO DE VARIABLES LOGIN
    fun reiniciar() {
        progressBar.value = true
        rolLogin.value = ""
        respuestaLogin.value = Login(SesionItem(0), LoginItem("", "", "", "", ""), Control("", ""))
        mensajeRespuesta.value = ""
        progressBar.value = false
    }

    //REINICIO DE VARIABLES
    fun reiniciaTodo() {
        ubicacion.value = Ubicacion("", "")
        ip.value = ModeloObteieneIP("")
        opcionMensaje.intValue = 0
        progressBar.value = false
        respuestaServicio.value = false
        mensajeRespuesta.value = ""
        facturaSeleccionada.value = FacturaItem(0,"","",0.0,"","",0,"")
        rolLogin.value = ""
        biometricos.value = false
        respuestaLogin.value = Login(SesionItem(0), LoginItem("", "", "", "",""), Control("", ""))
        loginCorrecto.value = false
        datosParaInicioToken.value = LoginToken("","","")
        pideToken.value = false
        tiempoLocal.value = LocalTime.now()
        seleccionMenu.value = ""
        respuestaCambioContrasena.value = Control("", "")
        cambioCorrecto.value = false
        respuestaCambioToken.value = Control("", "")
        cambioCorrectoToken.value = false
        sesionIniciada.value = false
        miInformacion.value = InfoItem(
                "", "", "", "", "",
                listOf(TelsItem(0, "", 0)), listOf(EmailsItem("", "", 0)), "", 0)
        misProductos.value = MyProducto(
                IdUnicoItem(0), listOf(MyProdcutoItem("", "", "", "", "")),
                Control("", ""))
        detallesDePoliza.value = DetalleProducto(
                DetalleProductoItem("", "", "", "", "", "", "", "", "", "", ""),
                listOf(DetalleMenuItem("", 0)),
                listOf(DetalleCoberturaItem("", "", "")),
                listOf(DetalleBeneficiarioItem("", 0, "")),
                listOf(FacturaItem(0, "", "", 0.0, "", "", 0, "")),
                Control("", ""))
        datosVerificacion.value = ModeloVerificaDato(VerificaDatos(
                VerificaDatoItem("","","","",""),
                Control("","")))
        registroConcluido.value = AltaRegistro(
                ControlRegistro("","","",""))
        catalogoParentescos.value = listOf(ParentescoItem("", ""))
        muestraMensaje.value = false
        actualizoInfo.value = false
        seleccionoPoliza.value = false
        seleccionoBeneficiario.value = false
        seleccionoFactura.value = false
    }

    //SELECCIÓN DE ROL
    fun selecRol(rol: String) {
        rolLogin.value = rol
    }

    fun datosUbicacion(datos: Location?) {
        if (datos?.latitude != null) {
            ubicacion.value.lat = datos.latitude.toString()
            ubicacion.value.lon = datos.longitude.toString()
        }
    }

    fun obtieneIP() {
        if (ip.value.ip.isEmpty()) {
            viewModelScope.launch(Dispatchers.IO) {
                try {
                    val authService = ConexionIP.getAuthService()
                    val responseService = authService.obtieneIP("https://api.ipify.org?format=json")
                    if (responseService.isSuccessful) {
                        ip.value = responseService.body()?.copy()!!
                    } else {
                        ip.value.ip = "0"
                    }
                } catch (e: Exception) {
                    ip.value.ip = "0"
                    Log.d("Obtiene IP", "Error DE CONEXIÓN", e)
                    mensajeRespuesta.value = "No se realizó la conexión, verifica la conectividad."
                }
            }
        }
    }

    //CREA REGISTRO
    fun enviaRegistro (usuario: String, rol: String, mail: String, tel: String, contra: String, idUnico: Int){
        progressBar.value = true
        var rolEnvio = 0
        when(rol){
            "Agente" -> { rolEnvio = 1 }
            "Contratante" -> { rolEnvio = 2 }
            "Asegurado" -> { rolEnvio = 3 }
        }
        val dato = encriptar(contra,usuario)
        val hash = url
        //val hash = (100000..999999).random()
        //println("Numero aleatorio generado: $hash")
        val jsonObject = JSONObject()
        jsonObject.put("Rol",rolEnvio)
        jsonObject.put("EmailNew",mail)
        jsonObject.put("EmailOld",mail)
        jsonObject.put("TelNew",tel)
        jsonObject.put("TelOld",tel)
        jsonObject.put("Contrasena",dato)
        jsonObject.put("idUnico",idUnico)
        jsonObject.put("HashAndroid",hash)
        println("JSON ENVIO:: $jsonObject")
        val jsonObjectString = jsonObject.toString()
        val requestBody = jsonObjectString.toRequestBody("application/json".toMediaTypeOrNull())
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val authService = ConexionRetrofit.getAuthService()
                val responseService = authService.enviaRegistro(requestBody)
                if (responseService.isSuccessful){
                    registroConcluido.value = responseService.body()!!.altaRegistro.copy()
                    correoValidacion(servicio = registroConcluido.value.control.servicioCorreo, link = registroConcluido.value.control.enlace)
                }
                progressBar.value = false
            }
            catch (e: Exception){
                progressBar.value = false
                Log.d("Consulta de RFC", "Error DE CONEXIÓN", e)
                mensajeRespuesta.value = "No se realizó la conexión, verifica la conectividad."
            }
        }
    }

    //ENVIA CORREO PARA VALIDACIÓN
    private fun correoValidacion (servicio: String, link: String) {
        progressBar.value = true
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val authService = ConexionRetrofit.getAuthService()
                authService.enviaMailRegistro(url = "$url$servicio$url$link")
                progressBar.value = false
            } catch (e: Exception) {
                progressBar.value = false
                Log.d("Envio de mail", "Error DE CONEXIÓN", e)
                mensajeRespuesta.value = "No se realizó la conexión, verifica la conectividad."
            }
        }
    }

    //VALIDACIÓN DE RFC Y POLIZA
    fun verificaDatos (sRFC: String, datoUnico: String, rol: String) {
        progressBar.value = true
        var rolEnvio = 0
        when(rol){
            "Agente" -> { rolEnvio = 1 }
            "Contratante" -> { rolEnvio = 2 }
            "Asegurado" -> { rolEnvio = 3 }
        }
        val jsonObject = JSONObject()
        jsonObject.put("RFC",sRFC)
        jsonObject.put("Rol",rolEnvio)
        jsonObject.put("idUnico",datoUnico)
        val jsonObjectString = jsonObject.toString()
        println("JSON OBJECT:: $jsonObject")
        val requestBody = jsonObjectString.toRequestBody("application/json".toMediaTypeOrNull())
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val authService = ConexionRetrofit.getAuthService()
                delay(1500L)
                val responseService = authService.verificaDatos(requestBody)
                if (responseService.isSuccessful){
                    datosVerificacion.value = responseService.body()?.copy()!!
                }
                progressBar.value = false
            }
            catch (e: Exception){
                progressBar.value = false
                Log.d("Consulta de RFC", "Error DE CONEXIÓN", e)
                mensajeRespuesta.value = "No se realizó la conexión, verifica la conectividad."
            }
        }
    }

    //CONEXIÓN PARA LOGIN
    fun conexion(rol: String, usuario: String, contra: String, store: Sesion) {
        progressBar.value = true
        val dato = encriptar(contra,usuario)
        val jsonObject = JSONObject()
        jsonObject.put("Usuario", usuario)
        jsonObject.put("Contrasena", dato)
        jsonObject.put("Rol", rol)
        jsonObject.put("Dispositivo", android.os.Build.MODEL)
        jsonObject.put("VersionSis", android.os.Build.VERSION.SDK_INT)
        jsonObject.put("DirIp", ip.value.ip)
        jsonObject.put("DirMac", null)
        jsonObject.put("Latitud", ubicacion.value.lat)
        jsonObject.put("Longitud", ubicacion.value.lon)
        jsonObject.put("SistemaOp", "Android")
        val jsonObjectString = jsonObject.toString()
        println("JSON ENVIO:: $jsonObjectString")
        val requestBody = jsonObjectString.toRequestBody("application/json".toMediaTypeOrNull())
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val authService = ConexionRetrofit.getAuthService()
                val responseService = authService.login(requestBody)
                if (responseService.isSuccessful) {
                    respuestaServicio.value = true
                    delay(1500L)
                    respuestaLogin.value = responseService.body()!!.login.copy()
                    when (respuestaLogin.value.control.numeroRespuesta) {
                        "1" -> {
                            loginCorrecto.value = true
                            tiempoLocal.value = LocalTime.now()
                            CoroutineScope(Dispatchers.IO).launch {
                                store.saveUser(usuario)
                                store.savePass(contra)
                            }
                            respuestaLogin.value.items.codUsuario.let {
                                consultaInformacion(
                                    it,
                                    respuestaLogin.value.session.idSession
                                )
                            }
                            respuestaLogin.value.items.codUsuario.let {
                                consultaProductos(
                                    it,
                                    respuestaLogin.value.session.idSession
                                )
                            }
                            sesionIniciada.value = true
                        }
                        "3" -> {
                            datosParaInicioToken.value.usuario = usuario
                            datosParaInicioToken.value.rol = rol
                            datosParaInicioToken.value.contra = contra
                            pideToken.value = true
                        }
                        "6" -> {
                            asignaPassword.value = true
                        }
                    }
                } else {
                    responseService.errorBody()?.let { error ->
                        respuestaLogin.value = Login(
                            SesionItem(0),
                            LoginItem("", "", "", "", ""),
                            Control("88", "Error al iniciar sesión")
                        )
                        delay(1500L)
                        error.close()
                    }
                }
                progressBar.value = false
                loginRequestLiveData.postValue(responseService.isSuccessful)
            } catch (e: Exception) {
                progressBar.value = false
                Log.d("LOGIN", "Error DE CONEXIÓN", e)
                respuestaLogin.value = Login(
                    SesionItem(0),
                    LoginItem("", "", "", "", ""),
                    Control("99", "No se realizó la conexión, verifica la conectividad.")
                )
            }
        }
    }

    fun confirmaToken (rol: String, sRFC: String,token: String, terminos: Int){
        progressBar.value = true
        val dato = encriptar(token,sRFC)
        val jsonObject = JSONObject()
        jsonObject.put("RFC",sRFC)
        jsonObject.put("Token",dato)
        jsonObject.put("Rol",rol)
        jsonObject.put("Terminos",terminos)
        val jsonObjectString = jsonObject.toString()
        println("JSON ENVIO:: $jsonObjectString")
        val requestBody = jsonObjectString.toRequestBody("application/json".toMediaTypeOrNull())
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val authService = ConexionRetrofit.getAuthService()
                val responseService = authService.confirmaToken(requestBody)
                if (responseService.isSuccessful) {
                    delay(1500L)
                    muestraMensaje.value = true
                    mensajeRespuesta.value = responseService.body()!!.confirmaToken.control.textoRespuesta
                    if(responseService.body()!!.confirmaToken.control.numeroRespuesta == "1"){
                        loginCorrecto.value = true
                    }
                } else {
                    responseService.errorBody()?.let { error ->
                        mensajeRespuesta.value = "Error al ejecutar el servicio"
                        delay(1500L)
                        error.close()
                    }
                }
                loginRequestLiveData.postValue(responseService.isSuccessful)
                progressBar.value = false
            } catch (e: Exception) {
                progressBar.value = false
                Log.d("Confirma token", "Error DE CONEXIÓN", e)
                mensajeRespuesta.value = "No se realizó la conexión, verifica la conectividad."
            }
        }
    }

    fun seleccionMenuTop(opcion: String) {
        seleccionMenu.value = opcion
    }

    fun cambioContrasena (usuario: String, rol: String, anterior: String, nueva: String, session: Int?){
        progressBar.value = true
        val dato = encriptar(anterior,usuario)
        val datoNuevo = encriptar(nueva,usuario)
        val jsonObject = JSONObject()
        jsonObject.put("Usuario",usuario)
        jsonObject.put("Rol",rol)
        jsonObject.put("Anterior",dato)
        jsonObject.put("Nueva",datoNuevo)
        jsonObject.put("Session",session)
        val jsonObjectString = jsonObject.toString()
        val requestBody = jsonObjectString.toRequestBody("application/json".toMediaTypeOrNull())
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val authService = ConexionRetrofit.getAuthService()
                val responseService = authService.cambioPassword(requestBody)
                if (responseService.isSuccessful) {
                    respuestaServicio.value = true
                    delay(1500L)
                    mensajeRespuesta.value = responseService.body()!!.cambioPassword.control.textoRespuesta
                    respuestaCambioContrasena.value = responseService.body()!!.cambioPassword.control.copy()
                    cambioCorrecto.value = respuestaCambioContrasena.value.numeroRespuesta == "1"
                } else {
                    responseService.errorBody()?.let { error ->
                        mensajeRespuesta.value = "Error al ejecutar el servicio"
                        delay(1500L)
                        error.close()
                    }
                }
                loginRequestLiveData.postValue(responseService.isSuccessful)
                progressBar.value = false
            } catch (e: Exception) {
                progressBar.value = false
                Log.d("Cambio password", "Error DE CONEXIÓN", e)
                mensajeRespuesta.value = "No se realizó la conexión, verifica la conectividad."
            }
        }
    }

    fun cambioToken (usuario: String, rol: String, anterior: String, nueva: String, session: Int){
        progressBar.value = true
        val dato = encriptar(anterior,usuario)
        val datoNuevo = encriptar(nueva,usuario)
        val jsonObject = JSONObject()
        jsonObject.put("Usuario",usuario)
        jsonObject.put("Rol",rol)
        jsonObject.put("Anterior",dato)
        jsonObject.put("Nueva",datoNuevo)
        jsonObject.put("Session",session)
        val jsonObjectString = jsonObject.toString()
        val requestBody = jsonObjectString.toRequestBody("application/json".toMediaTypeOrNull())
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val authService = ConexionRetrofit.getAuthService()
                val responseService = authService.cambioToken(requestBody)
                if (responseService.isSuccessful) {
                    respuestaServicio.value = true
                    delay(1500L)
                    mensajeRespuesta.value = responseService.body()!!.cambioToken.control.textoRespuesta
                    respuestaCambioToken.value = responseService.body()!!.cambioToken.control.copy()
                    cambioCorrectoToken.value = respuestaCambioToken.value.numeroRespuesta == "1"
                } else {
                    responseService.errorBody()?.let { error ->
                        mensajeRespuesta.value = "Error al ejecutar el servicio"
                        delay(1500L)
                        error.close()
                    }
                }
                loginRequestLiveData.postValue(responseService.isSuccessful)
                progressBar.value = false
            } catch (e: Exception) {
                progressBar.value = false
                Log.d("Cambio token", "Error DE CONEXIÓN", e)
                mensajeRespuesta.value = "No se realizó la conexión, verifica la conectividad."
            }
        }
    }

    fun recuperaTok(op: Int){
        if(op == 1){
            muestraMensaje.value = false
            cierraSesion(respuestaLogin.value.items.rol,respuestaLogin.value.items.codUsuario,respuestaLogin.value.session.idSession)
        }
    }

    //RECUPERAR TOKEN
    fun recuperaToken(usuario: String, rol: String) {
        progressBar.value = true
        val sesion = respuestaLogin.value.session.idSession
        val jsonObject = JSONObject()
        jsonObject.put("Usuario", usuario)
        jsonObject.put("Rol",rol)
        jsonObject.put("Session",sesion)
        val jsonObjectString = jsonObject.toString()
        println("JSON OBJECT:: $jsonObject")
        val requestBody = jsonObjectString.toRequestBody("application/json".toMediaTypeOrNull())
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val authService = ConexionRetrofit.getAuthService()
                val responseService = authService.recuperaToken(requestBody)
                if (responseService.isSuccessful){
                    if(responseService.body()?.recuperaToken?.control?.numeroRespuesta == "1"){
                        muestraMensaje.value = true
                    }
                }
                progressBar.value = false
            }
            catch (e: Exception){
                progressBar.value = false
                Log.d("Consulta de RFC", "Error DE CONEXIÓN", e)
                mensajeRespuesta.value = "No se realizó la conexión, verifica la conectividad."
            }
        }
    }

    //RECUPERAR CONTRASEÑA
    fun recuperaContrasenia(rol: String, usuario: String){
        progressBar.value = true
        val contra = textoAleatorio(8)
        val contraEn = encriptar(contra,usuario)
        val jsonObject = JSONObject()
        jsonObject.put("RFC",usuario)
        jsonObject.put("Rol",rol)
        jsonObject.put("PasswordE",contraEn)
        jsonObject.put("PasswordN",contra)
        val jsonObjectString = jsonObject.toString()
        val requestBody = jsonObjectString.toRequestBody("application/json".toMediaTypeOrNull())
        println("JSON OBJECT:: $jsonObject")
        viewModelScope.launch(Dispatchers.IO) {
            try{
                val authService = ConexionRetrofit.getAuthService()
                val responseService = authService.recuperaPassword(requestBody)
                if (responseService.isSuccessful){
                    muestraMensaje.value = true
                    mensajeRespuesta.value = responseService.body()?.recuperaPassword?.control?.textoRespuesta.toString()
                }
                progressBar.value = false
            } catch (e: Exception){
                progressBar.value = false
                Log.d("Cierre de sesión", "Error DE CONEXIÓN", e)
                mensajeRespuesta.value = "No se realizó la conexión, verifica la conectividad."
            }
        }
    }

    fun cierraSesion (rol: String, usuario: String, session: Int) {
        progressBar.value = true
        val jsonObject = JSONObject()
        jsonObject.put("Usuario",usuario)
        jsonObject.put("Rol",rol)
        jsonObject.put("Session",session)
        val jsonObjectString = jsonObject.toString()
        println("JSON OBJECT:: $jsonObject")
        val requestBody = jsonObjectString.toRequestBody("application/json".toMediaTypeOrNull())
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val authService = ConexionRetrofit.getAuthService()
                val responseService = authService.cierreSesion(requestBody)
                if (responseService.isSuccessful){
                    respuestaServicio.value = true
                    delay(1500L)
                    sesionIniciada.value = false
                    reiniciar()
                    loginCorrecto.value = false
                }
                progressBar.value = false
            } catch (e: Exception) {
                progressBar.value = false
                Log.d("Cierre de sesión", "Error DE CONEXIÓN", e)
                mensajeRespuesta.value = "No se realizó la conexión, verifica la conectividad."
            }
        }
    }

    fun consultaInformacion (usuario: String, session: Int) {
        progressBar.value = true
        val jsonObject = JSONObject()
        jsonObject.put("Usuario",usuario)
        jsonObject.put("Session",session)
        val jsonObjectString = jsonObject.toString()
        println("JSON OBJECT:: $jsonObject")
        val requestBody = jsonObjectString.toRequestBody("application/json".toMediaTypeOrNull())
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val authService = ConexionRetrofit.getAuthService()
                val responseService = authService.consultaInfo(requestBody)
                if (responseService.isSuccessful){
                    miInformacion.value = responseService.body()!!.myInfo.datos.copy()
                }
                progressBar.value = false
            }
            catch (e: Exception){
                progressBar.value = false
                Log.d("Consulta de información", "Error DE CONEXIÓN", e)
                mensajeRespuesta.value = "No se realizó la conexión, verifica la conectividad."
            }
        }
    }

    fun consultaProductos(usuario: String, session: Int){
        progressBar.value = true
        listadoParentescos()
        val jsonObject = JSONObject()
        jsonObject.put("Usuario",usuario)
        jsonObject.put("Session",session)
        val jsonObjectString = jsonObject.toString()
        println("JSON OBJECT:: $jsonObject")
        val requestBody = jsonObjectString.toRequestBody("application/json".toMediaTypeOrNull())
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val authService = ConexionRetrofit.getAuthService()
                val responseService = authService.consultaProductos(requestBody)
                if (responseService.isSuccessful){
                    misProductos.value = responseService.body()!!.myProducto.copy()
                }
                progressBar.value = false
            }
            catch (e: Exception){
                progressBar.value = false
                Log.d("Consulta de productos", "Error DE CONEXIÓN", e)
                mensajeRespuesta.value = "No se realizó la conexión, verifica la conectividad."
            }
        }
    }

    fun detallePoliza(usuario: String?, idPoliza: String?, idSession: Int) {
        progressBar.value = true
        val numPol = "$idPoliza".substringBefore("-")
        val idetPol = "$idPoliza".substringAfter("-")
        val jsonObject = JSONObject()
        jsonObject.put("Usuario",usuario)
        jsonObject.put("idPoliza",numPol)
        jsonObject.put("idetPol",idetPol)
        jsonObject.put("Session",idSession)
        val jsonObjectString = jsonObject.toString()
        println("JSON OBJECT:: $jsonObject")
        val requestBody = jsonObjectString.toRequestBody("application/json".toMediaTypeOrNull())
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val authService = ConexionRetrofit.getAuthService()
                val responseService = authService.detalleProducto(requestBody)
                if(responseService.isSuccessful){
                    detallesDePoliza.value = responseService.body()!!.detalleProducto.copy()
                    seleccionoPoliza.value = true
                }
                progressBar.value = false
            } catch (e: Exception) {
                progressBar.value = false
                Log.d("Detalles de póliza", "Error DE CONEXIÓN", e)
                mensajeRespuesta.value = "No se realizó la conexión, verifica la conectividad."
            }
        }
    }

    fun editaMailTel(correo: String?, cCorrelativo: Int, telefono: String?, tCorrelativo: Int){
        progressBar.value = true
        val actualizacionObject = JSONObject()
        actualizacionObject.put("Usuario", respuestaLogin.value.items.codUsuario)
        actualizacionObject.put("Session", respuestaLogin.value.session.idSession)
        actualizacionObject.put("Telefono", telefono)
        actualizacionObject.put("CorrelativoTel", tCorrelativo)
        actualizacionObject.put("Correo", correo)
        actualizacionObject.put("CorrelativoMail", cCorrelativo)
        val jsonObjectString = actualizacionObject.toString()
        println("JSON OBJECT:: $jsonObjectString")
        val requestBody = jsonObjectString.toRequestBody("application/json".toMediaTypeOrNull())
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val authService = ConexionRetrofit.getAuthService()
                val responseService = authService.actualizaInfo(requestBody)
                if(responseService.isSuccessful){
                    actualizoInfo.value = true
                    mensajeRespuesta.value = responseService.body()?.cambioPassword?.control?.textoRespuesta.toString()
                }
                progressBar.value = false
            } catch (e: Exception) {
                progressBar.value = false
                Log.d("Actualización de información", "Error DE CONEXIÓN", e)
                mensajeRespuesta.value = "No se realizó la conexión, verifica la conectividad."
            }
        }
    }

    private fun listadoParentescos(){
        progressBar.value = true
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val authService = ConexionRetrofit.getAuthService()
                val responseService = authService.catalogoParentescos()
                if(responseService.isSuccessful){
                    catalogoParentescos.value = responseService.body()!!.catalogoParentescos.listaParentescos
                }
                progressBar.value = false
            } catch (e: Exception) {
                progressBar.value = false
                Log.d("Catalogo de parentescos", "Error DE CONEXIÓN", e)
                mensajeRespuesta.value = "No se realizó la conexión, verifica la conectividad."
            }
        }
    }

    fun generaCaratula(idPoliza: Int, contexto: Context){
        println("Poliza a generar: $idPoliza")
        progressBar.value = true
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val authService = ConexionAPILocal.getAuthService()
                val responseService = authService.obtieneCaratula(idPoliza)
                println("response obtiene ${responseService.isSuccessful}  body-> ${responseService.body()}")
                if (responseService.isSuccessful){
                    urlCaratula.value = responseService.body()?.documento.toString()
                    println("caratula -> ${urlCaratula.value}")
                    if(urlCaratula.value.isNotEmpty()){
                        descargaDocumento(urlCaratula.value,"Poliza", "Descarga de póliza", contexto)
                    }
                }
                progressBar.value = false
            }
            catch (e: Exception){
                progressBar.value = false
                Log.d("Imprime poliza", "Error DE CONEXIÓN", e)
                mensajeRespuesta.value = "No se realizó la conexión, verifica la conectividad."
            }
        }
    }

    fun descargaDocumento(link:String, title:String, descripcion: String, context: Context){
        progressBar.value = true
        println("url: $link")
        val request = DownloadManager.Request(Uri.parse(link))
        request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI or DownloadManager.Request.NETWORK_MOBILE)
        request.setTitle(title)
        request.setDescription(descripcion)
        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
        request.setDestinationInExternalPublicDir(
            Environment.DIRECTORY_DOWNLOADS,
            "${System.currentTimeMillis()}")
        val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        manager.enqueue(request)
        progressBar.value = false
        Toast.makeText(
            context,
            "Documento descargado, verificar descargas.",
            Toast.LENGTH_SHORT
        ).show()
    }

    fun enviaDocCorreo(idPoliza: Int, subgrupo: Int){
        progressBar.value = true
        val envioObject = JSONObject()
        envioObject.put("idPoliza", idPoliza)
        envioObject.put("Session", respuestaLogin.value.session.idSession)
        envioObject.put("Usuario", respuestaLogin.value.items.codUsuario)
        envioObject.put("subGrupo", subgrupo)
        val jsonObjectString = envioObject.toString()
        println("JSON OBJECT:: $jsonObjectString")
        val requestBody = jsonObjectString.toRequestBody("application/json".toMediaTypeOrNull())
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val authService = ConexionRetrofit.getAuthService()
                val responseService = authService.enviaMail(requestBody)
                if(responseService.isSuccessful){
                    muestraMensaje.value = true
                    mensajeRespuesta.value = "Mensaje: ${responseService.body()?.envioMail?.control?.textoRespuesta}"
                }
                progressBar.value = false
            } catch (e: Exception) {
                progressBar.value = false
                Log.d("Obtiene poliza", "Error DE CONEXIÓN", e)
                mensajeRespuesta.value = "No se realizó la conexión, verifica la conectividad."
            }
        }
    }

    fun actualizaBeneficiarios(idPoliza: String, vlJson: String){
        progressBar.value = true
        val envioObject = JSONObject()
        envioObject.put("idPoliza", idPoliza.substringBefore("-").toInt())
        envioObject.put("idetPol", idPoliza.substringAfter("-").toInt())
        envioObject.put("Session", respuestaLogin.value.session.idSession)
        envioObject.put("Usuario", respuestaLogin.value.items.codUsuario)
        envioObject.put("codAseg", misProductos.value.idAsegurado.codAsegurado)
        envioObject.put("vl_Json", vlJson)
        val jsonObjectString = envioObject.toString()
        println("JSON OBJECT:: $jsonObjectString")
        val requestBody = jsonObjectString.toRequestBody("application/json".toMediaTypeOrNull())
        println("JSON ENVIO:: $requestBody")
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val authService = ConexionRetrofit.getAuthService()
                val responseService = authService.actualizaBeneficiarios(requestBody)
                if(responseService.isSuccessful){
                    muestraMensaje.value = true
                    mensajeRespuesta.value = "Mensaje: ${responseService.body()?.respuestaBeneficiarios?.control?.textoRespuesta}"
                }
                progressBar.value = false
            } catch (e: Exception) {
                progressBar.value = false
                Log.d("ACTUALIZO BENEFICIARIOS", "Error DE CONEXIÓN", e)
                mensajeRespuesta.value = "No se realizó la conexión, verifica la conectividad."
            }
        }
    }

    fun editaBeneficiario(){
        progressBar.value = true
        viewModelScope.launch(Dispatchers.IO) {
            delay(800L)
            seleccionoBeneficiario.value = true
            progressBar.value = false
        }
    }

    fun seleccionaFactura(factura: FacturaItem){
        progressBar.value = true
        viewModelScope.launch(Dispatchers.IO) {
            delay(800L)
            seleccionoFactura.value = true
            facturaSeleccionada.value = factura
            progressBar.value = false
        }
    }

    fun clickMensaje(seleccion :Int){
        opcionMensaje.intValue = seleccion
    }

    fun aplicaPago(poliza: Int, factura: Int, monto: Double, referencia: String, aprobacion: Int){
        progressBar.value = true
        val envioObject = JSONObject()
        envioObject.put("POLIZA", poliza)
        envioObject.put("FACTURA", factura)
        envioObject.put("MONTO", monto)
        envioObject.put("REFERENCIA_OPENPAY", referencia)
        envioObject.put("NUMERO_APROBACION", aprobacion)
        val jsonObjectString = envioObject.toString()
        println("JSON OBJECT:: $jsonObjectString")
        val requestBody = jsonObjectString.toRequestBody("application/json".toMediaTypeOrNull())
        println("JSON ENVIO:: $envioObject")
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val authService = ConexionAPILocal.getAuthService()
                val responseService = authService.aplicaCobranza(token = /*lkvfbbbyuzhkiumhzpcy*/"thdjuqzstbizttonshwz", body = requestBody)
                if(responseService.isSuccessful){
                    muestraMensaje.value = true
                    mensajeRespuesta.value = "Mensaje: ${responseService.body()?.aplicaCobranza?.control?.estatus} - ${responseService.body()?.aplicaCobranza?.control?.mensaje}"
                }
                progressBar.value = false
            } catch (e: Exception) {
                progressBar.value = false
                Log.d("APLICACIÓN DE PAGO", "Error DE CONEXIÓN", e)
                mensajeRespuesta.value = "No se realizó la conexión, verifica la conectividad."
            }
        }
    }

    fun creaReferencia(tipo: Int, poliza: Int, factura: Int, dispositivo: String?, token: String?){
        progressBar.value = true
        val envioObject = JSONObject()
        envioObject.put("TIPOREFERENCIA", tipo)
        envioObject.put("POLIZA", poliza)
        envioObject.put("FACTURA", factura)
        envioObject.put("DISPOSITIVO", dispositivo.toString())
        envioObject.put("PAGO", token.toString())
        val jsonObjectString = envioObject.toString()
        val requestBody = jsonObjectString.toRequestBody("Accept, application/json".toMediaTypeOrNull())
        println("JSON ENVIO:: $envioObject")
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val authService = ConexionAPILocal.getAuthService()
                val responseService = authService.creaReferencia(body = requestBody)
                if(responseService.isSuccessful){
                    muestraMensaje.value = true
                    mensajeRespuesta.value = responseService.body()?.textoRespuesta.toString()
                }
                progressBar.value = false
            } catch (e: Exception) {
                progressBar.value = false
                Log.d("APLICACIÓN DE PAGO", "Error DE CONEXIÓN", e)
                mensajeRespuesta.value = "No se realizó la conexión, verifica la conectividad."
            }
        }
    }

    //SELECCIÓN DE TRAMITE
    fun selecTramite(tramite: Int) {
        opcionTramite.intValue = tramite
    }
}