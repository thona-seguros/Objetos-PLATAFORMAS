package com.thona.thonaseguros.ui.theme

//TIEMPO MAXIMO PERMITIDO PARA LA SESIÓN (SEGUNDOS)
val tiempoSesion = 1200 //1200
val tiempoMensaje = 120 //300