package com.thona.thonaseguros.ui.navegacion

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.navigation.NavController
import com.thona.thonaseguros.datos.modelos.Login
import com.thona.thonaseguros.funciones.Funciones
import com.thona.thonaseguros.ui.pantallas.generales.Agente
import com.thona.thonaseguros.ui.plantillas.ProgressBarLoading
import com.thona.thonaseguros.ui.plantillas.menu.DatosPantalla

@Composable
fun LoginAgente(loadingProgressBar: Boolean, navController: NavController, funciones: Funciones, loginCorrecto: Boolean, respuestaLogin: Login, rolSel: String){

    Column(verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally){
        ProgressBarLoading(isLoading = loadingProgressBar)
    }
    BackHandler(
        enabled = !loadingProgressBar,
        onBack = { navController.navigate(route = DatosPantalla.Login.name){funciones.rolLogin.value = ""} }
    )
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Agente(
            login = funciones::conexion,
            click = funciones::selecRol,
            loadingProgressBar = loadingProgressBar,
            loginCorrecto = loginCorrecto,
            respuestaLogin = respuestaLogin,
            clickMensaje = funciones::cierraSesion,
            funciones = funciones,
            recupera = funciones::recuperaContrasenia
        )
        if(loginCorrecto){
            LaunchedEffect(key1 = Unit){
                navController.navigate(route = DatosPantalla.MenuAgente.name){
                }
            }
        }else if(rolSel.isNotEmpty()){
            LaunchedEffect(key1 = Unit){
                navController.navigate(route = rolSel){
                    funciones.reiniciar()
                }
            }
        }
    }
}

@Composable
fun MenuAgente (loadingProgressBar: Boolean, respuestaLogin: Login){
    Column(verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally){
        ProgressBarLoading(isLoading = loadingProgressBar)
    }
    BackHandler(
        enabled = !loadingProgressBar,
        onBack = {  }
    )
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        com.thona.thonaseguros.ui.pantallas.agente.MenuAgente(
            usuario = respuestaLogin
        )
    }
}