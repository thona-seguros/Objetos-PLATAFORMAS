package com.thona.thonaseguros

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.core.view.WindowCompat
import androidx.fragment.app.FragmentActivity
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.thona.thonaseguros.funciones.Funciones
import com.thona.thonaseguros.ui.navegacion.AppThona
import com.thona.thonaseguros.ui.theme.ThonaSegurosTheme

class MainActivity : FragmentActivity() {
    private val vista: Funciones by viewModels()
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    override fun onCreate(savedInstanceState: Bundle?) {
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent {
            ThonaSegurosTheme {
                AppThona(funciones = vista)

            }
        }
    }
}