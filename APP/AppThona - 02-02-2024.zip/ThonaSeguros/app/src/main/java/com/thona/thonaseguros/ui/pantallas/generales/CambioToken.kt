package com.thona.thonaseguros.ui.pantallas.generales

import android.annotation.SuppressLint
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.thona.thonaseguros.datos.modelos.Login
import com.thona.thonaseguros.ui.plantillas.AlertaPopUp
import com.thona.thonaseguros.ui.plantillas.CampoPassword
import com.thona.thonaseguros.ui.theme.Institucional1
import com.thona.thonaseguros.ui.theme.Institucional2
import com.thona.thonaseguros.ui.theme.Institucional3

@SuppressLint("UnrememberedMutableState")
@Composable
fun CambioToken(
    usuario: Login,
    cambiarToken: (usuario: String, rol: String, passAnterior: String, passNueva: String, idSession: Int) -> Unit,
    loadingProgressBar: Boolean,
    cambioCorrecto: Boolean,
    mensajeRespuesta: String,
    clicMensaje: (opcion: Int) -> Unit,
    recuperaToken: (usuario:String, rol: String) -> Unit,
    muestraMensajex: Boolean,
    cierraSesion: (Int) -> Unit
){
    var modifier = Modifier.alpha(alpha = 1F)
    if(loadingProgressBar){
        modifier = modifier.alpha(alpha = 0.8F)
    }
    var color1 = Institucional1
    when(usuario.items.rol){
        "CONTRATANTE" -> { color1 = Institucional1 }
        "ASEGURADO" -> { color1 = Institucional3 }
        "AGENTE" -> { color1 = Institucional2 }
    }
    var tokenAnterior by rememberSaveable { mutableStateOf(value = "") }
    var tokenNuevo by rememberSaveable { mutableStateOf(value = "") }
    var tokenConfirmacion by rememberSaveable { mutableStateOf(value = "") }
    var tokenVisible1 by rememberSaveable { mutableStateOf(false) }
    var tokenVisible2 by rememberSaveable { mutableStateOf(false) }
    var tokenVisible3 by rememberSaveable { mutableStateOf(false) }

    var esIgual by rememberSaveable { mutableStateOf(false) }

    val isValidate by derivedStateOf { tokenAnterior.isNotBlank() && tokenNuevo.isNotBlank() && tokenConfirmacion.isNotBlank() && esIgual}
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "Para realizar el cambio de token, ingresa tu token actual, tu nuevo token y confirma tu nuevo token.",
                modifier = modifier
                    .fillMaxWidth()
                    .padding(20.dp),
            )
        }
        Spacer(modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.Center){
            Text(text = "¿Has olvidado tu token?")
        }
        Row(horizontalArrangement = Arrangement.Center){
            Text(text = "Para reestablecerlo, da ")
            Text(
                modifier = modifier.clickable { recuperaToken(usuario.items.codUsuario, usuario.items.rol) },
                color = Institucional1,
                text = "click aqui"
            )
        }
        Spacer(modifier.height(20.dp))
        if(muestraMensajex){
            AlertaPopUp(
                titulo = "Recuperación de token",
                mensaje = "Se cerrara tu sesión, debes iniciar de nuevo con tus credenciales para asignar tu nuevo Token.",
                clicAceptar = { cierraSesion(1) },
                clicCancelar = {  },
                colorRol = color1,
                cantidadBotones = 1,
                texto1 = "Aceptar",
                texto2 = ""
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            CampoPassword(
                textValue = tokenAnterior,
                onValueChange = {
                    if( tokenAnterior.length <= 6 ){
                        tokenAnterior = it
                    }
                },
                onClickButton = { tokenVisible1 = !tokenVisible1 },
                texto = "Token actual",
                tipo = KeyboardType.Number,
                passwordVisible = tokenVisible1,
                accionGo = {  },
                isLoading = loadingProgressBar
            )
        }
        Spacer(modifier.height(5.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            CampoPassword(
                textValue = tokenNuevo,
                onValueChange = {
                    if( tokenNuevo.length<=6 ){
                        tokenNuevo = it
                    }
                    esIgual = igual(tokenNuevo,tokenConfirmacion)
                },
                onClickButton = { tokenVisible2 = !tokenVisible2 },
                texto = "Nuevo Token",
                tipo = KeyboardType.Number,
                passwordVisible = tokenVisible2,
                accionGo = {  },
                isLoading = loadingProgressBar
            )
        }
        Spacer(modifier.height(5.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            CampoPassword(
                textValue = tokenConfirmacion,
                onValueChange = {
                    if(tokenConfirmacion.length <= 6){
                        tokenConfirmacion = it
                    }
                    esIgual = igual(tokenNuevo,tokenConfirmacion)
                },
                onClickButton = { tokenVisible3 = !tokenVisible3 },
                texto = "Confirma tu nuevo token",
                tipo = KeyboardType.Number,
                passwordVisible = tokenVisible3,
                accionGo = {  },
                isLoading = loadingProgressBar
            )
        }
        Spacer(modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Button(
                onClick = {
                    usuario.items.codUsuario.let {
                        usuario.items.rol.let { it1 ->
                            cambiarToken(it, it1,tokenAnterior,tokenNuevo, usuario.session.idSession)
                        }
                    }
                },
                modifier = modifier
                    .fillMaxWidth()
                    .padding(
                        start = 20.dp,
                        end = 20.dp
                    ),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 5.dp),
                enabled = isValidate,
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(
                    color1
                )
            ) {
                Text(
                    text = "Aceptar",
                    fontSize = 20.sp,
                    color = Color.White
                )
            }
        }
        if(!esIgual && tokenConfirmacion.isNotBlank() && tokenNuevo.isNotBlank()){
            Text(
                modifier = modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                text = "El nuevo Token y la confirmación no coinciden.",
                fontSize = 10.sp,
                color = Color.Red
            )
        }
        if(!cambioCorrecto){
            Spacer(modifier.height(25.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = mensajeRespuesta,
                    fontSize = 15.sp,
                    color = Color.Red
                )
            }
        } else{
            AlertaPopUp(
                titulo = "Cambio de Token",
                mensaje = "El token ha sido actualizado con éxito",
                clicAceptar = {clicMensaje(1)},
                clicCancelar = {},
                colorRol = color1,
                cantidadBotones = 1,
                texto1 = "Aceptar",
                texto2 = ""
            )
        }
    }
}