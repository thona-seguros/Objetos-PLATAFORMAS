package com.thona.thonaseguros.ui.pantallas.generales

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Autorenew
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Alignment.Companion.CenterHorizontally
import androidx.compose.ui.Alignment.Companion.CenterVertically
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.thona.thonaseguros.datos.modelos.AltaRegistro
import com.thona.thonaseguros.datos.modelos.Control
import com.thona.thonaseguros.datos.modelos.ControlRegistro
import com.thona.thonaseguros.datos.modelos.ModeloVerificaDato
import com.thona.thonaseguros.datos.modelos.VerificaDatoItem
import com.thona.thonaseguros.datos.modelos.VerificaDatos
import com.thona.thonaseguros.funciones.Funciones
import com.thona.thonaseguros.ui.plantillas.AlertaPopUp
import com.thona.thonaseguros.ui.plantillas.CampoPassword
import com.thona.thonaseguros.ui.plantillas.CampoTexto
import com.thona.thonaseguros.ui.theme.Institucional1
import com.thona.thonaseguros.ui.theme.Institucional2
import com.thona.thonaseguros.ui.theme.Institucional3

@SuppressLint("UnrememberedMutableState", "SimpleDateFormat")
@Composable
fun Registro(
    loadingProgressBar: Boolean,
    funciones: Funciones
    ){
    var modifier = Modifier.alpha(alpha = 1F)
    if(loadingProgressBar){
        modifier = modifier.alpha(alpha = 0.8F)
    }
    Column(modifier = modifier) {
        var rol by remember { mutableStateOf(value = "") }
        var validoRFCClave by remember { mutableStateOf(value = false) }
        var validoCertificadoFecha by remember { mutableStateOf(value = false) }
        var validoCorreoTelefono by remember { mutableStateOf(value = false) }

        var datosValidos1 by remember { mutableStateOf(value = false) }
        var datosValidos2 by remember { mutableStateOf(value = false) }

        var color1 = Institucional1
        val color2 = Institucional2
        when (rol) {
            "Contratante" -> { color1 = Institucional1 }
            "Asegurado" -> { color1 = Institucional3 }
            "Agente" -> { color1 = Institucional2 }
        }

        var sRFC by remember { mutableStateOf(value = "") }
        var certificado by remember { mutableStateOf(value = "") }

        val nombre = funciones.datosVerificacion.value.verificaDatos.datos.nombre
        var telEnvio by remember { mutableStateOf( value = "") }
        var mailEnvio by remember { mutableStateOf(value = "") }
        var contra by remember { mutableStateOf(value = "") }

        if(!datosValidos1){
            Spacer(modifier = modifier.height(20.dp))
            Row(horizontalArrangement = Arrangement.Center, modifier = modifier.fillMaxWidth()){
                Column(horizontalAlignment = CenterHorizontally){
                    RadioButton(
                        selected = rol=="Asegurado",
                        onClick = { rol="Asegurado"; sRFC=""; certificado="" },
                        enabled = true,
                        colors = RadioButtonDefaults.colors(color1)
                    )
                    Text(
                        text = "Asegurado",
                        color = if(rol=="Asegurado")color1 else Color.Black
                    )
                }
                Spacer(modifier = modifier.width(10.dp))
                Column(horizontalAlignment = CenterHorizontally){
                    RadioButton(
                        selected = rol=="Contratante",
                        onClick = { rol="Contratante"; sRFC=""; certificado="" },
                        enabled = true,
                        colors = RadioButtonDefaults.colors(color1)
                    )
                    Text(
                        text = "Contratante",
                        color = if(rol=="Contratante")color1 else Color.Black
                    )
                }
                Spacer(modifier = modifier.width(10.dp))
                Column(horizontalAlignment = CenterHorizontally){
                    RadioButton(
                        selected = rol=="Agente",
                        onClick = { rol="Agente"; sRFC=""; certificado="" },
                        enabled = true,
                        colors = RadioButtonDefaults.colors(color1)
                    )
                    Text(
                        text = "Agente",
                        color = if(rol=="Agente")color1 else Color.Black
                    )
                }
            }
            Spacer(modifier = modifier.height(10.dp))
        }
        val scrollState = rememberScrollState()
        Column(modifier = Modifier
            .verticalScroll(scrollState)
            .fillMaxSize(),
            horizontalAlignment = CenterHorizontally) {
            if(rol.isNotEmpty()){
                var dato by remember { mutableStateOf(value = "") }
                when(rol){
                    "Asegurado" -> {
                        dato = "certificado"
                    }
                    "Contratante" -> {
                        dato = "póliza"
                    }
                    "Agente" -> {
                        dato = "clave de agente"
                    }
                }
                Spacer(modifier = modifier.height(10.dp))
                if(!datosValidos1){
                    Text( modifier = modifier
                        .fillMaxWidth()
                        .padding(start = 10.dp, end = 10.dp), text = "Para validar tus datos, a continuación ingresa tu RFC y tu $dato" )
                    Spacer(modifier = modifier.height(15.dp))
                    Text( text = "Ingresa tu RFC sin homoclave" )
                }
                CampoTexto(
                    textValue = sRFC,
                    onValueChange = { if(it.length <= 13)sRFC = it.uppercase() },
                    onClickButton = { sRFC = "" },
                    texto = "RFC*",
                    tipo = KeyboardType.Text,
                    isLoading = datosValidos1
                )

                if(!datosValidos1){
                    when(rol){
                        "Asegurado" -> {
                            Text(text = "Ingresa alguno de tus certificados")
                        }
                        "Contratante" -> {
                            Text(text = "Ingresa alguna de tus polizas")
                        }
                        "Agente" -> {
                            Text(text = "Ingresa tu clave de agente")
                        }
                    }
                }
                CampoTexto(
                    textValue = certificado,
                    onValueChange = { certificado = it },
                    onClickButton = { certificado = "" },
                    texto = if(rol=="Asegurado") "No. certificado*" else if(rol=="Contratante") "No. póliza*" else if(rol == "Agente") "Clave de agente*" else "",
                    tipo = if(rol == "Agente") KeyboardType.Number else KeyboardType.Text,
                    isLoading = datosValidos1
                )
                Spacer(modifier = modifier.height(10.dp))
                validoRFCClave = sRFC.length == 12 || sRFC.length == 13 && certificado.isNotEmpty()

                if(validoRFCClave){
                    Row{
                        Button(
                            onClick = { funciones.verificaDatos(sRFC,certificado,rol) },
                            enabled = if(datosValidos1)false else validoRFCClave,
                            colors = ButtonDefaults.buttonColors(containerColor = color1)
                        ) {
                            when(sRFC.length){
                                12 -> {
                                    Text(text = "Validar Persona Moral")
                                }
                                13 -> {
                                    Text(text = "Validar Persona Física")
                                }
                            }
                        }
                        if(datosValidos1){
                            Spacer(modifier = modifier.width(5.dp))
                            IconButton(onClick = {
                                datosValidos1=false
                                datosValidos2 = false
                                validoRFCClave=false
                                validoCertificadoFecha=false
                                validoCorreoTelefono=false
                                funciones.datosVerificacion.value = ModeloVerificaDato(VerificaDatos(
                                    VerificaDatoItem("","","","",""), Control("","")
                                    ))
                                }
                            ) {
                                Icon(imageVector = Icons.Default.Autorenew, contentDescription = "", tint = color1)
                            }
                        }
                    }
                    if(loadingProgressBar){
                        Spacer(modifier = modifier.height(10.dp))
                    }
                    datosValidos1 = funciones.datosVerificacion.value.verificaDatos.control.numeroRespuesta == "1"
                }
                if(funciones.datosVerificacion.value.verificaDatos.control.numeroRespuesta== "0" ){
                    Spacer(modifier = modifier.height(10.dp))
                    Text(
                        modifier = modifier.align(CenterHorizontally),
                        text = funciones.datosVerificacion.value.verificaDatos.control.textoRespuesta,
                        color = Institucional2,
                        fontSize = 8.sp
                    )
                }

                Spacer(modifier = modifier.height(10.dp))
                if(datosValidos1){
                    var datoTelCorrecto by remember { mutableStateOf(value = false) }
                    if(!datosValidos2){
                        Text(text = "Nombre")
                    }
                    OutlinedTextField(modifier = modifier
                        .fillMaxWidth()
                        .padding(start = 20.dp, end = 20.dp), value = nombre, onValueChange = {  }, readOnly = true, shape = CircleShape)
                    Spacer(modifier = modifier.height(10.dp))
                    var tel by remember { mutableStateOf(value = funciones.datosVerificacion.value.verificaDatos.datos.telefono) }
                    var mail by remember { mutableStateOf(value = funciones.datosVerificacion.value.verificaDatos.datos.email) }
                    if(!datosValidos2){
                        Text(text = "Teléfono")
                    }
                    OutlinedTextField(
                        modifier = modifier
                            .fillMaxWidth()
                            .padding(start = 20.dp, end = 20.dp),
                        value = tel,
                        onValueChange = {
                            if(tel.length<10){
                                tel = it
                            }
                            datoTelCorrecto = validaTelefono(tel)
                        },
                        label = { Text(text = "Teléfono*") },
                        placeholder = { Text(text = "Teléfono*") },
                        leadingIcon = {
                                      Icon(
                                          imageVector = Icons.Filled.PhoneAndroid,
                                          contentDescription = "Teléfono")
                        },
                        trailingIcon = {
                            IconButton(
                                onClick = { tel = ""; datoTelCorrecto = validaTelefono(tel) },
                                enabled = !datosValidos2
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Clear,
                                    contentDescription = "Borrar"
                                )
                            }
                        },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Phone,
                            imeAction = ImeAction.Next
                        ),
                        isError = !datoTelCorrecto,
                        shape = CircleShape
                    )
                    Box(modifier = modifier.fillMaxWidth()){
                        Row (modifier.align(Alignment.CenterEnd)){
                            Text(
                                text = "${tel.length}/10",
                                color = if(validaTelefono(tel)) Color.LightGray else Color.Red,
                                fontSize = 11.sp,
                                modifier = modifier.padding(end = 25.dp)
                            )
                        }
                    }

                    var datoMailCorrecto by remember { mutableStateOf(value = true) }
                    if(!datosValidos2){
                        Text(text = "Ingresa tu mail")
                    }
                    CampoTexto(
                        textValue = mail,
                        onValueChange = { mail = it; datoMailCorrecto = validaMail(mail) },
                        onClickButton = { mail = ""; datoMailCorrecto = validaMail(mail) },
                        texto = "Correo*",
                        tipo = KeyboardType.Email,
                        isLoading = datosValidos2,
                        isError = !datoMailCorrecto
                    )
                    if(!datoMailCorrecto){
                        Text(text = "Dato de correo incorrecto", color = color2, modifier = modifier
                            .fillMaxWidth()
                            .align(Alignment.Start)
                            .padding(start = 30.dp), fontSize = 8.sp)
                    }
                    Spacer(modifier = modifier.height(10.dp))

                    var datoContraseniaCorrecto by remember { mutableStateOf(value = false) }
                    if(!datosValidos2){
                        Text(text = "Ingresa tu contraseña")
                    }
                    var passwordVisible by remember { mutableStateOf(value = false) }
                    CampoPassword(
                        textValue = contra,
                        onValueChange = { contra = it; datoContraseniaCorrecto = validaContrasenia(contra) },
                        onClickButton = { passwordVisible = !passwordVisible },
                        texto = "Contraseña*",
                        tipo = KeyboardType.Password,
                        passwordVisible = passwordVisible,
                        accionGo = {  },
                        isLoading = datosValidos2,
                        isError = !datoContraseniaCorrecto
                    )
                    if(!datoContraseniaCorrecto){
                        Text(text = "Dato contraseña incorrecto", color = color2, modifier = modifier
                            .fillMaxWidth()
                            .align(Alignment.Start)
                            .padding(start = 30.dp), fontSize = 8.sp)
                    }
                    Spacer(modifier = modifier.height(10.dp))
                    var validaContra by remember { mutableStateOf(value = "") }
                    var validacionConfirmacionCOntra by remember { mutableStateOf(value = false) }
                    if(!datosValidos2){
                        Text(text = "Confirma tu contraseña")
                    }
                    var passwordVisible2 by remember { mutableStateOf(value = false) }
                    CampoPassword(
                        textValue = validaContra,
                        onValueChange = { validaContra = it; validacionConfirmacionCOntra = validaContra==contra },
                        onClickButton = { passwordVisible2 = !passwordVisible2 },
                        texto = "Confirmación de contraseña*",
                        tipo = KeyboardType.Password,
                        passwordVisible = passwordVisible2,
                        accionGo = {  },
                        isLoading = datosValidos2,
                        isError = !validacionConfirmacionCOntra
                    )
                    if(!validacionConfirmacionCOntra){
                        Text(text = "Las contraseñas no coinciden", color = color2, modifier = modifier
                            .fillMaxWidth()
                            .align(Alignment.Start)
                            .padding(start = 30.dp), fontSize = 8.sp)
                    }
                    validoCorreoTelefono = datoTelCorrecto && datoMailCorrecto && datoContraseniaCorrecto && validacionConfirmacionCOntra
                    Spacer(modifier = modifier.height(20.dp))
                    Button(
                        modifier = modifier
                            .fillMaxWidth()
                            .padding(start = 10.dp, end = 10.dp),
                        onClick = { telEnvio=tel; mailEnvio=mail; datosValidos2=validoCorreoTelefono },
                        enabled = validoCorreoTelefono,
                        colors = ButtonDefaults.buttonColors(containerColor = color1)
                    ) {
                        Text(
                            text = "Registrar"
                        )
                    }
                    Spacer(modifier = modifier.height(20.dp))
                }
            }
        }
        if(datosValidos2){
            val openDialog = remember { mutableStateOf(false)  }
            var check1 by remember { mutableStateOf(false)  }
            var check2 by remember { mutableStateOf(false)  }
            var check3 by remember { mutableStateOf(false)  }
            openDialog.value = true
            AlertDialog(
                onDismissRequest = {
                    openDialog.value = false
                },
                title = {
                    Text(text = "Aceptación terminos")
                },
                text = {
                    Column {
                        Row(verticalAlignment = CenterVertically) {
                            Checkbox(colors = myCheckBoxColors(color1, Color.Gray), checked = check1, onCheckedChange = {check1 = !check1})
                            Text(text = "Terminos y condiciones")
                        }
                        Row(verticalAlignment = CenterVertically) {
                            Checkbox(colors = myCheckBoxColors(color1, Color.Gray), checked = check2, onCheckedChange = {check2 = !check2})
                            Text(text = "Aviso de privacidad")
                        }
                        Row(verticalAlignment = CenterVertically) {
                            Checkbox(colors = myCheckBoxColors(color1, Color.Gray), checked = check3, onCheckedChange = {check3 = !check3})
                            Text(text = "Actualización de información")
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            funciones.enviaRegistro(sRFC,rol, mailEnvio, telEnvio, contra, funciones.datosVerificacion.value.verificaDatos.datos.codigoUnico.toInt())
                        },
                        colors = ButtonDefaults.buttonColors(color1),
                        enabled = (check1 && check2 && check3)
                    ) {
                        Text(text = "Aceptar")
                    }
                },
                dismissButton = {
                    Button(
                        onClick = {
                            openDialog.value=false; datosValidos2 = false
                        },
                        colors = ButtonDefaults.buttonColors(color1)
                    ) {
                        Text(text = "Cancelar")
                    }
                }
            )
        }
        if(datosValidos2 && ( funciones.registroConcluido.value.control.numeroRespuesta!="" && funciones.registroConcluido.value.control.numeroRespuesta!="1")){
            AlertaPopUp(
                titulo = "Error de registro",
                mensaje = funciones.registroConcluido.value.control.textoRespuesta,
                clicAceptar = { funciones.registroConcluido.value = AltaRegistro(ControlRegistro("","","","")); datosValidos2 = false },
                clicCancelar = {  },
                colorRol = color1,
                cantidadBotones = 1,
                texto1 = "Aceptar",
                texto2 = ""
            )
        }
        if(datosValidos2 && funciones.registroConcluido.value.control.numeroRespuesta=="1"){
            AlertaPopUp(
                titulo = "Registro exitoso",
                mensaje = funciones.registroConcluido.value.control.textoRespuesta,
                clicAceptar = { funciones.registroConcluido.value = AltaRegistro(ControlRegistro("","","","")); datosValidos2 = false; funciones.opcionMensaje.intValue = 88; funciones.reiniciar() },
                clicCancelar = {  },
                colorRol = color1,
                cantidadBotones = 1,
                texto1 = "Aceptar",
                texto2 = ""
            )
        }
    }
}