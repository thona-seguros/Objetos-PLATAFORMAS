package com.thona.thonaseguros.ui.pantallas.generales

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.thona.thonaseguros.R
import com.thona.thonaseguros.ui.theme.Institucional1
import com.thona.thonaseguros.ui.theme.Institucional2
import com.thona.thonaseguros.ui.theme.Institucional3

@Composable
fun SeleccionRol(
    click: (pant: String) -> Unit,
    loadingProgressBar: Boolean
){
    var modifier = Modifier.alpha(alpha = 1F)
    if(loadingProgressBar){
        modifier = modifier.alpha(alpha = 0.8F)
    }

    Spacer(modifier = modifier.height(50.dp))
    Row{
        Image(
            painter = painterResource(id = R.drawable.estrella_r),
            contentDescription = "Thona Seguros",
            modifier = modifier.size(150.dp)
        )
    }
    Spacer(modifier = modifier.height(20.dp))
    Row(verticalAlignment = Alignment.CenterVertically){
        Text(
            text = "Selecciona una opción",
            fontSize = 18.sp
        )
    }
    Spacer(modifier = modifier.height(50.dp))
    Row{
        Button(
            onClick = { click("Contratante") },
            modifier = modifier
                .fillMaxWidth()
                .padding(
                    start = 80.dp,
                    end = 80.dp
                ),
            elevation = ButtonDefaults.buttonElevation(defaultElevation = 5.dp),
            enabled = true,
            shape = CircleShape,
            colors = ButtonDefaults.buttonColors(
                Institucional1
            )
        ) {
            Text(
                text = "Soy Contratante",
                fontSize = 20.sp,
                color = Color.White
            )
        }
    }
    Spacer(modifier = modifier.height(20.dp))
    Row{
        Button(
            onClick = { click("Asegurado") },
            modifier = modifier
                .fillMaxWidth()
                .padding(
                    start = 80.dp,
                    end = 80.dp
                ),
            elevation = ButtonDefaults.buttonElevation(defaultElevation = 5.dp),
            enabled = true,
            shape = CircleShape,
            colors = ButtonDefaults.buttonColors(
                Institucional3
            )
        ) {
            Text(
                text = "Soy Asegurado",
                fontSize = 20.sp,
                color = Color.White
            )
        }
    }
    Spacer(modifier = modifier.height(20.dp))
    Row{
        Button(
            onClick = { click("Agente") },
            modifier = modifier
                .fillMaxWidth()
                .padding(
                    start = 80.dp,
                    end = 80.dp
                ),
            elevation = ButtonDefaults.buttonElevation(defaultElevation = 5.dp),
            enabled = true,
            shape = CircleShape,
            colors = ButtonDefaults.buttonColors(
                Institucional2
            )
        ) {
            Text(
                text = "Soy Agente",
                fontSize = 20.sp,
                color = Color.White
            )
        }
    }
    Spacer(modifier = modifier.height(20.dp))
    Row{
        TextButton(
            onClick = { click("Registro") }
        ) {
            Text(
                text = "¿No tienes una cuenta? Registrar"
            )
        }
    }
}