package com.thona.thonaseguros.ui.pantallas.asegurado

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountBox
import androidx.compose.material.icons.outlined.AdminPanelSettings
import androidx.compose.material.icons.outlined.AttachMoney
import androidx.compose.material.icons.outlined.Bedtime
import androidx.compose.material.icons.outlined.MonetizationOn
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.thona.thonaseguros.datos.modelos.Login
import com.thona.thonaseguros.datos.modelos.MyProducto
import com.thona.thonaseguros.ui.theme.Institucional3

@Composable
fun AseguradoTramites(
    usuario: Login,
    productos: MyProducto,
    tramite: (opTramite: Int) -> Unit,
    loadingProgressBar: Boolean
){
    var modifier = Modifier.alpha(alpha = 1F)
    if(loadingProgressBar){
        modifier = modifier.alpha(alpha = 0.8F)
    }
    val mContext = LocalContext.current
    Box(
        modifier
            .fillMaxWidth()
            .background(color = Institucional3)
    ) {
        Row(
            modifier = modifier
                .padding(horizontal = 8.dp)
                .align(Alignment.CenterStart),
            horizontalArrangement = Arrangement.Center
        ) {
            Text(
                text = usuario.items.nomUsuario,
                color = Color.White,
                fontSize = 11.sp
            )
        }
        Row(
            modifier = modifier
                .padding(horizontal = 8.dp)
                .align(Alignment.CenterEnd),
            horizontalArrangement = Arrangement.Center
        ) {
            Text(
                text = "No. Asegurado:${productos.idAsegurado.codAsegurado}",
                color = Color.White,
                fontSize = 11.sp
            )
        }
    }
    Spacer(modifier = modifier.height(15.dp))
    Column (horizontalAlignment = Alignment.CenterHorizontally){
        Row {
            Column{
                OutlinedButton(
                    onClick = {
                        Toast.makeText(
                            mContext,
                            "Listado promociones",
                            Toast.LENGTH_SHORT
                        ).show(); tramite(1)
                    },
                    modifier= modifier.size(60.dp),
                    shape = CircleShape,
                    border= BorderStroke(width = 5.dp, color = Institucional3),
                    contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor =  Institucional3)
                ) {
                    Icon(imageVector = Icons.Outlined.MonetizationOn ,contentDescription = "", tint= Institucional3)
                }
                Spacer(modifier = modifier.height(5.dp))
                Text(
                    text = "Promociones",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = modifier.width(30.dp))
            Column {
                OutlinedButton(
                    onClick = {
                        Toast.makeText(
                            mContext,
                            "Acción del tramite 2",
                            Toast.LENGTH_SHORT
                        ).show()
                    },
                    modifier= modifier.size(60.dp),
                    shape = CircleShape,
                    border= BorderStroke(width = 5.dp, color = Institucional3),
                    contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor =  Institucional3)
                ) {
                    Icon(imageVector = Icons.Outlined.AccountBox ,contentDescription = "", tint= Institucional3)
                }
                Spacer(modifier = modifier.height(5.dp))
                Text(
                    text = "Tramite 2",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = modifier.width(30.dp))
            Column {
                OutlinedButton(
                    onClick = {
                        Toast.makeText(
                            mContext,
                            "Acción del tramite 3",
                            Toast.LENGTH_SHORT
                        ).show()
                    },
                    modifier= modifier.size(60.dp),
                    shape = CircleShape,
                    border= BorderStroke(width = 5.dp, color = Institucional3),
                    contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor =  Institucional3)
                ) {
                    Icon(imageVector = Icons.Outlined.AdminPanelSettings ,contentDescription = "", tint= Institucional3)
                }
                Spacer(modifier = modifier.height(5.dp))
                Text(
                    text = "Tramite 3",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = modifier.width(30.dp))
            Column {
                OutlinedButton(
                    onClick = {
                        Toast.makeText(
                            mContext,
                            "Acción del tramite 4",
                            Toast.LENGTH_SHORT
                        ).show()
                    },
                    modifier= modifier.size(60.dp),
                    shape = CircleShape,
                    border= BorderStroke(width = 5.dp, color = Institucional3),
                    contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor =  Institucional3)
                ) {
                    Icon(imageVector = Icons.Outlined.AdminPanelSettings ,contentDescription = "", tint= Institucional3)
                }
                Spacer(modifier = modifier.height(5.dp))
                Text(
                    text = "Tramite 4",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
        Spacer(modifier = modifier.height(150.dp))
        Row {
            Column {
                OutlinedButton(
                    onClick = {
                        Toast.makeText(
                            mContext,
                            "Acción tramite 5",
                            Toast.LENGTH_SHORT
                        ).show()
                    },
                    modifier= modifier.size(60.dp),
                    shape = CircleShape,
                    border= BorderStroke(width = 5.dp, color = Institucional3),
                    contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor =  Institucional3)
                ) {
                    Icon(imageVector = Icons.Outlined.AttachMoney ,contentDescription = "", tint= Institucional3)
                }
                Spacer(modifier = modifier.height(5.dp))
                Text(
                    text = "Tramite 5",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = modifier.width(30.dp))
            Column {
                OutlinedButton(
                    onClick = {
                        Toast.makeText(
                            mContext,
                            "Acción del tramite 6",
                            Toast.LENGTH_SHORT
                        ).show()
                    },
                    modifier= modifier.size(60.dp),
                    shape = CircleShape,
                    border= BorderStroke(width = 5.dp, color = Institucional3),
                    contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor =  Institucional3)
                ) {
                    Icon(imageVector = Icons.Outlined.Bedtime ,contentDescription = "", tint= Institucional3)
                }
                Spacer(modifier = modifier.height(5.dp))
                Text(
                    text = "Tramite 6",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = modifier.width(30.dp))
            Column {
                OutlinedButton(
                    onClick = {
                        Toast.makeText(
                            mContext,
                            "Acción tramite 7",
                            Toast.LENGTH_SHORT
                        ).show()
                    },
                    modifier= modifier.size(60.dp),
                    shape = CircleShape,
                    border= BorderStroke(width = 5.dp, color = Institucional3),
                    contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor =  Institucional3)
                ) {
                    Icon(imageVector = Icons.Outlined.AttachMoney ,contentDescription = "", tint= Institucional3)
                }
                Spacer(modifier = modifier.height(5.dp))
                Text(
                    text = "Tramite 7",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = modifier.width(30.dp))
            Column {
                OutlinedButton(
                    onClick = {
                        Toast.makeText(
                            mContext,
                            "Acción del tramite 8",
                            Toast.LENGTH_SHORT
                        ).show()
                    },
                    modifier= modifier.size(60.dp),
                    shape = CircleShape,
                    border= BorderStroke(width = 5.dp, color = Institucional3),
                    contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor =  Institucional3)
                ) {
                    Icon(imageVector = Icons.Outlined.Bedtime ,contentDescription = "", tint= Institucional3)
                }
                Spacer(modifier = modifier.height(5.dp))
                Text(
                    text = "Tramite 8",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}