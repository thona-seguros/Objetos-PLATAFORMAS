package com.thona.thonaseguros.ui.pantallas.generales

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.thona.thonaseguros.datos.modelos.Login
import com.thona.thonaseguros.ui.plantillas.AlertaPopUp
import com.thona.thonaseguros.ui.plantillas.CampoPassword
import com.thona.thonaseguros.ui.theme.Institucional1
import com.thona.thonaseguros.ui.theme.Institucional2
import com.thona.thonaseguros.ui.theme.Institucional3

@SuppressLint("UnrememberedMutableState")
@Composable
fun CambioPassword(
    usuario: Login,
    cambiarContrasena: (usuario: String, rol: String, passAnterior: String, passNueva: String, idSession: Int) -> Unit,
    loadingProgressBar: Boolean,
    cambioCorrecto: Boolean,
    mensajeRespuesta: String,
    clicMensaje: (opcion: Int) -> Unit
){
    var modifier = Modifier.alpha(alpha = 1F)
    if(loadingProgressBar){
        modifier = modifier.alpha(alpha = 0.8F)
    }
    var color1 = Institucional1
    when(usuario.items.rol){
        "CONTRATANTE" -> { color1 = Institucional1 }
        "ASEGURADO" -> { color1 = Institucional3 }
        "AGENTE" -> { color1 = Institucional2 }
    }
    var passwordAnterior by rememberSaveable { mutableStateOf(value = "") }
    var passwordNuevo by rememberSaveable { mutableStateOf(value = "") }
    var passwordConfirmacion by rememberSaveable { mutableStateOf(value = "") }
    var passwordVisible1 by rememberSaveable { mutableStateOf(false) }
    var passwordVisible2 by rememberSaveable { mutableStateOf(false) }
    var passwordVisible3 by rememberSaveable { mutableStateOf(false) }

    var esIgual by rememberSaveable { mutableStateOf(false) }

    val isValidate by derivedStateOf { passwordAnterior.isNotBlank() && passwordNuevo.isNotBlank() && passwordConfirmacion.isNotBlank() && esIgual}
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "Para realizar el cambio de contraseña, ingresa tu contraseña actual, tu nueva contraseña y confirma tu nueva contraseña.",
                modifier = modifier
                    .fillMaxWidth()
                    .padding(20.dp),
            )
        }
        Spacer(modifier.height(15.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            CampoPassword(
                textValue = passwordAnterior,
                onValueChange = {passwordAnterior = it},
                onClickButton = { passwordVisible1 = !passwordVisible1 },
                texto = "Contraseña actual",
                tipo = KeyboardType.Password,
                passwordVisible = passwordVisible1,
                accionGo = {  },
                isLoading = loadingProgressBar
            )
        }
        Spacer(modifier.height(5.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            CampoPassword(
                textValue = passwordNuevo,
                onValueChange = {passwordNuevo = it; esIgual = igual(passwordNuevo,passwordConfirmacion) },
                onClickButton = { passwordVisible2 = !passwordVisible2 },
                texto = "Nueva contraseña",
                tipo = KeyboardType.Password,
                passwordVisible = passwordVisible2,
                accionGo = {  },
                isLoading = loadingProgressBar
            )
        }
        Spacer(modifier.height(5.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            CampoPassword(
                textValue = passwordConfirmacion,
                onValueChange = {passwordConfirmacion = it; esIgual = igual(passwordNuevo,passwordConfirmacion)},
                onClickButton = { passwordVisible3 = !passwordVisible3 },
                texto = "Confirma tu nueva contraseña",
                tipo = KeyboardType.Password,
                passwordVisible = passwordVisible3,
                accionGo = {  },
                isLoading = loadingProgressBar
            )
        }
        Spacer(modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Button(
                onClick = {
                    usuario.items.codUsuario.let {
                        usuario.items.rol.let { it1 ->
                            cambiarContrasena(it, it1,passwordAnterior,passwordNuevo, usuario.session.idSession)
                        }
                    }
                },
                modifier = modifier
                    .fillMaxWidth()
                    .padding(
                        start = 20.dp,
                        end = 20.dp
                    ),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 5.dp),
                enabled = isValidate,
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(
                    color1
                )
            ) {
                Text(
                    text = "Aceptar",
                    fontSize = 20.sp,
                    color = Color.White
                )
            }
        }
        if(!esIgual && passwordConfirmacion.isNotBlank() && passwordNuevo.isNotBlank()){
            Text(
                modifier = modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                text = "La nueva contraseña y la confirmación no coinciden.",
                fontSize = 10.sp,
                color = Color.Red
            )
        }
        if(!cambioCorrecto){
            Spacer(modifier.height(25.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = mensajeRespuesta,
                    fontSize = 15.sp,
                    color = Color.Red
                )
            }
        } else{
            AlertaPopUp(
                titulo = "Cambio de contraseña",
                mensaje = "La contraseña ha sido actualizada con éxito",
                clicAceptar = {clicMensaje(1)},
                clicCancelar = {},
                colorRol = color1,
                cantidadBotones = 1,
                texto1 = "Aceptar",
                texto2 = ""
            )
        }
    }
}

fun igual(texto1: String, texto2: String): Boolean{
    return texto1 == texto2
}