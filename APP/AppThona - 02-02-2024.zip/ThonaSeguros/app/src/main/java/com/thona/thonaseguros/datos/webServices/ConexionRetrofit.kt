package com.thona.thonaseguros.datos.webServices

import android.annotation.SuppressLint
import com.google.gson.GsonBuilder
import com.jakewharton.retrofit2.adapter.kotlin.coroutines.CoroutineCallAdapterFactory
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocketFactory
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

fun getUnsafeOkHttpClient(): OkHttpClient.Builder? {
    return try {
        val trustAllCerts = arrayOf<TrustManager>(
            @SuppressLint("CustomX509TrustManager")
            object : X509TrustManager {
                @SuppressLint("TrustAllX509TrustManager")
                override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {
                }
                @SuppressLint("TrustAllX509TrustManager")
                override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {
                }
                override fun getAcceptedIssuers(): Array<X509Certificate> {
                    return arrayOf()
                }
            }
        )
        val sslContext = SSLContext.getInstance("SSL")
        sslContext.init(null, trustAllCerts, SecureRandom())
        val sslSocketFactory: SSLSocketFactory = sslContext.socketFactory
        val builder = OkHttpClient.Builder()
        builder.sslSocketFactory(sslSocketFactory, trustAllCerts[0] as X509TrustManager)
            .hostnameVerifier { _, _ -> true }
        builder
    } catch (e: Exception) {
        throw RuntimeException(e)
    }
}

object ConexionRetrofit {
    /*
    //CONEXIÓN DRP
    private val retrofit: Retrofit
    var url = "http://192.168.0.223:8081/ords/sicas/appthona/"
    init {
        val gson = GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss").create()

        val builder = Retrofit.Builder()
            //.baseUrl("https://sicas.thonaseguros.mx:8443/ords/sicas/appthona/")
            .baseUrl(url)
            //.baseUrl("http://sicas-alt:8443/ords/sicas/appthona/")
            .addConverterFactory(GsonConverterFactory.create(gson))
            .addCallAdapterFactory(CoroutineCallAdapterFactory())

        val loggingInterceptor = HttpLoggingInterceptor()
        loggingInterceptor.level = HttpLoggingInterceptor.Level.BODY

        val okHttpClient = OkHttpClient.Builder()
            .addInterceptor(loggingInterceptor)
            //.writeTimeout(0, TimeUnit.MILLISECONDS)
            .writeTimeout(2, TimeUnit.MINUTES)
            .readTimeout(2, TimeUnit.MINUTES)
            .callTimeout(2, TimeUnit.MINUTES)
            .connectTimeout(2, TimeUnit.MINUTES)
            .connectTimeout(2, TimeUnit.MINUTES).build()
        retrofit = builder.client(okHttpClient).build()
    }
    fun getAuthService(): Metodos {
        return retrofit.create(Metodos::class.java)
    }
    */

    var url = "https://sicas-alt:8443/ords/sicas/appthona/"
    //var url = "https://32.202.90.230:8443/ords/sicas/appthona/"

    //CONEXIÓN UAT
    //TODO COLOCAR android:networkSecurityConfig="@xml/network_security_config" EN ANDROID MANIFEST
    private val retrofit: Retrofit
    init {
        val gson = GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss").create()
        val builder = Retrofit.Builder()
            .baseUrl(url)
            .addConverterFactory(GsonConverterFactory.create(gson))
            .addCallAdapterFactory(CoroutineCallAdapterFactory())
        val loggingInterceptor = HttpLoggingInterceptor()
        loggingInterceptor.level = HttpLoggingInterceptor.Level.BODY
        val okHttpClient = OkHttpClient.Builder()
            .addInterceptor(loggingInterceptor)
            .writeTimeout(2, TimeUnit.MINUTES)
            .readTimeout(2, TimeUnit.MINUTES)
            .callTimeout(2, TimeUnit.MINUTES)
            .connectTimeout(2, TimeUnit.MINUTES)
            .connectTimeout(2, TimeUnit.MINUTES)
            .hostnameVerifier { _, _ -> true }
            .build()
        retrofit = builder.client(getUnsafeOkHttpClient()?.build() ?: okHttpClient)
            .build()
    }
    fun getAuthService(): Metodos {
        return retrofit.create(Metodos::class.java)
    }

    /*
    //CONEXIÓN CON PRODUCCIÓN
    //TODO COLOCAR android:networkSecurityConfig="@xml/network_security_config" EN ANDROID MANIFEST
    private val retrofit: Retrofit
    init {
        val gson = GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss").create()

        val trustAllCerts = arrayOf<TrustManager>(
            object : X509TrustManager {
                @SuppressLint("TrustAllX509TrustManager")
                override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {
                }

                @SuppressLint("TrustAllX509TrustManager")
                override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {
                }

                override fun getAcceptedIssuers(): Array<X509Certificate> {
                    return arrayOf()
                }
            }
        )

        val builder = Retrofit.Builder()
            .baseUrl("https://sicas.thonaseguros.mx:8443/ords/sicas/appthona/")
            //.baseUrl("http://192.168.0.223:8081/ords/sicas/appthona/")
            //.baseUrl("https://sicas-alt:8443/ords/sicas/appthona/")
            .addConverterFactory(GsonConverterFactory.create(gson))
            .addCallAdapterFactory(CoroutineCallAdapterFactory())

        val sslContext = SSLContext.getInstance("SSL")
        sslContext.init(null, trustAllCerts, SecureRandom())

        val loggingInterceptor = HttpLoggingInterceptor()
        loggingInterceptor.level = HttpLoggingInterceptor.Level.BODY

        val okHttpClient = OkHttpClient.Builder()
            .addInterceptor(loggingInterceptor)
            .sslSocketFactory(sslContext.socketFactory, trustAllCerts[0] as X509TrustManager)
            //.writeTimeout(0, TimeUnit.MILLISECONDS)
            /*.writeTimeout(1, TimeUnit.MINUTES)
            .readTimeout(1, TimeUnit.MINUTES)
            .callTimeout(1, TimeUnit.MINUTES)
            .connectTimeout(1, TimeUnit.MINUTES)
            .connectTimeout(1, TimeUnit.MINUTES)*/
            //.retryOnConnectionFailure(true)
            .build()
        retrofit = builder.client(okHttpClient).build()
        //retrofit = builder.client(getUnsafeOkHttpClient()?.build() ?: okHttpClient).build()
    }

    fun getAuthService(): Metodos {
        return retrofit.create(Metodos::class.java)
    }
     */
}

/*CONEXIÓN CON EL SERVICIO DE OBTENER LA IP*/
object ConexionIP {
    private val retrofit: Retrofit
    init {
        val gson = GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss").create()
        val builder = Retrofit.Builder()
            .baseUrl("https://api.ipify.org")
            .addConverterFactory(GsonConverterFactory.create(gson))
            .addCallAdapterFactory(CoroutineCallAdapterFactory())
        val loggingInterceptor = HttpLoggingInterceptor()
        loggingInterceptor.level = HttpLoggingInterceptor.Level.BODY
        val okHttpClient = OkHttpClient.Builder()
            .addInterceptor(loggingInterceptor)
            .writeTimeout(1, TimeUnit.MINUTES)
            .readTimeout(1, TimeUnit.MINUTES)
            .callTimeout(1, TimeUnit.MINUTES)
            .connectTimeout(1, TimeUnit.MINUTES)
            .connectTimeout(1, TimeUnit.MINUTES).build()
        retrofit = builder.client(okHttpClient).build()
    }
    fun getAuthService(): Metodos {
        return retrofit.create(Metodos::class.java)
    }
}

/*CONEXIÓN CON EL API DE UAT*/
object ConexionAPILocal {
    private val retrofit: Retrofit
    init {
        val gson = GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss").create()

        val builder = Retrofit.Builder()
            //UAT
            //.baseUrl("https://thona01.azurewebsites.net/api/")
            //DESARROLLO
            .baseUrl("https://thona-api-desarrollo.azurewebsites.net/api/")
            //.addConverterFactory(SimpleXmlConverterFactory.create())
            .addConverterFactory(GsonConverterFactory.create(gson))
            .addCallAdapterFactory(CoroutineCallAdapterFactory())
        val loggingInterceptor = HttpLoggingInterceptor()
        loggingInterceptor.level = HttpLoggingInterceptor.Level.BODY
        val okHttpClient = OkHttpClient.Builder()
            .addInterceptor(loggingInterceptor)
            .writeTimeout(2, TimeUnit.MINUTES)
            .readTimeout(2, TimeUnit.MINUTES)
            .callTimeout(2, TimeUnit.MINUTES)
            .connectTimeout(2, TimeUnit.MINUTES)
            .connectTimeout(2, TimeUnit.MINUTES).build()
        retrofit = builder.client(okHttpClient).build()
    }
    fun getAuthService(): Metodos {
        return retrofit.create(Metodos::class.java)
    }
}