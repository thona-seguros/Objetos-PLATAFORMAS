package com.thona.thonaseguros.datos.modelos

import com.google.gson.annotations.SerializedName

/* Coneido de la respuesta Aplica Cobranza */
data class ModeloAplicaCobranza(
    @SerializedName("DATA") val aplicaCobranza: AplicaCobranza
)

/* Contenido de la respuesta Alta registro */
data class ModeloVerificaDato(
    @SerializedName("items") val verificaDatos: VerificaDatos
)

/* Contenido de la respuesta Envia Registro */
data class ModeloEnviaRegistro(
    @SerializedName("items") val altaRegistro: AltaRegistro
)

/* Contenido de la respuesta de login */
data class ModeloLogin(
    @SerializedName("items") val login: Login
)

/* Contenido de la respuesta al cambio de password */
data class ModeloCambioPassword(
    @SerializedName("items") val cambioPassword: CambioPassword
)

/* Contenido de la respuesta al cambio de token */
data class ModeloCambioToken(
    @SerializedName("items") val cambioToken: CambioToken
)

/* Contenido de la respuesta al confirmación de token */
data class ModeloConfirmaToken(
    @SerializedName("items") val confirmaToken: ConfirmaToken
)

/* Contenido de la respuesta al recuperar token */
data class ModeloRecuperaToken(
    @SerializedName("items") val recuperaToken: RecuperaToken
)

/* Contenido de la respuesta al recuperar token */
data class ModeloRecuperaPassword(
    @SerializedName("items") val recuperaPassword: RecuperaPassword
)

/* Contenido de la respuesta cierre de sesión */
data class ModeloCierreSesion(
    @SerializedName("items") val cierraSesion: CierreSesion
)

/* Contenido de la respuesta del ws mi información */
data class ModeloMyInformacion(
    @SerializedName("items") val myInfo: MyInfo
)

/* Contenido de la respuesta de productos asociados */
data class ModeloMyProducto(
    @SerializedName("items") val myProducto: MyProducto
)

/* Contenido de la respuesta de Detalle de productos */
data class ModeloDetalleProducto(
    @SerializedName("items") val detalleProducto: DetalleProducto
)
/* Catalogo de parentescos a mostrar */
data class ModeloCatalogoParentescos(
    @SerializedName("items") val catalogoParentescos: CatalogoParentescos
)
/* Servicio de envio de póliza por correo */
data class ModeloEnviaMail(
    @SerializedName("items") val envioMail: EnvioMail
)
/* Servicio de actualización de beneficiarios */
data class ModeloRespuestaBeneficiarios(
    @SerializedName("items") val respuestaBeneficiarios: RespuestaBeneficiarios
)
/* Servicio para obtener la ip */
data class ModeloObteieneIP(
    @SerializedName("ip") var ip : String
)