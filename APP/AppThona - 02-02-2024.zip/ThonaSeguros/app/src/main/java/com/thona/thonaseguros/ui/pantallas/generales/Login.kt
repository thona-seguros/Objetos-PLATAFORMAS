package com.thona.thonaseguros.ui.pantallas.generales

import android.annotation.SuppressLint
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CheckboxColors
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.thona.thonaseguros.R
import com.thona.thonaseguros.datos.modelos.Login
import com.thona.thonaseguros.datos.modelos.Sesion
import com.thona.thonaseguros.funciones.Funciones
import com.thona.thonaseguros.ui.plantillas.AlertaPopUp
import com.thona.thonaseguros.ui.plantillas.CampoPassword
import com.thona.thonaseguros.ui.plantillas.CampoTexto
import com.thona.thonaseguros.ui.theme.Institucional1
import com.thona.thonaseguros.ui.theme.Institucional2
import com.thona.thonaseguros.ui.theme.Institucional3

@SuppressLint("UnrememberedMutableState")
@Composable
fun Login(
    click: (pant: String) -> Unit,
    recupera: (rol: String, usuario: String) -> Unit,
    rol: String,
    iniciarSesion: (rol: String, cuenta: String, pass: String, store: Sesion) -> Unit,
    texto1: String,
    texto2: String,
    loadingProgressBar: Boolean,
    loginCorrecto: Boolean,
    respuestaLogin: Login,
    clickMensaje: (rol: String, opcion: String, idSession: Int) -> Unit,
    funciones: Funciones
){
    var modifier = Modifier.alpha(alpha = 1F)
    if(loadingProgressBar){
        modifier = modifier.alpha(alpha = 0.8F)
    }
    val context = LocalContext.current
    var activoBiometrico by remember { mutableStateOf(false) }
    val biometricManager = remember { BiometricManager.from(context) }
    val isBiometricAvailable = remember {
        biometricManager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL)
    }

    when(isBiometricAvailable){
        BiometricManager.BIOMETRIC_SUCCESS -> {
            activoBiometrico = true
        }
    }

    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = modifier, verticalArrangement = Arrangement.Center){
        var usuario by rememberSaveable { mutableStateOf(value = "") }
        var password by rememberSaveable { mutableStateOf(value = "") }
        var passwordVisible by rememberSaveable { mutableStateOf(false) }
        var aceptoTyC by rememberSaveable { mutableStateOf(value = true) }
        val isValidate by derivedStateOf { usuario.length>2 && password.isNotBlank() && !loadingProgressBar && aceptoTyC }

        var recuperaContrasenia by rememberSaveable { mutableStateOf(false) }

        var color1 = Institucional1
        var color2 = Institucional2
        var color3 = Institucional3
        when(rol){
            "Contratante" -> {
                color1 = Institucional1
                color2 = Institucional2
                color3 = Institucional3
            }
            "Asegurado" -> {
                color1 = Institucional3
                color2 = Institucional2
                color3 = Institucional1
            }
            "Agente" -> {
                color1 = Institucional2
                color2 = Institucional3
                color3 = Institucional1
            }
        }
        val store = Sesion(LocalContext.current)
        val usuarText = store.getAccessUser.collectAsState(initial = "")
        val passText = store.getAccessPassword.collectAsState(initial = "")
        Spacer(modifier = modifier.height(40.dp))
        Row{
            Image(
                painter = painterResource(id = R.drawable.estrella_r),
                contentDescription = "Thona Seguros",
                modifier = modifier.size(150.dp)
            )
        }
        Spacer(modifier = modifier.height(30.dp))
        Row{
            CampoTexto(
                textValue = usuario,
                onValueChange = { usuario = it; },
                onClickButton = { usuario = "" },
                texto = "Usuario",
                tipo = KeyboardType.Text,
                isLoading = loadingProgressBar
            )
        }
        Spacer(modifier = modifier.height(5.dp))
        Row{
            CampoPassword(
                textValue = password,
                onValueChange = {password = it},
                onClickButton = { passwordVisible = !passwordVisible },
                texto = "Contraseña",
                tipo = KeyboardType.Password,
                passwordVisible = passwordVisible,
                accionGo = {if(isValidate)iniciarSesion(rol.uppercase(),usuario,password,store) },
                isLoading = loadingProgressBar
            )
        }
        Spacer(modifier = modifier.height(5.dp))
        /*Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(
                colors = myCheckBoxColors(Color1, Color.Gray),
                checked = aceptoTyC,
                onCheckedChange = { aceptoTyC = !aceptoTyC }
            )
            val text = buildAnnotatedString {
                append("Acepto los ")
                pushStringAnnotation("URL", "https://thonaseguros.mx/terminos-y-condiciones-de-uso-thonapp/")
                withStyle(
                    SpanStyle(
                        color = Color1,
                        fontWeight = FontWeight.Bold
                    )
                ) {
                    append("Terminos y Condiciones")
                }
                pop()
            }
            val uriHandler = LocalUriHandler.current
            ClickableText(text, style = MaterialTheme.typography.labelMedium) { offset ->
                text.getStringAnnotations(
                    tag = "URL",
                    start = offset,
                    end = offset
                ).firstOrNull()?.let { annotation ->
                    uriHandler.openUri(annotation.item)
                }
            }
        }*/
        Spacer(modifier = modifier.height(10.dp))
        if(funciones.biometricos.value){
            usuario=usuarText.value
            password=passText.value
            aceptoTyC = true
            iniciarSesion(rol.uppercase(),usuario,password, store)
            funciones.biometricos.value = false
        }
        Row{
            Button(
                onClick = {
                    iniciarSesion(rol.uppercase(),usuario,password,store)
                },
                modifier = modifier
                    .fillMaxWidth()
                    .padding(
                        start = 20.dp,
                        end = 20.dp
                    ),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 5.dp),
                enabled = isValidate,
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(
                    color1
                )
            ) {
                if(loadingProgressBar){
                    Text(
                        text = "Espera",
                        fontSize = 20.sp,
                        color = Color.White
                    )
                }
                else{
                    Text(
                        text = "Ingresar",
                        fontSize = 20.sp,
                        color = Color.White
                    )
                }
            }
        }
        Row{
            if (activoBiometrico && usuarText.value.isNotEmpty() && passText.value.isNotEmpty()) {
                Spacer(modifier = modifier.width(5.dp))
                IconButton(
                    onClick = { authenticateWithBiometrics(context as FragmentActivity, funciones) }){
                    Icon(
                        imageVector = Icons.Filled.Fingerprint, contentDescription = "FingerPrint", modifier.size(50.dp)
                    )
                }
            }
        }
        Spacer(modifier = modifier.height(5.dp))
        Row{
            TextButton(
                onClick = { click(texto1) },
                colors = ButtonDefaults.buttonColors(
                    contentColor = color2,
                    containerColor = Color.White
                ),
                enabled = !loadingProgressBar
            ) {
                Text(text = "Soy $texto1")
            }
            Spacer(modifier = modifier.width(80.dp))
            TextButton(
                onClick = { click(texto2) },
                colors = ButtonDefaults.buttonColors(
                    contentColor = color3,
                    containerColor = Color.White
                ),
                enabled = !loadingProgressBar
            ) {
                Text(text = "Soy $texto2")
            }
        }

        Spacer(modifier = modifier.height(20.dp))
        Row{
            TextButton(
                onClick = { recuperaContrasenia = true },
                colors = ButtonDefaults.buttonColors(
                    contentColor = Color.Blue,
                    containerColor = Color.White
                ),
                enabled = !loadingProgressBar
            ) {
                Text(text = "Recuperar contraseña")
            }
        }

        var datoUsuario by rememberSaveable { mutableStateOf(value = "") }
        if(recuperaContrasenia){
            AlertDialog(
                onDismissRequest = {
                    recuperaContrasenia = false
                },
                title = {
                    Text(text = "Captura tu usuario (RFC)")
                },
                text = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(shape = CircleShape,value = datoUsuario, onValueChange = { if(it.length<=13)datoUsuario = it })
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            recupera(rol.uppercase(),datoUsuario); datoUsuario = ""; recuperaContrasenia = false
                        },
                        colors = ButtonDefaults.buttonColors(color1),
                        enabled = ( datoUsuario.length>=12 )
                    ) {
                        Text(text = "Aceptar")
                    }
                }
            )
        }

        Spacer(modifier = modifier.height(15.dp))

        if(funciones.asignaPassword.value){
            var nuevaContra by rememberSaveable { mutableStateOf(value = "") }
            AlertDialog(
                onDismissRequest = {
                    funciones.asignaPassword.value
                },
                title = {
                    Text(text = "Asignación de contraseña")
                },
                text = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically){
                            Text(text = "Por tu seguridad, es necesario actualizar tu contraseña.")
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CampoPassword(
                                textValue = nuevaContra,
                                onValueChange = { nuevaContra = it },
                                onClickButton = { passwordVisible = !passwordVisible },
                                texto = "Contraseña",
                                tipo = KeyboardType.Password,
                                passwordVisible = passwordVisible,
                                accionGo = {  },
                                isLoading = loadingProgressBar
                            )
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            funciones.cambioContrasena(usuario,rol.uppercase(),password,nuevaContra,null)
                            funciones.asignaPassword.value = false
                        },
                        colors = ButtonDefaults.buttonColors(color1),
                        enabled = validaContrasenia(nuevaContra)
                    ) {
                        Text(text = "Aceptar")
                    }
                }
            )
        }

        if(funciones.cambioCorrecto.value){
            AlertaPopUp(
                titulo = "Cambio de contraseña",
                mensaje = funciones.respuestaCambioContrasena.value.textoRespuesta,
                clicAceptar = { funciones.cambioCorrecto.value = false; funciones.mensajeRespuesta.value = ""; password = "" },
                clicCancelar = {  },
                colorRol = color1,
                cantidadBotones = 1,
                texto1 = "Aceptar",
                texto2 = ""
            )
        }

        if(!loginCorrecto){
            Row{
                Text(
                    text = respuestaLogin.control.textoRespuesta,
                    fontSize = 15.sp,
                    color = Color.Red
                )
            }
        }
        if (respuestaLogin.control.textoRespuesta == "Tienes una sesion activa."){
            AlertaPopUp(
                titulo = respuestaLogin.control.textoRespuesta,
                mensaje = "¿Deseas cerrar esa sesión?",
                clicAceptar = { clickMensaje(respuestaLogin.items.rol,usuario, respuestaLogin.session.idSession); click(rol) },
                clicCancelar = { click("Login") },
                colorRol = color1,
                cantidadBotones = 2,
                texto1 = "Cerrar",
                texto2 = "Cancelar"
            )
        }
        if (funciones.muestraMensaje.value){
            AlertaPopUp(
                titulo = "Recuperación de contraseña",
                mensaje = funciones.mensajeRespuesta.value,
                clicAceptar = { funciones.muestraMensaje.value = false },
                clicCancelar = {  },
                colorRol = color1,
                cantidadBotones = 1,
                texto1 = "Aceptar",
                texto2 = ""
            )
        }
    }
}

@Composable
fun myCheckBoxColors(check: Color, desCheck: Color): CheckboxColors {
    return CheckboxDefaults.colors(
        checkedColor = check,
        uncheckedColor = desCheck
    )
}

fun authenticateWithBiometrics(context: FragmentActivity, funciones: Funciones){
    val biometricPrompt = BiometricPrompt(
        context,
        ContextCompat.getMainExecutor(context),
        object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                funciones.biometricos.value = true
            }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
            }
        }
    )
    val promptInfo = BiometricPrompt.PromptInfo.Builder()
        .setTitle("Inicio de sesión")
        .setSubtitle("Para ingresar, coloca tu huella en el sensor o el rostro en el lector.")
        .setNegativeButtonText("Ingresar con contraseña")
        .build()

    biometricPrompt.authenticate(promptInfo)
}


@Composable
fun Agente(
    login: (rol: String, usu: String, cont: String, store: Sesion) -> Unit,
    click: (pant: String) -> Unit,
    recupera: (rol: String, usuario: String) -> Unit,
    loadingProgressBar: Boolean,
    loginCorrecto: Boolean,
    respuestaLogin: Login,
    clickMensaje: (rol: String, opc: String, idSession: Int) -> Unit,
    funciones: Funciones
){
    Login(
        rol = "Agente",
        iniciarSesion = login ,
        texto1 = "Asegurado",
        texto2 = "Contratante",
        click = click,
        loadingProgressBar = loadingProgressBar,
        loginCorrecto = loginCorrecto,
        respuestaLogin = respuestaLogin,
        clickMensaje = clickMensaje,
        funciones = funciones,
        recupera = recupera
    )
}

@Composable
fun Asegurado(
    login: (rol: String, usu: String, cont: String, store: Sesion) -> Unit,
    click: (pant: String) -> Unit,
    recupera: (rol: String, usuario: String) -> Unit,
    loadingProgressBar: Boolean,
    loginCorrecto: Boolean,
    respuestaLogin: Login,
    clickMensaje: (rol: String, usuario: String, idSession: Int) -> Unit,
    funciones: Funciones
){
    Login(
        rol = "Asegurado",
        iniciarSesion = login ,
        texto1 = "Agente",
        texto2 = "Contratante",
        click = click,
        loadingProgressBar = loadingProgressBar,
        loginCorrecto = loginCorrecto,
        respuestaLogin = respuestaLogin,
        clickMensaje = clickMensaje,
        funciones = funciones,
        recupera = recupera
    )
}

@Composable
fun Contratante(
    login: (rol: String, usu: String, cont: String, store: Sesion) -> Unit,
    click: (pant: String) -> Unit,
    recupera: (rol: String, usuario: String) -> Unit,
    loadingProgressBar: Boolean,
    loginCorrecto: Boolean,
    respuestaLogin: Login,
    clickmensaje: (rol: String, opc: String, idSession: Int) -> Unit,
    funciones: Funciones
){
    Login(
        rol = "Contratante",
        iniciarSesion = login ,
        texto1 = "Agente",
        texto2 = "Asegurado",
        click = click,
        loadingProgressBar = loadingProgressBar,
        loginCorrecto = loginCorrecto,
        respuestaLogin = respuestaLogin,
        clickMensaje = clickmensaje,
        funciones = funciones,
        recupera = recupera
    )
}