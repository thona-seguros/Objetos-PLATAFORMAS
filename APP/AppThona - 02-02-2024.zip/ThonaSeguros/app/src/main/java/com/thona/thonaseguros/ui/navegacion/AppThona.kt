package com.thona.thonaseguros.ui.navegacion

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.thona.thonaseguros.R
import com.thona.thonaseguros.datos.modelos.Login
import com.thona.thonaseguros.funciones.Funciones
import com.thona.thonaseguros.ui.pantallas.generales.AsignaToken
import com.thona.thonaseguros.ui.pantallas.generales.CambioPassword
import com.thona.thonaseguros.ui.pantallas.generales.CambioToken
import com.thona.thonaseguros.ui.pantallas.generales.Registro
import com.thona.thonaseguros.ui.pantallas.generales.SeleccionRol
import com.thona.thonaseguros.ui.plantillas.AlertaPopUp
import com.thona.thonaseguros.ui.plantillas.ProgressBarLoading
import com.thona.thonaseguros.ui.plantillas.menu.BottomBarNav
import com.thona.thonaseguros.ui.plantillas.menu.DatosPantalla
import com.thona.thonaseguros.ui.plantillas.menu.TopBar
import com.thona.thonaseguros.ui.plantillas.menu.itemsMenu
import com.thona.thonaseguros.ui.theme.Institucional1
import com.thona.thonaseguros.ui.theme.Institucional2
import com.thona.thonaseguros.ui.theme.Institucional3

@Composable
fun AppThona(
    funciones: Funciones,
    navController: NavHostController = rememberNavController()
){

    /*VARIABLES GENERALES*/
    val loadingProgressBar = funciones.progressBar.value
    val rolSel = funciones.rolLogin.value
    val loginCorrecto = funciones.loginCorrecto.value
    val respuestaLogin = funciones.respuestaLogin.value
    val aceptoMensaje = funciones.opcionMensaje.intValue
    val consultaInformacion = funciones.miInformacion.value
    val consultaProductos = funciones.misProductos.value
    val actualizoInfo = funciones.actualizoInfo.value
    val mensajeRespuesta = funciones.mensajeRespuesta.value
    val seleccion = funciones.seleccionMenu.value
    val seleccionoPoliza = funciones.seleccionoPoliza.value
    val cambioContrasenaCorrecto = funciones.cambioCorrecto.value
    val cambioTokenCorrecto = funciones.cambioCorrectoToken.value
    val detalleProducto = funciones.detallesDePoliza.value
    val listaParentescos = funciones.catalogoParentescos.value
    val seleccionoBeneficiario = funciones.seleccionoBeneficiario.value
    val seleccionoFactura = funciones.seleccionoFactura.value
    val muestra = funciones.muestraMensaje.value
    val tramiteSeleccionado = funciones.opcionTramite.intValue

    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentScreen = DatosPantalla.valueOf(
        backStackEntry?.destination?.route?: DatosPantalla.Login.name
    )
    var colorRol = Institucional1
    var nFondo = 0
    if(currentScreen.name.contains("Contratante")){nFondo=1}
    if(currentScreen.name.contains("Agente")){nFondo=2}
    if(currentScreen.name.contains("Asegurado")){nFondo=3}
    when(nFondo){
        1 -> { colorRol = Institucional1 }
        2 -> { colorRol = Institucional2 }
        3 -> { colorRol = Institucional3 }
    }

    Scaffold(
        topBar = {
            TopBar(
                color = colorRol,
                pantallaActual = currentScreen,
                puedeRegresar = false,
                accionRegresar = { navController.navigateUp() },
                actionItems = itemsMenu,
                accionItem = funciones::seleccionMenuTop,
                funciones = funciones
            )
        },
        bottomBar = {
            BottomBarNav(
                color = colorRol,
                navController = navController
            )
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = DatosPantalla.Login.name,
            modifier = Modifier.padding(innerPadding)
        ) {
            /*NAVEGACIÓN GENERAL*/
            composable(route = DatosPantalla.Login.name) {
                Column(verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                    ProgressBarLoading(isLoading = funciones.progressBar.value)
                }
                BackHandler(
                    enabled = !loadingProgressBar,
                    onBack = {  }
                )
                Column(horizontalAlignment = Alignment.CenterHorizontally){
                    SeleccionRol(
                        click = funciones::selecRol,
                        loadingProgressBar = loadingProgressBar
                    )
                    if(funciones.rolLogin.value.isNotEmpty()){
                        LaunchedEffect(key1 = Unit){
                            navController.navigate(route = funciones.rolLogin.value){
                                funciones.reiniciar()
                            }
                        }
                    }
                }
            }
            composable(route = DatosPantalla.Registro.name){
                Column(verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally){
                    ProgressBarLoading(isLoading = loadingProgressBar)
                }
                BackHandler(
                    enabled = !loadingProgressBar,
                    onBack = { navController.navigate(route = DatosPantalla.Login.name){funciones.rolLogin.value = ""} }
                )
                Column {
                    Registro(
                        loadingProgressBar = loadingProgressBar,
                        funciones = funciones
                    )
                }
                if(funciones.opcionMensaje.intValue == 88){
                    LaunchedEffect(key1 = Unit){
                        navController.navigate(route = DatosPantalla.Login.name){
                            funciones.opcionMensaje.intValue = 0
                        }
                    }
                }
            }
            composable(route = DatosPantalla.AgenteContratanteAseguradoAsignaToken.name) {
                Column(verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally){
                    ProgressBarLoading(isLoading = loadingProgressBar)
                }
                BackHandler(
                    enabled = !loadingProgressBar,
                    onBack = {  }
                )
                Image(
                    painter = painterResource(id = R.drawable.estrella_r),
                    contentDescription = "Thona Seguros",
                    modifier = Modifier
                        .padding(2.dp)
                        .fillMaxSize()
                        .blur(4.dp),
                    alpha = 0.07F
                )
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    AsignaToken(
                        funciones = funciones,
                        loadingProgressBar = loadingProgressBar
                    )
                }
                var ok by rememberSaveable { mutableStateOf(value = false) }
                if(loginCorrecto){
                    if(funciones.muestraMensaje.value){
                        AlertaPopUp(
                            titulo = "Asignación exitosa",
                            mensaje = "Gracias, el token ha quedado asignado al usuario ${funciones.datosParaInicioToken.value.usuario}.",
                            clicAceptar = { ok = true; funciones.muestraMensaje.value = false },
                            clicCancelar = {  },
                            colorRol = Institucional3,
                            cantidadBotones = 1,
                            texto1 = "Aceptar",
                            texto2 = ""
                        )
                    }
                    if(ok){
                        LaunchedEffect(key1 = Unit){
                            navController.navigate(route = DatosPantalla.Login.name){
                                funciones.reiniciaTodo()
                            }
                        }
                    }
                }
            }
            composable(route = DatosPantalla.CambioContrasenaAgenteContratanteAsegurado.name){
                Column(verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally){
                    ProgressBarLoading(isLoading = loadingProgressBar)
                }
                BackHandler(
                    enabled = !loadingProgressBar,
                    onBack = {  }
                )
                Image(
                    painter = painterResource(id = R.drawable.estrella_r),
                    contentDescription = "Thona Seguros",
                    modifier = Modifier
                        .padding(2.dp)
                        .fillMaxSize()
                        .blur(4.dp),
                    alpha = 0.07F
                )
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CambioPassword(
                        usuario = respuestaLogin,
                        cambiarContrasena = funciones::cambioContrasena,
                        loadingProgressBar = loadingProgressBar,
                        cambioCorrecto = cambioContrasenaCorrecto,
                        mensajeRespuesta = mensajeRespuesta,
                        clicMensaje = funciones::clickMensaje
                    )
                    if(cambioContrasenaCorrecto && respuestaLogin.items.rol == "ASEGURADO"){
                        if(aceptoMensaje == 1){
                            LaunchedEffect(key1 = Unit){
                                navController.navigate(route = DatosPantalla.AseguradoCuenta.name){
                                    funciones.cambioCorrecto.value = false
                                    funciones.mensajeRespuesta.value = ""
                                    funciones.opcionMensaje.intValue = 0
                                }
                            }
                        }
                    }
                }
            }
            composable(route = DatosPantalla.CambioTokenAgenteContratanteAsegurado.name){
                Column(verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally){
                    ProgressBarLoading(isLoading = loadingProgressBar)
                }
                BackHandler(
                    enabled = !loadingProgressBar,
                    onBack = {  }
                )
                Image(
                    painter = painterResource(id = R.drawable.estrella_r),
                    contentDescription = "Thona Seguros",
                    modifier = Modifier
                        .padding(2.dp)
                        .fillMaxSize()
                        .blur(4.dp),
                    alpha = 0.07F
                )
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CambioToken(
                        usuario = respuestaLogin,
                        cambiarToken = funciones::cambioToken,
                        loadingProgressBar = loadingProgressBar,
                        cambioCorrecto = cambioTokenCorrecto,
                        mensajeRespuesta = mensajeRespuesta,
                        clicMensaje = funciones::clickMensaje,
                        recuperaToken = funciones::recuperaToken,
                        muestraMensajex = muestra,
                        cierraSesion = funciones::recuperaTok
                    )
                    if(cambioTokenCorrecto && respuestaLogin.items.rol == "ASEGURADO"){
                        if(aceptoMensaje == 1){
                            LaunchedEffect(key1 = Unit){
                                navController.navigate(route = DatosPantalla.AseguradoCuenta.name){
                                    funciones.cambioCorrectoToken.value = false
                                    funciones.mensajeRespuesta.value = ""
                                    funciones.opcionMensaje.intValue = 0
                                }
                            }
                        }
                    }
                }
                if(!loginCorrecto){
                    LaunchedEffect(key1 = Unit){
                        navController.navigate(route = DatosPantalla.Login.name){
                            funciones.reiniciaTodo()
                        }
                    }
                }
            }

            /*ASEGURADO*/
            composable(route = DatosPantalla.Asegurado.name){
                LoginAsegurado(
                    loadingProgressBar = loadingProgressBar,
                    navController = navController,
                    funciones = funciones,
                    colorRol = colorRol,
                    loginCorrecto = loginCorrecto,
                    respuestaLogin = respuestaLogin,
                    rolSel = rolSel, aceptoMensaje
                )
            }
            composable(route = DatosPantalla.PromocionAsegurado.name){
                PomocionAsegurado(loadingProgressBar = loadingProgressBar, navController = navController)
            }
            composable(route = DatosPantalla.AseguradoCuenta.name) {
                CuentaAsegurado(
                    loadingProgressBar = loadingProgressBar,
                    respuestaLogin = respuestaLogin,
                    consultaInformacion = consultaInformacion,
                    consultaProductos = consultaProductos,
                    funciones = funciones,
                    navController = navController,
                    actualizoInfo = actualizoInfo,
                    mensajeRespuesta = mensajeRespuesta,
                    seleccion = seleccion
                )
            }
            composable(route = DatosPantalla.AseguradoTramites.name) {
                AseguradoTramites(
                    loadingProgressBar = loadingProgressBar,
                    respuestaLogin = respuestaLogin,
                    consultaProductos = consultaProductos,
                    funciones = funciones,
                    navController = navController,
                    tramite = funciones::selecTramite
                )
                when(tramiteSeleccionado){
                    1 -> {
                        LaunchedEffect(key1 = Unit){
                            navController.navigate(route = DatosPantalla.PromocionAsegurado.name){
                                funciones.opcionTramite.intValue = 0
                            }
                        }
                    }
                }
            }
            composable(route = DatosPantalla.AseguradoPolizas.name) {
                PolizasAsegurado(
                    loadingProgressBar = loadingProgressBar,
                    respuestaLogin = respuestaLogin,
                    funciones = funciones,
                    consultaProductos = consultaProductos,
                    navController = navController,
                    seleccionoPoliza = seleccionoPoliza
                )
            }
            composable(route = DatosPantalla.AseguradoDetallePoliza.name){
                DetalleDePolizasAsegurado(
                    loadingProgressBar = loadingProgressBar,
                    navController = navController,
                    funciones = funciones,
                    respuestaLogin = respuestaLogin,
                    consultaInformacion = consultaInformacion,
                    detalleProducto = detalleProducto,
                    seleccionoBeneficiario = seleccionoBeneficiario,
                    seleccionoFactura = seleccionoFactura
                )
            }
            composable(route = DatosPantalla.AseguradoDetallesFacturas.name){
                DetalleFacturasAsegurado(
                    loadingProgressBar = loadingProgressBar,
                    navController = navController,
                    funciones = funciones
                )
            }
            composable(route = DatosPantalla.AseguradoBeneficiarios.name){
                BeneficiariosAsegurado(
                    loadingProgressBar = loadingProgressBar,
                    navController = navController,
                    detalleProducto = detalleProducto,
                    funciones = funciones,
                    listaParentescos = listaParentescos,
                    aceptoMensaje = aceptoMensaje
                )
            }

            /*CONTRATANTE*/
            composable(route = DatosPantalla.Contratante.name) {
                LoginContratante(
                    loadingProgressBar = loadingProgressBar,
                    navController = navController,
                    funciones = funciones,
                    loginCorrecto = loginCorrecto,
                    respuestaLogin = respuestaLogin,
                    rolSel = rolSel
                )
            }

            composable(route = DatosPantalla.MenuContratante.name){
                MenuContratante(
                    loadingProgressBar = loadingProgressBar,
                    respuestaLogin = respuestaLogin
                )
            }

            /*AGENTE*/
            composable(route = DatosPantalla.Agente.name) {
                LoginAgente(
                    loadingProgressBar = loadingProgressBar,
                    navController = navController,
                    funciones = funciones,
                    loginCorrecto= loginCorrecto,
                    respuestaLogin = respuestaLogin,
                    rolSel = rolSel
                )
            }
            composable(route = DatosPantalla.MenuAgente.name) {
                MenuAgente(
                    loadingProgressBar = loadingProgressBar,
                    respuestaLogin = respuestaLogin
                )
            }
        }
    }
}

fun validaSesion(datosUsuario: Login): Boolean{
    return datosUsuario.items.nomUsuario.isNotEmpty()
}