package com.thona.thonaseguros.datos.webServices

import com.thona.thonaseguros.datos.modelos.Control
import com.thona.thonaseguros.datos.modelos.ModeloAplicaCobranza
import com.thona.thonaseguros.datos.modelos.ModeloCambioPassword
import com.thona.thonaseguros.datos.modelos.ModeloCambioToken
import com.thona.thonaseguros.datos.modelos.ModeloCatalogoParentescos
import com.thona.thonaseguros.datos.modelos.ModeloCierreSesion
import com.thona.thonaseguros.datos.modelos.ModeloConfirmaToken
import com.thona.thonaseguros.datos.modelos.ModeloDetalleProducto
import com.thona.thonaseguros.datos.modelos.ModeloEnviaMail
import com.thona.thonaseguros.datos.modelos.ModeloEnviaRegistro
import com.thona.thonaseguros.datos.modelos.ModeloLogin
import com.thona.thonaseguros.datos.modelos.ModeloMyInformacion
import com.thona.thonaseguros.datos.modelos.ModeloMyProducto
import com.thona.thonaseguros.datos.modelos.ModeloObteieneIP
import com.thona.thonaseguros.datos.modelos.ModeloRecuperaPassword
import com.thona.thonaseguros.datos.modelos.ModeloRecuperaToken
import com.thona.thonaseguros.datos.modelos.ModeloRespuestaBeneficiarios
import com.thona.thonaseguros.datos.modelos.ModeloVerificaDato
import com.thona.thonaseguros.datos.modelos.ObtenCaratulaItem
import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query
import retrofit2.http.Url

interface Metodos {
    /* REGISTRO */
    @POST("AltaRegistro")
    suspend fun verificaDatos(@Body body: RequestBody): Response<ModeloVerificaDato>

    @POST("EnviaRegistro")
    suspend fun enviaRegistro(@Body body: RequestBody): Response<ModeloEnviaRegistro>

    @POST("login")
    suspend fun login(@Body body: RequestBody): Response<ModeloLogin>

    @POST("cambioPassword")
    suspend fun cambioPassword(@Body body: RequestBody): Response<ModeloCambioPassword>

    @POST("cambioToken")
    suspend fun cambioToken(@Body body: RequestBody): Response<ModeloCambioToken>

    @POST("ConfirmaToken")
    suspend fun confirmaToken(@Body body: RequestBody): Response<ModeloConfirmaToken>

    @POST("recuperaToken")
    suspend fun recuperaToken(@Body body: RequestBody): Response<ModeloRecuperaToken>

    @POST("correoPasswordTemp")
    suspend fun recuperaPassword(@Body body: RequestBody): Response<ModeloRecuperaPassword>

    @POST("cierreSesion")
    suspend fun cierreSesion(@Body body: RequestBody): Response<ModeloCierreSesion>

    @POST("MyInfo")
    suspend fun consultaInfo(@Body body: RequestBody): Response<ModeloMyInformacion>

    @POST("MyProduct")
    suspend fun consultaProductos(@Body body: RequestBody): Response<ModeloMyProducto>

    @POST("DetProducts")
    suspend fun detalleProducto(@Body body: RequestBody): Response<ModeloDetalleProducto>

    @POST("UpdMyInfo")
    suspend fun actualizaInfo(@Body body: RequestBody): Response<ModeloCambioPassword>

    @POST("updBenef")
    suspend fun actualizaBeneficiarios(@Body body: RequestBody): Response<ModeloRespuestaBeneficiarios>

    @POST("reports")
    suspend fun enviaMail(@Body body: RequestBody): Response<ModeloEnviaMail>

    @GET("catParentesco")
    suspend fun catalogoParentescos(): Response<ModeloCatalogoParentescos>

    @GET
    suspend fun obtieneIP(@Url url: String): Response<ModeloObteieneIP>

    @GET
    suspend fun enviaMailRegistro(@Url url: String): Response<Any>

    @POST("AplicaCobranzaApp")
    suspend fun aplicaCobranza(@Query("token") token: String, @Body body: RequestBody): Response<ModeloAplicaCobranza>

    @GET("CreaPDF")
    suspend fun obtieneCaratula(@Query("idP") poliza: Int): Response<ObtenCaratulaItem>

    @POST("CreaOpenPay")
    suspend fun creaReferencia(@Body body: RequestBody): Response<Control>
}