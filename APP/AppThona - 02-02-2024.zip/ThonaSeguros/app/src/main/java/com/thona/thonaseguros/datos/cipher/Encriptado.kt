package com.thona.thonaseguros.datos.cipher

import android.annotation.SuppressLint
import android.util.Base64
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.spec.SecretKeySpec

@SuppressLint("GetInstance")
fun desencriptar(datos: String, pass: String): String{
    return try{
        val secretKey: SecretKeySpec = generateKey(pass)
        val cipher: Cipher = Cipher.getInstance("AES")
        cipher.init(Cipher.DECRYPT_MODE, secretKey)
        val datosDescodificados: ByteArray = Base64.decode(datos, Base64.DEFAULT)
        val datosDesenciptadosByte: ByteArray = cipher.doFinal(datosDescodificados)
        val datosDesencriptadosString = String(datosDesenciptadosByte)
        datosDesencriptadosString
    } catch (e: Throwable){
        ""
    }
}

@SuppressLint("GetInstance")
fun encriptar(datos: String, pass: String): String {
    return try{
        val secretKey: SecretKeySpec = generateKey(pass)
        val cipher: Cipher = Cipher.getInstance("AES")
        cipher.init(Cipher.ENCRYPT_MODE, secretKey)
        val datosEncriptadosBytes: ByteArray = cipher.doFinal(datos.toByteArray())
        val datosEncriptadosString: String = Base64.encodeToString(datosEncriptadosBytes, Base64.DEFAULT)
        datosEncriptadosString
    }catch (e: Throwable){
        ""
    }
}

fun generateKey(pass: String): SecretKeySpec {
    val sha: MessageDigest = MessageDigest.getInstance("SHA-256")
    var key: ByteArray = pass.toByteArray(Charsets.UTF_8)
    key = sha.digest(key)
    return SecretKeySpec(key, "AES")
}

fun textoAleatorio(length: Int) : String {
    val charset = ('a'..'z') + ('A'..'Z') + ('0'..'9')
    return (1..length)
        .map { charset.random() }
        .joinToString("")
}