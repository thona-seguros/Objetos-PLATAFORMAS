package com.thona.thonaseguros.ui.plantillas

import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color

@Composable
fun AlertaPopUp(
    titulo: String,
    mensaje: String,
    clicAceptar: () -> Unit,
    clicCancelar: () -> Unit,
    colorRol: Color,
    cantidadBotones: Int,
    texto1: String,
    texto2: String,
    /*cargando: Boolean*/
){
    val openDialog = remember { mutableStateOf(false) }
    openDialog.value = true
    AlertDialog(
        onDismissRequest = {
            openDialog.value = false
        },
        title = {
            Text(text = titulo)
        },
        text = {
            Text(mensaje)
        },
        confirmButton = {
            Button(
                /*enabled = !cargando,*/
                onClick = {
                    clicAceptar();openDialog.value=false
                },
                colors = ButtonDefaults.buttonColors(colorRol)
            ) {
                Text(texto1)
            }
        },
        dismissButton = {
            if(cantidadBotones == 2){
                Button(
                    /*enabled = !cargando,*/
                    onClick = {
                        clicCancelar();openDialog.value=false
                    },
                    colors = ButtonDefaults.buttonColors(colorRol)
                ) {
                    Text(texto2)
                }
            }
        }
    )
}