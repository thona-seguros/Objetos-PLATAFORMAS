package com.thona.thonaseguros.permisos

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.pm.PackageManager
import android.location.Location
import android.widget.Toast
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.thona.thonaseguros.funciones.Funciones
import com.thona.thonaseguros.ui.plantillas.AlertaPopUp
import com.thona.thonaseguros.ui.theme.Institucional1

private lateinit var fusedLocationClient: FusedLocationProviderClient

fun pidePermiso(
    actividad: Activity,
    permiso: String
){
    ActivityCompat.requestPermissions(actividad, arrayOf(permiso), 0)
}

@Composable
fun CheckPermission(actividad: Activity, permiso: String, mensaje: String, clicMensaje: (opcion: Int) -> Unit) {
    if (ContextCompat.checkSelfPermission(actividad, permiso) == PackageManager.PERMISSION_DENIED) {
        AlertaPopUp(
            titulo = "Solicitud de permiso",
            mensaje = mensaje,
            clicAceptar =  {clicMensaje(1)},
            clicCancelar = { clicMensaje(2) },
            colorRol = Institucional1,
            cantidadBotones = 2,
            texto1 = "Aceptar",
            texto2 = "Cancelar"
        )
    } else {
        Toast.makeText(actividad, "Permiso $permiso aceptado", Toast.LENGTH_SHORT).show()
    }
}

@Composable
fun permisos(funciones: Funciones, actividad: Activity, permiso: String, clicMensaje: (opcion: Int) -> Unit): Boolean{
    var aceptoPermiso = false
    if(ContextCompat.checkSelfPermission(actividad, permiso) == PackageManager.PERMISSION_GRANTED){
        aceptoPermiso = true
        when (permiso){
            Manifest.permission.ACCESS_FINE_LOCATION -> {
                Ubicacion(funciones = funciones, actividad = actividad, clicMensaje = clicMensaje)
            }
        }
    }
    return aceptoPermiso
}

@SuppressLint("MissingPermission")
@Composable
fun Ubicacion (funciones: Funciones, actividad: Activity, clicMensaje: (opcion: Int) -> Unit){
    fusedLocationClient = LocationServices.getFusedLocationProviderClient(actividad)
    val tieneDatos = remember { mutableStateOf(true) }
    fusedLocationClient.lastLocation
        .addOnSuccessListener { location : Location? ->
            funciones::datosUbicacion.invoke(location)
            funciones::obtieneIP.invoke()
            tieneDatos.value = location?.latitude != null
        }
    if(!tieneDatos.value){
        AlertaPopUp(
            titulo = "Habilita tu ubicación",
            mensaje = "Para poder continuar, es necesario tener activo el servicio de ubicación.\nPor favor activa tu ubicación y vuelve a intentar.\n\nLa puedes activar desde Ajustes > Ubicación. \n\n*NOTA: Una vez activado espera 3 minutos y vuelve a intentarlo.",
            clicAceptar = { clicMensaje(2) },
            clicCancelar = {  },
            colorRol = Institucional1,
            cantidadBotones = 1,
            texto1 = "Aceptar",
            texto2 = "Cancelar"
        )
    }
}