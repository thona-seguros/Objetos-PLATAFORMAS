package com.thona.thonaseguros.ui.pantallas.asegurado

import android.Manifest
import android.app.Activity
import android.content.Context
import android.os.Build
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AssignmentInd
import androidx.compose.material.icons.outlined.AttachEmail
import androidx.compose.material.icons.outlined.FactCheck
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.thona.thonaseguros.datos.modelos.DetalleProducto
import com.thona.thonaseguros.datos.modelos.InfoItem
import com.thona.thonaseguros.datos.modelos.FacturaItem
import com.thona.thonaseguros.funciones.Funciones
import com.thona.thonaseguros.permisos.permisos
import com.thona.thonaseguros.permisos.pidePermiso
import com.thona.thonaseguros.ui.plantillas.AlertaPopUp
import com.thona.thonaseguros.ui.plantillas.menu.ExpandableListViewModel
import com.thona.thonaseguros.ui.plantillas.menu.ListadoMenu
import com.thona.thonaseguros.ui.theme.Institucional3

@Composable
fun DetallePolizas(
    clicKEdicion: () -> Unit,
    clickFactura: (factura: FacturaItem) -> Unit,
    usuario: InfoItem,
    detallePoliza: DetalleProducto,
    clickDescargaDocumento: (link: String, titulo: String, descripcion: String, contexto: Context) -> Unit,
    /*clickDescargaCG: (link: String, titulo: String, contexto: Context) -> Unit,*/
    clickEnviaPorCorreo: (idPoliza: Int, subgrupo: Int) -> Unit,
    mensaje: String,
    muestraMensaje: Boolean,
    funciones: Funciones,
    loadingProgressBar: Boolean
){
    var modifier = Modifier.alpha(alpha = 1F)
    if(loadingProgressBar){
        modifier = modifier.alpha(alpha = 0.8F)
    }
    var clickBoton by rememberSaveable { mutableIntStateOf(0) }
    val poliza = detallePoliza.detalleProducto.idPoliza.substringBefore("-").toInt()
    val subgrupo = detallePoliza.detalleProducto.idPoliza.substringAfter("-").toInt()
    Column{
        Row (modifier = modifier.offset(7.dp)) {
            Text(
                text = "Póliza ${detallePoliza.detalleProducto.idPoliza}",
                fontWeight = FontWeight.Bold
            )
        }
        Row (modifier = modifier.offset(7.dp)) {
            Text(
                text = "Estatus: ${detallePoliza.detalleProducto.status}",
                fontWeight = FontWeight.Bold
            )
        }
        Row (modifier = modifier.offset(7.dp)) {
            Text(
                text = "Periodicidad: ${detallePoliza.detalleProducto.codigoPlanPago}",
                fontWeight = FontWeight.Bold
            )
        }
        Row (modifier = modifier.offset(7.dp)) {
            Text(
                text = "Vigencia: ${detallePoliza.detalleProducto.vicenciaInicial} - ${detallePoliza.detalleProducto.vigenciaFinal}",
                fontWeight = FontWeight.Normal
            )
        }
        Row (modifier = modifier
            .offset(7.dp)
            .padding(8.dp)) {
            Text(
                text = detallePoliza.detalleProducto.descripcionSeguro,
                fontWeight = FontWeight.Light,
                fontSize = 15.sp
            )
        }
        Column {
            Spacer(modifier = modifier.height(15.dp))
            Divider(color = Institucional3, thickness = 1.dp)
            Column {
                ListadoMenu(
                    clicKEdicion = clicKEdicion,
                    clickFactura = clickFactura,
                    viewModel = ExpandableListViewModel(),
                    datos = detallePoliza
                )
            }
            Divider(color = Institucional3, thickness = 1.dp)
        }
        Spacer(modifier = modifier.height(20.dp))
        val mContext = LocalContext.current
        Row (modifier = modifier
            .fillMaxWidth(), horizontalArrangement = Arrangement.Center){
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                OutlinedButton(
                    onClick = {
                        clickBoton = 1
                    },
                    modifier= modifier.size(60.dp),
                    shape = CircleShape,
                    border= BorderStroke(width = 5.dp, color = Institucional3),
                    contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor =  Institucional3)
                ) {
                    Icon(imageVector = Icons.Outlined.AssignmentInd ,contentDescription = "", tint= Institucional3)
                }
                Spacer(modifier = modifier.height(5.dp))
                Text(
                    text = "Descargar Póliza",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = modifier.width(15.dp))
            Column (horizontalAlignment = Alignment.CenterHorizontally){
                OutlinedButton(
                    onClick = {
                        clickBoton = 2
                    },
                    modifier= modifier.size(60.dp),
                    shape = CircleShape,
                    border= BorderStroke(width = 5.dp, color = Institucional3),
                    contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor =  Institucional3)
                ) {
                    Icon(imageVector = Icons.Outlined.FactCheck ,contentDescription = "", tint= Institucional3)
                }
                Spacer(modifier = modifier.height(5.dp))
                Text(
                    text = "Descargar C.G.",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = modifier.width(15.dp))
            Column (horizontalAlignment = Alignment.CenterHorizontally){
                OutlinedButton(
                    onClick = {
                        clickBoton = 3
                    },
                    modifier= modifier.size(60.dp),
                    shape = CircleShape,
                    border= BorderStroke(width = 5.dp, color = Institucional3),
                    contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor =  Institucional3)
                ) {
                    Icon(imageVector = Icons.Outlined.AttachEmail ,contentDescription = "", tint= Institucional3)
                }
                Spacer(modifier = modifier.height(5.dp))
                Text(
                    text = "Enviar Email",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            if(clickBoton != 0){
                when(clickBoton){
                    1->{
                        val url = funciones.urlCaratula.value
                        println("URL DE POLIZA-> $url")
                        val permiosoAlm = permisos(funciones = funciones, actividad = mContext as Activity, permiso = Manifest.permission.WRITE_EXTERNAL_STORAGE, clicMensaje = funciones::clickMensaje)
                        AlertaPopUp(
                            titulo = "Descargar póliza",
                            mensaje = "¿Deseas descargar la póliza ${detallePoliza.detalleProducto.idPoliza}? ",
                            clicAceptar = {
                                if(permiosoAlm || Build.VERSION.SDK_INT >= Build.VERSION_CODES.R){
                                    Toast.makeText(
                                        mContext,
                                        "Se esta descargando la poliza",
                                        Toast.LENGTH_SHORT
                                    ).show(); clickBoton = 0; funciones.generaCaratula(poliza, mContext); /*if(url.isNotEmpty())clickDescargaDocumento(url,"Poliza","Descarga de póliza",mContext);*/ funciones.urlCaratula.value = ""
                                }else{
                                    Toast.makeText(
                                        mContext,
                                        "No tiene permiso para guardar datos",
                                        Toast.LENGTH_SHORT
                                    ).show(); clickBoton = 99
                                }
                            },
                            clicCancelar = { clickBoton = 0 },
                            colorRol = Institucional3,
                            cantidadBotones = 2,
                            texto1 = "Descargar",
                            texto2 = "Cancelar"
                        )
                    }
                    2->{
                        val permiosoAlm = permisos(funciones = funciones, actividad = mContext as Activity, permiso = Manifest.permission.WRITE_EXTERNAL_STORAGE, clicMensaje = funciones::clickMensaje)
                        AlertaPopUp(
                            titulo = "Descargar condiciones generales",
                            mensaje = "¿Deseas descargar las condiciones generales de la póliza ${detallePoliza.detalleProducto.idPoliza}?",
                            clicAceptar = {
                                if(permiosoAlm || Build.VERSION.SDK_INT >= Build.VERSION_CODES.R){
                                    Toast.makeText(
                                        mContext,
                                        "Icono para descargar Condiciones Generales",
                                        Toast.LENGTH_SHORT
                                    ).show(); clickBoton = 0; clickDescargaDocumento("https://thona01.azurewebsites.net/temp/VI2019Condiciones_Generales.pdf", "Condiciones Generales","Descarga de CG", mContext)
                                }else{
                                    Toast.makeText(
                                        mContext,
                                        "No tiene permiso para guardar datos",
                                        Toast.LENGTH_SHORT
                                    ).show(); clickBoton = 99
                                }
                            },
                            clicCancelar = { clickBoton = 0 },
                            colorRol = Institucional3,
                            cantidadBotones = 2,
                            texto1 = "Descargar",
                            texto2 = "Cancelar"
                        )
                    }
                    3->{
                        AlertaPopUp(
                            titulo = "Enviar documentación",
                            mensaje = "Se enviará al mail ${usuario.emailUsuario.first().email} los documentos de la póliza ${detallePoliza.detalleProducto.idPoliza}",
                            clicAceptar = { Toast.makeText(
                                mContext,
                                "Se esta realizando el envio del mail",
                                Toast.LENGTH_SHORT
                            ).show(); clickBoton = 0; clickEnviaPorCorreo(poliza,subgrupo) },
                            clicCancelar = { clickBoton = 0 },
                            colorRol = Institucional3,
                            cantidadBotones = 2,
                            texto1 = "Enviar",
                            texto2 = "Cancelar"
                        )
                    }
                    99->{
                        pidePermiso(
                            actividad = mContext as Activity,
                            permiso = Manifest.permission.WRITE_EXTERNAL_STORAGE
                        )
                        clickBoton=0
                    }
                }
            }
            if(muestraMensaje){
                AlertaPopUp(
                    titulo = "Se ha enviado la póliza por correo",
                    mensaje = mensaje,
                    clicAceptar = { funciones.muestraMensaje.value = false },
                    clicCancelar = {  },
                    colorRol = Institucional3,
                    cantidadBotones = 1,
                    texto1 = "Aceptar",
                    texto2 = ""
                )
            }
        }
    }
}