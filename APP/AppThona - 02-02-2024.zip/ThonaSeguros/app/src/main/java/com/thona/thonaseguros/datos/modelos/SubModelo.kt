package com.thona.thonaseguros.datos.modelos

import com.google.gson.annotations.SerializedName

/* Contenido de la respuesta Aplica Cobranza */
data class AplicaCobranza(
    @SerializedName("CONTROL") val control: AplicaCobranzaItem
)
/* Contenido de la respuesta Alta Registro */
data class VerificaDatos(
    @SerializedName("datos") val datos: VerificaDatoItem,
    @SerializedName("control") val control: Control
)
/* Contenido de la respuesta Envio Registro */
data class AltaRegistro(
    @SerializedName("control") val control: ControlRegistro
)
/* Contenido de la respuesta de login */
data class Login(
    @SerializedName("session") val session: SesionItem,
    @SerializedName("datos") val items: LoginItem,
    @SerializedName("control") val control: Control
)
/* Contenido de la respuesta al cambio de password */
data class CambioPassword(
    @SerializedName("control") val control: Control
)
/* Contenido de la respuesta al cambio de token */
data class CambioToken(
    @SerializedName("control") val control: Control
)
/* Contenido de la respuesta a la confirmación de token */
data class ConfirmaToken(
    @SerializedName("control") val control: Control
)
/* Contenido de la respuesta de recuperar token */
data class RecuperaToken(
    @SerializedName("control") val control: Control
)
/* Contenido de la respuesta de recuperar token */
data class RecuperaPassword(
    @SerializedName("control") val control: Control
)
/* Contenido de la respuesta cierre de sesión */
data class CierreSesion(
    @SerializedName("control") val control: Control
)
/* Contenido de la respuesta del ws mi información */
data class MyInfo(
    @SerializedName("datos") val datos: InfoItem,
    @SerializedName("control") val control: Control
)
/* Contenido de la respuesta de rpductos asociados */
data class MyProducto(
    @SerializedName("IdUnico") val idAsegurado: IdUnicoItem,
    @SerializedName("productos") val productos: List<MyProdcutoItem>,
    @SerializedName("control") val control: Control
)
/* Contenido de la respuesta de Detalle de productos */
data class DetalleProducto(
    @SerializedName("productos") val detalleProducto: DetalleProductoItem,
    @SerializedName("Menus") val detalleMenu: List<DetalleMenuItem>,
    @SerializedName("cobertura") val detalleCoberturas: List<DetalleCoberturaItem>,
    @SerializedName("beneficiario") val detalleBeneficiarios: List<DetalleBeneficiarioItem>,
    @SerializedName("facturas") val facturas: List<FacturaItem>,
    @SerializedName("control") val control: Control
)
/* Catalogo de parentescos a mostrar */
data class CatalogoParentescos(
    @SerializedName("datos") val listaParentescos: List<ParentescoItem>,
    @SerializedName("control") val control: Control
)
/* Servicio de envio de póliza por correo */
data class EnvioMail(
    @SerializedName("control") val control: Control
)
/* Servicio de actualización de beneficiarios */
data class RespuestaBeneficiarios(
    @SerializedName("control") val control: Control
)