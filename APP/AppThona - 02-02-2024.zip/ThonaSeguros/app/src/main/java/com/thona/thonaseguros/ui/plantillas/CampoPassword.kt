package com.thona.thonaseguros.ui.plantillas

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun CampoPassword(
    textValue: String,
    onValueChange: (String) -> Unit,
    onClickButton: () -> Unit,
    texto: String,
    tipo: KeyboardType,
    passwordVisible: Boolean,
    accionGo: () -> Unit,
    isLoading: Boolean,
    isError: Boolean = false
) {
    val keyboardController = LocalSoftwareKeyboardController.current
    OutlinedTextField(
        value = textValue,
        onValueChange = onValueChange,
        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 20.dp, end = 20.dp),
        label = { Text(text = texto) },
        placeholder = { Text(text = texto) },
        trailingIcon = {
            val image = if (passwordVisible)
                Icons.Filled.Visibility
            else Icons.Filled.VisibilityOff
            val descripcion = if (passwordVisible) "Ocultar" else "Mostrar"
            IconButton(
                onClick = onClickButton,
                enabled = !isLoading
            ) {
                Icon(imageVector = image, descripcion)
            }
        },
        enabled = !isLoading,
        isError = isError,
        keyboardOptions = KeyboardOptions(
            autoCorrect = false,
            keyboardType = tipo,
            imeAction = ImeAction.Go
        ),
        keyboardActions = KeyboardActions(
            onGo = {
                accionGo.invoke()
                keyboardController?.hide()
            }
        ),
        shape = CircleShape
    )
}
