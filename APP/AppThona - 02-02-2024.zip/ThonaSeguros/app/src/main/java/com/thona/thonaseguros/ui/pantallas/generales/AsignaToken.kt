package com.thona.thonaseguros.ui.pantallas.generales

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Checkbox
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.thona.thonaseguros.funciones.Funciones
import com.thona.thonaseguros.ui.theme.Institucional3

@Composable
fun AsignaToken(
    funciones: Funciones,
    loadingProgressBar: Boolean
){
    var modifier = Modifier.alpha(alpha = 1F)
    if(loadingProgressBar){
        modifier = modifier.alpha(alpha = 0.8F)
    }

    val usuario = funciones.datosParaInicioToken.value.usuario

    var token by rememberSaveable { mutableStateOf(value = "") }
    var check1 by rememberSaveable { mutableStateOf(value = false) }
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = modifier.fillMaxSize()){
        Row(verticalAlignment = Alignment.CenterVertically){
            Text(text = "A continuación se va a asignar el token unico para transaccionar dentro de la APP Thona.")
        }
        Spacer(modifier = modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically){
            Text(text = "Por favor, toma en cuenta que este token es personal y no debes compartirlo con nadie.")
        }
        Spacer(modifier = modifier.height(15.dp))
        OutlinedTextField(
            value = token,
            onValueChange = { if(it.length <= 6)token = it },
            shape = CircleShape
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(colors = myCheckBoxColors(Institucional3, Color.Gray), checked = check1, onCheckedChange = {check1 = !check1})
            Text(text = "Terminos y condiciones")
        }
        OutlinedButton(
            onClick = {
                funciones.confirmaToken(funciones.datosParaInicioToken.value.rol,usuario, token,1)
                funciones.pideToken.value = false
            },
            enabled = (token.length == 6 && check1)
        ) {
            Text(text = "Asignar")
        }
    }
}