package com.thona.thonaseguros.datos.modelos

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.google.gson.annotations.SerializedName
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/* Datos de la aplicación de pago*/
data class AplicaCobranzaItem(
    @SerializedName("FACTURA") val factura: Int,
    @SerializedName("ESTATUS") val estatus: String,
    @SerializedName("MENSAJE") val mensaje: String
)
/* Datos del usuario que se verifico */
data class VerificaDatoItem(
    @SerializedName("NombreUser") val nombre: String,
    @SerializedName("TelMovil") val telefono: String,
    @SerializedName("Email") val email: String,
    @SerializedName("CodUnico") val codigoUnico: String,
    @SerializedName("CodUsuario") val codUsuario: String
)
/* ID unico de la sesión */
data class SesionItem(
    @SerializedName("idSession") val idSession: Int                 //ID unico de sesión
)
/* Datos del servicio de login */
data class LoginItem (
    @SerializedName("Usuario") val codUsuario: String,              //Codigo del usuario logueado
    @SerializedName("Rol") val rol: String,                         //Rol del usuario logueado
    @SerializedName("Nombre") val nomUsuario: String,               //Nombre del usuario logueado
    @SerializedName("ApellidoPaterno") val apPatUsuario: String,    //Apellido paterno del usuario logueado
    @SerializedName("UltSesion") val ultimaSesion: String,          //Fecha y hora de ultima sesión
)
/* Nodo de CONTROL */
data class Control (
    @SerializedName("ReturnNumError") val numeroRespuesta: String,  //Numero de error /*TODO REVISAR TIPO DE DATO*/
    @SerializedName("ReturnError") val textoRespuesta: String,      //Descripción del codigo
)
/* Nodo de CONTROL Para registro */
data class ControlRegistro (
    @SerializedName("ReturnNumError") val numeroRespuesta: String,  //Numero de error
    @SerializedName("vMsjSalida") val textoRespuesta: String,      //Descripción del codigo
    @SerializedName("vl_Enlace") val enlace: String,      //Enlace que ira en el correo
    @SerializedName("vl_EnviaCorreo") val servicioCorreo: String,      //Servicio que se va a ejecutar para eniar el correo
)
/* Datos del servicio de mi información */
data class InfoItem (
    @SerializedName("NombreUser") val nombreUsuario: String,        //Nombre del usuario logueado
    @SerializedName("SexoUser") val sexoUsuario: String,            //Sexo del usuario
    @SerializedName("NacimUser") val fechaNacimiento: String,       //Fecha de nacimiento del usuario
    @SerializedName("DirecUser") val direccionUsuario: String,      //Dirección del usuario
    @SerializedName("RFCUser") val rfcUsuario: String,              //RFC del usuario
    @SerializedName("CelUser") val celUsuario: List<TelsItem>,      //Lista de telefonos registrados del usuario
    @SerializedName("EmailUser") val emailUsuario: List<EmailsItem>,//Lista de emails registrados del usuario
    @SerializedName("CURPUser") val curpUsuario: String,            //CURP del usuario
    @SerializedName("nPolizas") val cantidadPolizas: Int            //Conteo de polizas activas del usuario
)
/* Datos de la lista de telefonos */
data class TelsItem(
    @SerializedName("telefono") val tel: Long,                      //Numero de teléfono
    @SerializedName("principal") val esPrincipal: String,           //Si es principal
    @SerializedName("correlativo") val correlativo: Int             //Correlativo
)
/* Datos de la lista de correos */
data class EmailsItem(
    @SerializedName("email") val email: String,                     //email registrado
    @SerializedName("principal") val esPrincipal: String,           //Si es el principal
    @SerializedName("correlativo") val correlativo: Int             //Correlativo
)
/* Codigo del asegurado que inicio sesión */
data class IdUnicoItem (
    @SerializedName("codAsegurado") val codAsegurado: Int           //Codigo del asegurado
)
/* Datos del servicio consulta de productos */
data class MyProdcutoItem (
    @SerializedName("IdPoliza") val idPoliza: String,               //ID unico de poliza
    @SerializedName("FecVigencia") val fechaVigencia: String,       //Fecha de vigencia de la póliza
    @SerializedName("IdTipoSeg") val idTipoSeguro: String,          //Codigo del tipo de seguro asociado a la póliza
    @SerializedName("DescSeg") val descTipoSeguro: String,          //Descripción del tipo de seguro
    @SerializedName("Status") val statusPoliza: String              //Estatus de la póliza
)
/* Datos del servicio que consulta el detalle de un producto */
data class DetalleProductoItem (
    @SerializedName("IdPoliza") val idPoliza: String,               //ID unico de póliza
    @SerializedName("IdAsegurado") val idAsegurado: String,         //Codigo del asegurado
    @SerializedName("IdTipoSeg") val idTipoSeguro: String,          //Codigo del tipo de seguro asociado a la póliza
    @SerializedName("VigenciaIni") val vicenciaInicial: String,     //Fecha de inicio de vigencia de la póliza
    @SerializedName("VigenciaFin") val vigenciaFinal: String,       //Fecha de final de vigencia de la póliza
    @SerializedName("FecRenovacion") val fechaRenovacion: String,   //Fecha de renovación de la póliza
    @SerializedName("Status") val status: String,                   //Estatus de la póliza
    @SerializedName("DescSeg") val descripcionSeguro: String,       //Descripción del tipo de seguro
    @SerializedName("CodPlanPago") val codigoPlanPago: String,      //Forma de pago de la póliza
    @SerializedName("SumaAseg") val sumaAsegurada: String,          //Suma asegurada de la póliza
    @SerializedName("CodCobertura") val codigoCobertura: String     //Codigo de cobertura
)
/* Menus para mostrar en detalles de polizas */
data class DetalleMenuItem (
    @SerializedName("Titulo") val tituloMenu: String,               //Texto del titulo
    @SerializedName("Estatus") val estatusMenu: Int                 //Estatus si se debe mostrar
)
/* Detalles de coberturas de una poliza */
data class DetalleCoberturaItem (
    @SerializedName("codCobert") val codigoCobertura: String,       //Codigo de cobertura
    @SerializedName("sumAsegurada") val sumaAsegurada: String,      //Suma asegurada
    @SerializedName("descCobertura") val descripcionCobertura: String//Descripción de cobertura
)
/* Datos de los beneficiarios de una póliza */
data class DetalleBeneficiarioItem(
    @SerializedName("nombenef") val nombreBeneficiario: String,     //Nombre del beneficiario
    @SerializedName("porcentaje") val porcentajeBeneficiario: Int,  //Porcentaje asignado al beneficiario
    @SerializedName("parentesco") val parentescoBeneficiario: String//Parentesco del beneficiario
)
/* Datos de las facturas de una póliza */
data class FacturaItem(
    @SerializedName("IdFactura") val idFactura: Int,                //Numero de factura
    @SerializedName("StsFactura") val statusFactura: String,        //Estatus de la factura
    @SerializedName("FechaFact") val fechaFactura: String,          //Fecha de la factura
    @SerializedName("MontoFactura") val montoFactura: Double,       //Valor de la factura
    @SerializedName("IdRecibo") val idRecibo: String,               //Numero de recibo
    @SerializedName("CuotaFact") val cuotaFactura: String,          //Numero de cuota 1/12
    @SerializedName("IdTransaccion") val idTransaccion: Int,        //Numero de transacción en caso de estar pagada
    @SerializedName("vl_PlanPagoFact") val vlPlanPagoFact: String  //Plan de pagos
)
/* Datos del listado de parentescos */
data class ParentescoItem(
    @SerializedName("codValor") val codParentesco: String,          //Codigo asociado al parentesco
    @SerializedName("descValor") val parentesco: String             //Descripción del parentesco
)
/* Respuesta de obtención de caratula */
data class ObtenCaratulaItem(
    @SerializedName("respuesta") val numRespuesta: String,
    @SerializedName("url") val documento: String
)
/* Datos de latitud y longitud de ubicación */
data class Ubicacion(
    var lat: String,
    var lon: String
)
/* Datos de usuario y contraseña con los que se logro hacer login */
class Sesion(private val context: Context) {
    companion object {
        private val Context.dataUser: DataStore<Preferences> by preferencesDataStore("Usuario")
        private val USER_USER_KEY = stringPreferencesKey("user_user")
        private val Context.dataPass: DataStore<Preferences> by preferencesDataStore("Password")
        private val USER_PASS_KEY = stringPreferencesKey("user_pass")
    }
    val getAccessUser: Flow<String> = context.dataUser.data.map { preferences ->
        preferences[USER_USER_KEY] ?: ""
    }
    val getAccessPassword: Flow<String> = context.dataPass.data.map { preferences ->
        preferences[USER_PASS_KEY] ?: ""
    }
    suspend fun saveUser(usuario: String) {
        context.dataUser.edit { preferences ->
            preferences[USER_USER_KEY] = usuario
        }
    }
    suspend fun savePass(contrasenia: String) {
        context.dataPass.edit { preferences ->
            preferences[USER_PASS_KEY] = contrasenia
        }
    }
}
data class LoginToken(
    var rol: String,
    var usuario: String,
    var contra: String
)
data class AltaTarjetaOpenPay(
    val id: String,
    val card: TarjetaOpenPay,
    val control: Control
)
data class TarjetaOpenPay(
    val cardNumber: String,
    val nombre: String,
    val mes: String,
    val anio: String
)