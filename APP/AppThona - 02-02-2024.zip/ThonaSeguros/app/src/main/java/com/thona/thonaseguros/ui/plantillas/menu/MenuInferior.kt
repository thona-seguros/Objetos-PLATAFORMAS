package com.thona.thonaseguros.ui.plantillas.menu

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddReaction
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.Color
import androidx.navigation.NavController
import androidx.navigation.compose.currentBackStackEntryAsState

@Composable
fun BottomBarNav(
    color: Color,
    navController: NavController
) {
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val pantallaActual = navBackStackEntry?.destination?.route
    if (pantallaActual == null || pantallaActual == DatosPantalla.Login.name || pantallaActual == DatosPantalla.Registro.name || pantallaActual == DatosPantalla.PromocionAsegurado.name || pantallaActual == DatosPantalla.Asegurado.name || pantallaActual == DatosPantalla.Contratante.name || pantallaActual == DatosPantalla.Agente.name || pantallaActual == DatosPantalla.AgenteContratanteAseguradoAsignaToken.name ){
        return
    }
    BottomAppBar(
        containerColor = color
    ) {
        val pantallaProductos = pantallaActual == DatosPantalla.AseguradoPolizas.name
        val pantallaTramites = pantallaActual == DatosPantalla.AseguradoTramites.name
        val pantallaCuenta = pantallaActual == DatosPantalla.AseguradoCuenta.name
        NavigationBarItem(
            selected = pantallaProductos,
            onClick = {
                if(!pantallaProductos) {
                    navController.navigate(DatosPantalla.AseguradoPolizas.name) {
                        popUpTo(DatosPantalla.AseguradoPolizas.name) { inclusive = true }
                    }
                }
            },
            icon = {
                Icon(
                    imageVector = Icons.Default.AddReaction,
                    contentDescription = DatosPantalla.AseguradoPolizas.name,
                    tint = Color.White
                )
            },
            label = {
                Text(
                    text = "Mis Pólizas",
                    color = Color.White
                )
            }
        )
        NavigationBarItem(
            selected = pantallaTramites,
            onClick = {
                if(!pantallaTramites) {
                    navController.navigate(DatosPantalla.AseguradoTramites.name) {
                        popUpTo(DatosPantalla.AseguradoTramites.name) { inclusive = true }
                    }
                }
            },
            icon = {
                Icon(
                    imageVector = Icons.Default.Dashboard,
                    contentDescription = DatosPantalla.AseguradoTramites.name,
                    tint = Color.White
                )
            },
            label = {
                Text(
                    text = "Mis Trámites",
                    color = Color.White
                )
            }
        )
        NavigationBarItem(
            selected = pantallaCuenta,
            onClick = {
                if(!pantallaCuenta) {
                    navController.navigate(DatosPantalla.AseguradoCuenta.name) {
                        popUpTo(DatosPantalla.AseguradoCuenta.name) { inclusive = true }
                    }
                }
            },
            icon = {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = DatosPantalla.AseguradoCuenta.name,
                    tint = Color.White
                )
            },
            label = {
                Text(
                    text = "Mi Cuenta",
                    color = Color.White
                )
            }
        )
    }
}