package com.thona.thonaseguros.ui.theme

import androidx.compose.ui.graphics.Color

val Institucional1 = Color(0xFF06559B)
val Institucional2 = Color (0xFFCB3333)
val Institucional3 = Color (0xFF201747)

//COLORES PARA ESTATUS DE POLIZAS
val ThonaVerde = Color (124,185,87)
val ThonaRojo = Color (192,0,0)
val ThonaNaranja = Color(255, 87, 34, 255)

val PolizaANU = Color (192,0,0)
val PolizaREN = Color(255, 152, 0, 255)
val PolizaSUS = Color(255, 87, 34, 255)
val PolizaEMI = Color(139, 195, 74, 255)
val PolizaXRE = Color(103, 58, 183, 255)
val PolizaSOL = Color(205, 220, 57, 255)
val PolizaPLD = Color(33, 150, 243, 255)
val PolizaPRE = Color(255, 240, 104, 255)

val Institucional3light1 = Color(0xCC201747)
val Institucional3light2 = Color(0x80201747)