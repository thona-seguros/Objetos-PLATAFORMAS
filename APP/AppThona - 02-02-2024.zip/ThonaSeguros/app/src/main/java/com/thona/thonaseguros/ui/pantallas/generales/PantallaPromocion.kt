package com.thona.thonaseguros.ui.pantallas.generales

import android.widget.Toast
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.thona.thonaseguros.ui.plantillas.AlertaPopUp
import com.thona.thonaseguros.ui.theme.Institucional1

@Composable
fun PantallaPromocion(loadingProgressBar: Boolean){

    var modifier = Modifier.alpha(alpha = 1F)
    if(loadingProgressBar){
        modifier = modifier.alpha(alpha = 0.8F)
    }

    var apPat by remember { mutableStateOf(value = "") }
    var apMat by remember { mutableStateOf(value = "") }
    var nombre by remember { mutableStateOf(value = "") }
    var fechaNac by remember { mutableStateOf(value = "") }
    var mail by remember { mutableStateOf(value = "") }
    var tel by remember { mutableStateOf(value = "") }
    var check by remember { mutableStateOf(value = false) }
    var datosValidos by remember { mutableStateOf(value = false) }

    val scrollState = rememberScrollState()
    Column(
        modifier = modifier
            .verticalScroll(scrollState)
            .fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ){
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = "Para obtener un seguro de REGALO por favor captura los siguientes datos.")
        }
        Spacer(modifier = Modifier.height(10.dp))
        //DIA -> DD
        //MES -> MM
        //AÑO -> AAAA
        //OCUPACIÓN -> CATALOGO
        //NOMBRES
        //APELLIDO PATERNO
        //APELLIDO MATERNO
        //CORREO
        //CUESTIONARIO ***REVISAR SI TENDRA
        //GENERO -> F O M
        //CALLE DOMICILIO
        //NUMERO INTERIOR DOMICILIO
        //NUMERO EXTERIOR DOMICILIO
        //CODIGO POSTAL
        //CODIGO COLONIA -> SERVICIO DE ACUERDO AL CODIGO POSTAL
        //TELEFONO
        //REQUIERE FACTURA -> TRUE O FALSE
        //RFC
        //ACTIVIDAD ECONOMICA -> DEL CATALOGO
        //TIPO PERSONA -> F O M
        //REGIMEN FISCAR -> DEL CATALOGO EN CASO DE REQUERIR FACTURA
        //USO DE CFDI -> DEL CATALOGO EN CASO DE REQUERIR FACTURA
        //RAZON SOCUAL _> EN CASO DE REQUERIR FACTURA
        //CALLE FISCARL
        //NUMERO INTERIOR FISCAL
        //NUMERO EXTERIOR FISCAL
        //CODIGO POSTAL FISCAL
        //CODIGO COLONIA FISCAL
        //CODIGO ESTADO FISCAL
        //FORMA_COBRO -> DEL CATALOGO
        //NUMERO TARJETA -> EN CASO DE SELECCIONAR TARJETA
        //FECHA VIGENCIA TARJETA
        //CUENTA CLABE -> EN CASO DE SELECCIONAR CLABE
        //FRECUENCIA PAGO -> DEL CATALOGO PARA EL PRODUCTO
        //ENTIDAD FINANCIERA -> DEL CATALOGO
        //NUMERO CUENTA BANCARIA -> EN CASO DE QUE SEA POR CUENTA BANCARIA
        //NOMBRE DEL TITULAR DE TARJETA O CUENTA
        //MEDIO DE CONTACTO -> 1:SMS, 2: WHATSAPP
        //ACEPTAR TERMINOS Y CONDICIONES


        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = "Apellido paterno")
        }
        Row(verticalAlignment = Alignment.CenterVertically){
            OutlinedTextField(
                value = apPat,
                onValueChange = { apPat = it },
                singleLine = true,
                shape = CircleShape
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = "Apellido materno")
        }
        Row(verticalAlignment = Alignment.CenterVertically){
            OutlinedTextField(
                value = apMat,
                onValueChange = { apMat = it },
                singleLine = true,
                shape = CircleShape
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = "Nombre(s)")
        }
        Row(verticalAlignment = Alignment.CenterVertically){
            OutlinedTextField(
                value = nombre,
                onValueChange = { nombre = it },
                singleLine = true,
                shape = CircleShape
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = "Fecha de nacimiento")
        }
        Row(verticalAlignment = Alignment.CenterVertically){
            OutlinedTextField(
                value = fechaNac,
                onValueChange = { fechaNac = it },
                singleLine = true,
                shape = CircleShape
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = "E-mail")
        }
        Row(verticalAlignment = Alignment.CenterVertically){
            OutlinedTextField(
                value = mail,
                onValueChange = { mail = it },
                singleLine = true,
                shape = CircleShape
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = "Teléfono")
        }
        Row(verticalAlignment = Alignment.CenterVertically){
            OutlinedTextField(
                value = tel,
                onValueChange = { tel = it},
                singleLine = true,
                shape = CircleShape
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically){
            Checkbox(
                checked = check,
                onCheckedChange = { check=it },
            )
            Text(text = "Acepto terminos y condiciones")
        }
        datosValidos = apPat.isNotEmpty() && apMat.isNotEmpty() && nombre.isNotEmpty() && fechaNac.isNotEmpty() && mail.isNotEmpty() && tel.isNotEmpty() && check
        var clickEnvio by remember { mutableStateOf(value = false) }
        Row(verticalAlignment = Alignment.CenterVertically){
            Button(
                enabled = datosValidos,
                onClick = { clickEnvio = true },
                shape = CircleShape
            ) {
               Text(text = "Registrarme")
            }
        }
        val aux = LocalContext.current
        if(clickEnvio){
            AlertaPopUp(
                titulo = "Obtener promoción",
                mensaje = "Los datos que se enviaran para tu registro son: \nNombre: $nombre $apPat $apMat \nFecha de nacimiento: $fechaNac \nTeléfono: $tel \nMail: $mail \n¿Deseas enviar la información?",
                clicAceptar = { clickEnvio = false; Toast.makeText(aux,"Datos enviados",Toast.LENGTH_SHORT).show() },
                clicCancelar = { clickEnvio = false },
                colorRol = Institucional1,
                cantidadBotones = 2,
                texto1 = "Registrar",
                texto2 = "Cancelar"
            )
        }
    }
}