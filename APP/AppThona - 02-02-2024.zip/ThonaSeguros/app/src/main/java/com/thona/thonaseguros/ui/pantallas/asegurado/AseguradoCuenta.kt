package com.thona.thonaseguros.ui.pantallas.asegurado

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Cancel
import androidx.compose.material.icons.outlined.Save
import androidx.compose.material.icons.rounded.AccountCircle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.thona.thonaseguros.datos.modelos.InfoItem
import com.thona.thonaseguros.datos.modelos.Login
import com.thona.thonaseguros.datos.modelos.MyProducto
import com.thona.thonaseguros.ui.plantillas.textoEditable
import com.thona.thonaseguros.ui.theme.Institucional2
import com.thona.thonaseguros.ui.theme.Institucional3

@Composable
fun AseguradoCuenta(
    usuario: Login,
    infoUsuario: InfoItem,
    productos: MyProducto,
    clickActualizacion: (correo: String?, cCorrelativo: Int, telefono: String?, tCorrelativo: Int) -> Unit,
    clickCancelar: () -> Unit,
    loadingProgressBar: Boolean
){
    var modifier = Modifier.alpha(alpha = 1F)
    if(loadingProgressBar){
        modifier = modifier.alpha(alpha = 0.8F)
    }
    val mContext = LocalContext.current
    val scrollState = rememberScrollState()

    Box(
        modifier
            .fillMaxWidth()
            .background(color = Institucional3)
    ) {
        Row(
            modifier = modifier
                .padding(horizontal = 8.dp)
                .align(Alignment.CenterEnd),
            horizontalArrangement = Arrangement.Center
        ) {
            Text(
                text = "Última sesión: ${usuario.items.ultimaSesion}",
                color = Color.White,
                fontSize = 11.sp
            )
        }
    }

    Spacer(modifier = modifier.height(10.dp))
    Row(
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        //TODO PONER LA IMAGEN DEL USUARIO
        Column{
            Icon(
                imageVector = Icons.Rounded.AccountCircle,
                contentDescription = "",
                modifier = modifier.size(75.dp),
                tint = Institucional2
            )
        }
        Spacer(modifier = modifier.width(15.dp))
        Column{
            Row {
                Text(text = "${usuario.items.nomUsuario} ${usuario.items.apPatUsuario}", fontWeight = FontWeight.Bold, fontStyle = FontStyle.Italic)
            }
            Row {
                Text(text = "No. Asegurado: ", fontWeight = FontWeight.Bold)
                Text(text = "${productos.idAsegurado.codAsegurado}")
            }
            Row{
                Text(text = "Pólizas Activas: ", fontWeight = FontWeight.Bold)
                Text(text = "${infoUsuario.cantidadPolizas}")
            }
        }
    }
    Spacer(modifier = modifier.height(10.dp))
    Column (
        modifier = modifier
            .verticalScroll(scrollState)
            .fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ){
        var edicion1 by rememberSaveable { mutableStateOf("") }
        var edicion2 by rememberSaveable { mutableStateOf("") }
        var edicion = false
        Row(modifier = modifier
            .fillMaxWidth()
            .padding(start = 15.dp, end = 15.dp),horizontalArrangement = Arrangement.Center) {
            OutlinedTextField(
                modifier = modifier
                    .width(160.dp)
                    .height(60.dp),
                value = infoUsuario.fechaNacimiento,
                onValueChange = { },
                placeholder = { Text(text = "dd/mm/aaaa") },
                label = { Text(text = "Fecha de nacimiento") },
                readOnly = true,
                singleLine = true,
                shape = CircleShape,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Institucional2
                )
            )
            textoEditable(
                modifier = modifier
                    .width(200.dp)
                    .height(60.dp),
                dato = infoUsuario.sexoUsuario,
                etiqueta = "Genero de nacimiento",
                placeholder = "H/M",
                puedeEditar = false,
                tipoTeclado = KeyboardType.Text
            )
        }
        Row(modifier = modifier.fillMaxWidth(),horizontalArrangement = Arrangement.Start) {
            textoEditable(
                modifier = modifier
                    .fillMaxWidth()
                    .padding(start = 15.dp, end = 15.dp)
                    .height(60.dp),
                dato = infoUsuario.rfcUsuario,
                etiqueta = "RFC",
                placeholder = "",
                puedeEditar = false,
                tipoTeclado = KeyboardType.Text
            )
        }
        Row(modifier = modifier.fillMaxWidth(),horizontalArrangement = Arrangement.Start) {
            textoEditable(
                modifier = modifier
                    .fillMaxWidth()
                    .padding(start = 15.dp, end = 15.dp)
                    .height(60.dp),
                dato = infoUsuario.curpUsuario,
                etiqueta = "CURP",
                placeholder = "",
                puedeEditar = false,
                tipoTeclado = KeyboardType.Text
            )
        }
        Row(modifier = modifier.fillMaxWidth(),horizontalArrangement = Arrangement.Start) {
            textoEditable(
                modifier = modifier
                    .fillMaxWidth()
                    .padding(start = 15.dp, end = 15.dp),
                dato = infoUsuario.direccionUsuario,
                etiqueta = "Dirección",
                placeholder = "Dirección completa",
                puedeEditar = false,
                tipoTeclado = KeyboardType.Text
            )
        }
        Row(modifier = modifier.fillMaxWidth(),horizontalArrangement = Arrangement.Start) {
            edicion1 = textoEditable(
                modifier = modifier
                    .fillMaxWidth()
                    .padding(start = 15.dp, end = 15.dp)
                    .height(60.dp),
                dato = infoUsuario.emailUsuario.first().email,
                etiqueta = "Email*",
                placeholder = "correo@thonaseguros.mx",
                puedeEditar = true,
                tipoTeclado = KeyboardType.Email
            )
        }
        Row(modifier = modifier.fillMaxWidth(),horizontalArrangement = Arrangement.Start, verticalAlignment = Alignment.CenterVertically){
            edicion2 = textoEditable(
                modifier = modifier
                    .fillMaxWidth()
                    .padding(start = 15.dp, end = 15.dp)
                    .height(60.dp)
                ,
                dato = "${infoUsuario.celUsuario.first().tel}",
                etiqueta = "Número de teléfono*",
                placeholder = "5588774455",
                puedeEditar = true,
                tipoTeclado = KeyboardType.Phone
            )
        }
        Spacer(modifier = modifier.height(4.dp))
        if(edicion1 != "" && edicion2 != ""){
            if(edicion1 != infoUsuario.emailUsuario.first().email || edicion2 != infoUsuario.celUsuario.first().tel.toString()){
                edicion = true
            }
        }
        val envio1: String?; val correlativo1: Int
        val envio2: String?; val correlativo2: Int
        if(edicion){
            if(edicion1 == infoUsuario.emailUsuario.first().email){
                envio1 = null
                correlativo1 = 0
            }else{
                envio1 = edicion1
                correlativo1 = infoUsuario.emailUsuario.first().correlativo
            }
            if(edicion2 == infoUsuario.celUsuario.first().tel.toString()){
                envio2 = null
                correlativo2 = 0
            }else{
                envio2 = edicion2
                correlativo2 = infoUsuario.celUsuario.first().correlativo
            }
            Row(verticalAlignment = Alignment.CenterVertically){
                Button(
                    onClick = {
                        Toast.makeText(
                            mContext,
                            "Actualización cancelada",
                            Toast.LENGTH_SHORT
                        ).show(); clickCancelar()
                    },
                    shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Institucional3
                    ),
                    enabled = true
                ) {
                    Text(
                        text = "Cancelar",
                        color = Color.White
                    )
                    Spacer(modifier.size(ButtonDefaults.IconSpacing))
                    Icon(
                        imageVector = Icons.Outlined.Cancel,
                        contentDescription = "Cancelar",
                        tint = Color.White
                    )
                }
                Spacer(modifier = modifier.width(20.dp))
                Button(
                    onClick = {
                        Toast.makeText(
                            mContext,
                            "Actualización en curso",
                            Toast.LENGTH_SHORT
                        ).show(); clickActualizacion(envio1, correlativo1, envio2, correlativo2)
                    },
                    shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Institucional3
                    ),
                    enabled = true
                ) {
                    Text(
                        text = "Guardar",
                        color = Color.White
                    )
                    Spacer(modifier.size(ButtonDefaults.IconSpacing))
                    Icon(
                        imageVector = Icons.Outlined.Save,
                        contentDescription = "Guardar",
                        tint = Color.White
                    )
                }
                Spacer(modifier = modifier.height(10.dp))
            }
        }
    }
}