package com.thona.thonaseguros.ui.theme

val existePromocion = true

/* DATOS CONEXIÓN OPENPAY */
val merchantId = "modqqphqkw5mvjb22znk"
val apiKey = "sk_68dd96edd4f94a6eb5a36a6df22674cb"
val esProduccion = false
