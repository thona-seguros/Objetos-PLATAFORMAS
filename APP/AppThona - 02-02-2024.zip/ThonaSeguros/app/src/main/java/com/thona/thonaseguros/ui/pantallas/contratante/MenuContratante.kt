package com.thona.thonaseguros.ui.pantallas.contratante

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import com.thona.thonaseguros.datos.modelos.Login

@Composable
fun MenuContratante(
    usuario: Login
){
    Text(text = "Texto: ${usuario.control.textoRespuesta}, codigo: ${usuario.control.numeroRespuesta}")
    Text(text = "Datos: ${usuario.items.rol}")
}