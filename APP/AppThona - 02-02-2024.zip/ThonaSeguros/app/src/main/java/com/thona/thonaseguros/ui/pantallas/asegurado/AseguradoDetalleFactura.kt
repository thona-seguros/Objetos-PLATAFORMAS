package com.thona.thonaseguros.ui.pantallas.asegurado

import android.app.Activity
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.thona.thonaseguros.datos.openPay.open
import com.thona.thonaseguros.datos.openPay.tokenTarjeta
import com.thona.thonaseguros.funciones.Funciones
import com.thona.thonaseguros.ui.plantillas.AlertaPopUp
import com.thona.thonaseguros.ui.theme.Institucional3

@Composable
fun AseguradoDetalleFactura(
    loadingProgressBar: Boolean,
    funciones: Funciones
){
    val scrollState = rememberScrollState()

    var modifier = Modifier.alpha(alpha = 1F)
    if(loadingProgressBar){
        modifier = modifier.alpha(alpha = 0.8F)
    }

    val actividad = LocalContext.current as Activity
    if(funciones.iDAntiFraude.value == ""){
        funciones.iDAntiFraude.value = open(actividad)
    }

    Column(modifier = modifier
        .fillMaxSize()
        .padding(all = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
        ) {
        var documento by rememberSaveable { mutableStateOf(value = false) }
        var aplica by rememberSaveable { mutableStateOf(value = false) }
        var tarjeta by rememberSaveable { mutableStateOf(value = false) }

        Spacer(modifier = modifier.height(5.dp))
        if(funciones.facturaSeleccionada.value.statusFactura != "PAGADA"){
            if(!documento && !aplica && !tarjeta){
                Text(
                    text = "La factura ${funciones.facturaSeleccionada.value.idFactura} esta pendiente de pago"
                )
                Spacer(modifier = modifier.height(20.dp))
                Text(text = "El pago por $${funciones.facturaSeleccionada.value.montoFactura} correspondiente a la cuota número ${funciones.facturaSeleccionada.value.cuotaFactura} tiene fecha limite de pago el ${funciones.facturaSeleccionada.value.fechaFactura}")
                Spacer(modifier = modifier.height(20.dp))
                Text(text = "¿Desea aplicar cobranza? o ¿Generar documento para pago?")
            }else{
                Text(text = "La factura ${funciones.facturaSeleccionada.value.idFactura} por $${funciones.facturaSeleccionada.value.montoFactura} corresponde a la cuota ${funciones.facturaSeleccionada.value.cuotaFactura} de la póliza ${funciones.detallesDePoliza.value.detalleProducto.idPoliza}")
            }
        }else{
            Text(text = "La factura ${funciones.facturaSeleccionada.value.idFactura} esta ${funciones.facturaSeleccionada.value.statusFactura}")
        }
        Spacer(modifier = modifier.height(15.dp))
        if(!aplica && !documento && !tarjeta){
            Column (horizontalAlignment = Alignment.CenterHorizontally){
                Button(
                    enabled = funciones.facturaSeleccionada.value.statusFactura != "PAGADA",
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Institucional3
                    ),
                    onClick = { documento = false; tarjeta = false; aplica = true }
                ) {
                    Text(text = "Aplicar pago")
                }
                Spacer(modifier = modifier.width(5.dp))
                Button(
                    enabled = funciones.facturaSeleccionada.value.statusFactura != "PAGADA",
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Institucional3
                    ),
                    onClick = { aplica = false; documento = false; tarjeta = true }
                ) {
                    Text(text = "Pagar con tarjeta")
                }
                Spacer(modifier = modifier.width(5.dp))
                Button(
                    enabled = funciones.facturaSeleccionada.value.statusFactura != "PAGADA",
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Institucional3
                    ),
                    onClick = { tarjeta = false; aplica=false; documento = true }
                ) {
                    Text(text = "Generar documento")
                }
            }
        }

        var poliza by rememberSaveable{ mutableStateOf(value = funciones.detallesDePoliza.value.detalleProducto.idPoliza) }
        var factura by rememberSaveable{ mutableIntStateOf(value = funciones.facturaSeleccionada.value.idFactura) }
        var monto by rememberSaveable{ mutableDoubleStateOf(value = funciones.facturaSeleccionada.value.montoFactura) }
        var refOpenPay by rememberSaveable{ mutableStateOf(value = "") }
        var aprobacion by rememberSaveable{ mutableStateOf(value = "") }

        var noTarjeta by remember { mutableStateOf(value = "") }
        var nombreTarjeta by remember { mutableStateOf(value = "") }
        var mes by remember { mutableStateOf(value = "") }
        var anio by remember { mutableStateOf(value = "") }
        var cvv by remember { mutableStateOf(value = "") }

        if(aplica){
            Column(
                modifier = modifier
                    .verticalScroll(scrollState)
                    .fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(horizontalArrangement = Arrangement.Center){
                    Button(
                        enabled = funciones.facturaSeleccionada.value.statusFactura != "PAGADA",
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Institucional3
                        ),
                        onClick = { aplica = false; documento = false; tarjeta = true }
                    ) {
                        Text(text = "Pagar con tarjeta")
                    }
                    Spacer(modifier = modifier.width(5.dp))
                    Button(
                        enabled = funciones.facturaSeleccionada.value.statusFactura != "PAGADA",
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Institucional3
                        ),
                        onClick = { tarjeta = false; aplica=false; documento = true }
                    ) {
                        Text(text = "Generar documento")
                    }
                }
                Spacer(modifier = modifier.height(10.dp))
                Row (horizontalArrangement = Arrangement.Center){
                    Text(text = "Por favor, llena los siguientes campos para aplicar el pago de tu póliza")
                }
                Spacer(modifier = modifier.height(5.dp))
                Row(horizontalArrangement = Arrangement.Center, modifier = modifier.fillMaxWidth()){
                    OutlinedTextField(
                        value = poliza,
                        onValueChange = { poliza = it },
                        label = { Text(text = "Poliza") },
                        singleLine = true,
                        readOnly = true,
                        shape = CircleShape
                    )
                }
                Row(horizontalArrangement = Arrangement.Center, modifier = modifier.fillMaxWidth()){
                    OutlinedTextField(
                        value = factura.toString(),
                        onValueChange = { factura = it.toInt() },
                        label = { Text(text = "Factura") },
                        singleLine = true,
                        readOnly = true,
                        shape = CircleShape
                    )
                }
                Row(horizontalArrangement = Arrangement.Center, modifier = modifier.fillMaxWidth()){
                    OutlinedTextField(
                        value = monto.toString(),
                        onValueChange = { monto = it.toDouble() },
                        label = { Text(text = "Monto") },
                        singleLine = true,
                        readOnly = true,
                        shape = CircleShape
                    )
                }
                Row(horizontalArrangement = Arrangement.Center, modifier = modifier.fillMaxWidth()){
                    OutlinedTextField(
                        value = refOpenPay,
                        onValueChange = { refOpenPay = it },
                        label = { Text(text = "numero de referencia") },
                        singleLine = true,
                        readOnly = false,
                        shape = CircleShape
                    )
                }
                Row(horizontalArrangement = Arrangement.Center, modifier = modifier.fillMaxWidth()){
                    OutlinedTextField(
                        value = aprobacion,
                        onValueChange = { aprobacion = it },
                        label = { Text(text = "Numero de aprobación") },
                        singleLine = true,
                        readOnly = false,
                        shape = CircleShape
                    )
                }
                Spacer(modifier = modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.Center, modifier = modifier.fillMaxWidth()){
                    Button(
                        onClick = {
                            funciones.aplicaPago(
                                poliza = poliza.substringBefore("-").toInt(),
                                factura = factura,
                                monto = monto,
                                referencia = refOpenPay,
                                aprobacion = aprobacion.toInt()
                            )
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Institucional3
                        ),
                        enabled = funciones.facturaSeleccionada.value.statusFactura != "PAGADA"
                    ) {
                        Text(text = "Aplicar pago")
                    }
                }
            }
        }
        if(tarjeta){
            Column(
                modifier = modifier
                    .verticalScroll(scrollState)
                    .padding(all = 10.dp)
                    .fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally
            ){
                Row(horizontalArrangement = Arrangement.Center){
                    Button(
                        enabled = funciones.facturaSeleccionada.value.statusFactura != "PAGADA",
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Institucional3
                        ),
                        onClick = { documento = false; tarjeta = false; aplica = true }
                    ) {
                        Text(text = "Aplicar pago")
                    }
                    Spacer(modifier = modifier.width(5.dp))
                    Button(
                        enabled = funciones.facturaSeleccionada.value.statusFactura != "PAGADA",
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Institucional3
                        ),
                        onClick = { tarjeta = false; aplica=false; documento = true }
                    ) {
                        Text(text = "Generar documento")
                    }
                }
                Spacer(modifier = modifier.height(10.dp))
                Row (horizontalArrangement = Arrangement.Center){
                    Text(text = "Por favor, ingresa los datos de tu tarjeta bancaria para realizar el pago.")
                }
                Spacer(modifier = modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.Center, modifier = modifier.fillMaxWidth()){
                    OutlinedTextField(
                        value = nombreTarjeta,
                        onValueChange = { nombreTarjeta = it },
                        label = { Text(text = "Nombre del Titular de la tarjeta") },
                        singleLine = true,
                        readOnly = false,
                        shape = CircleShape
                    )
                }
                Spacer(modifier = modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.Center, modifier = modifier.fillMaxWidth()){
                    OutlinedTextField(
                        value = noTarjeta,
                        onValueChange = { if(it.length<=16)noTarjeta = it },
                        label = { Text(text = "Numero de tarjeta") },
                        singleLine = true,
                        readOnly = false,
                        shape = CircleShape
                    )
                }
                Spacer(modifier = modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.Center, modifier = modifier.fillMaxWidth()){
                    OutlinedTextField(
                        value = mes,
                        modifier = modifier.width(150.dp),
                        onValueChange = { if(it.length<=2)mes = it },
                        label = { Text(text = "Mes") },
                        singleLine = true,
                        readOnly = false,
                        shape = CircleShape
                    )
                    OutlinedTextField(
                        value = anio,
                        modifier = modifier.width(150.dp),
                        onValueChange = { if(it.length<=2)anio = it },
                        label = { Text(text = "Año") },
                        singleLine = true,
                        readOnly = false,
                        shape = CircleShape
                    )
                }
                Spacer(modifier = modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.Center, modifier = modifier.fillMaxWidth()){
                    OutlinedTextField(
                        value = cvv,
                        modifier = modifier.width(150.dp),
                        onValueChange = { if(it.length<=3)cvv = it },
                        label = { Text(text = "CVV") },
                        singleLine = true,
                        readOnly = false,
                        shape = CircleShape
                    )
                }
                Spacer(modifier = modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.Center, modifier = modifier.fillMaxWidth()){
                    Button(
                        onClick = {
                            if(funciones.tokenPago.value == ""){
                                tokenTarjeta(funciones = funciones, nombre = nombreTarjeta, tarjeta = noTarjeta,mes = mes.toInt(), anio = anio.toInt(), cvv = cvv)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Institucional3
                        ),
                        enabled = funciones.facturaSeleccionada.value.statusFactura != "PAGADA"
                    ) {
                        Text(text = "Pagar")
                    }
                }
            }
        }
        if(documento){
            Column(
                modifier = modifier
                    .verticalScroll(scrollState)
                    .padding(all = 10.dp)
                    .fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(horizontalArrangement = Arrangement.Center){
                    Button(
                        enabled = funciones.facturaSeleccionada.value.statusFactura != "PAGADA",
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Institucional3
                        ),
                        onClick = { documento = false; tarjeta = false; aplica = true }
                    ) {
                        Text(text = "Aplicar pago")
                    }
                    Spacer(modifier = modifier.width(5.dp))
                    Button(
                        enabled = funciones.facturaSeleccionada.value.statusFactura != "PAGADA",
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Institucional3
                        ),
                        onClick = { aplica = false; documento = false; tarjeta = true }
                    ) {
                        Text(text = "Pagar con tarjeta")
                    }
                }
                Spacer(modifier = modifier.height(10.dp))
                Row (horizontalArrangement = Arrangement.Center){
                    Text(text = "¿Deseas generar un documento para referencia en tienda de conveniencia o en ventanilla bancaria?")
                }
                Spacer(modifier = modifier.height(20.dp))
                Row (horizontalArrangement = Arrangement.Center){
                    Button(
                        onClick = { funciones.creaReferencia(tipo = 2, poliza = poliza.substringBefore("-").toInt(), factura = factura, dispositivo = null, token = null) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Institucional3
                        )
                    ) {
                        Text(text = "Ventanilla Bancaria")
                    }
                }
                Spacer(modifier = modifier.height(10.dp))
                Row (horizontalArrangement = Arrangement.Center){
                    Button(
                        onClick = { funciones.creaReferencia(tipo = 1,poliza = poliza.substringBefore("-").toInt(), factura = factura, dispositivo = null, token = null) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Institucional3
                        )
                    ) {
                        Text(text = "Tienda de conveniencia")
                    }
                }
            }
        }
        val mContext = LocalContext.current
        val mensaje = (if(funciones.mensajeRespuesta.value.contains("openpay.mx/")){
            "El documento esta listo para descargar\n\n ¿Deseas descargarlo?"
        } else { "Aviso de pago en linea.\n\n${funciones.mensajeRespuesta.value}" }).toString()
        if(funciones.muestraMensaje.value){
            AlertaPopUp(
                titulo = "AVISO",
                mensaje = mensaje,
                clicAceptar = {
                    funciones.muestraMensaje.value = false
                    if(funciones.mensajeRespuesta.value.contains("openpay.mx/")){
                        funciones.descargaDocumento(link = funciones.mensajeRespuesta.value, title = "Referencia para pago", descripcion = "Thona Seguros APP", context = mContext)
                    }
                    funciones.consultaProductos(funciones.respuestaLogin.value.items.codUsuario,funciones.respuestaLogin.value.session.idSession)
                },
                clicCancelar = { funciones.muestraMensaje.value = false },
                colorRol = Institucional3,
                cantidadBotones = 2,
                texto1 = "Aceptar",
                texto2 = "Cancelar"
            )
        }
        if(funciones.tokenPago.value != ""){
            println("TOKEN DE TARJETA ${funciones.tokenPago.value}")
            println("Dispositivo : ${funciones.iDAntiFraude.value}")
            AlertaPopUp(
                titulo = "Pago de póliza",
                mensaje = "Al dar click, aceptas los terminos y condiciones y el uso de tus datos bancarios.",
                clicAceptar = {
                    funciones.creaReferencia(tipo = 3, poliza = poliza.substringBefore("-").toInt(), factura = factura, dispositivo = funciones.iDAntiFraude.value, token = funciones.tokenPago.value)
                },
                clicCancelar = { funciones.tokenPago.value = "" },
                colorRol = Institucional3,
                cantidadBotones = 2,
                texto1 = "Aceptar",
                texto2 = "Cancelar"
            )
        }
    }
}