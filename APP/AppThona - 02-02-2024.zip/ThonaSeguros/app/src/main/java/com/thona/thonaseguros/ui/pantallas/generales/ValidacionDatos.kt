package com.thona.thonaseguros.ui.pantallas.generales

import java.util.regex.Pattern

fun validaTelefono(datoTelefono: String): Boolean{
    var valido = false
    if(datoTelefono.length == 10 && !datoTelefono.startsWith("0")){
        valido = true
    }
    return valido
}

fun validaMail(datoMail: String) =
    Pattern.compile(
        "^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$",
        Pattern.CASE_INSENSITIVE
    ).matcher(datoMail).find()

fun validaContrasenia(texto: String): Boolean{
    var valido = false
    if(texto.length>=4){
        valido = true
    }
    return valido
}