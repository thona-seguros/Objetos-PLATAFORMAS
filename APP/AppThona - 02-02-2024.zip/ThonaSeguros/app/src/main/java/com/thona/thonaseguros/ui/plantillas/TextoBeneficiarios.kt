package com.thona.thonaseguros.ui.plantillas

import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import com.thona.thonaseguros.ui.theme.Institucional1

@Composable
fun textoBeneficiarios(modifier: Modifier, dato: String, etiqueta: String, placeholder: String, editable: Boolean, tipoTeclado: KeyboardType): String{
    var texto by rememberSaveable { mutableStateOf(value = dato) }
    OutlinedTextField(
        value = texto,
        onValueChange = { texto = it },
        modifier = modifier,
        label = { Text(text = etiqueta) },
        placeholder = { Text(text = placeholder) },
        textStyle = if(etiqueta == "Porcentaje") TextStyle(textAlign = TextAlign.End)
        else TextStyle(),
        enabled = editable,
        readOnly = !editable,
        keyboardOptions = KeyboardOptions(
            keyboardType = tipoTeclado
        ),
        shape = CircleShape,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Institucional1
        ),
        singleLine = true,
        suffix = {
            if(etiqueta == "Porcentaje")
                Text(text = "%")
        },
    )
    return texto.ifEmpty {
        dato
    }
}

fun cambio(nuevo: String, anterior: String): Boolean{
    var distinto = false
    if(nuevo != anterior){
        distinto = true
    }
    return distinto
}