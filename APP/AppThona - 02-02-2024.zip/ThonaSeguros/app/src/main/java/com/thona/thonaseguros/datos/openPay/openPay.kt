package com.thona.thonaseguros.datos.openPay
/*
import android.app.Activity
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.thona.thonaseguros.datos.modelos.AltaTarjetaOpenPay
import com.thona.thonaseguros.datos.modelos.Control
import com.thona.thonaseguros.datos.modelos.TarjetaOpenPay
import com.thona.thonaseguros.funciones.Funciones
import com.thona.thonaseguros.ui.theme.apiKey
import com.thona.thonaseguros.ui.theme.esProduccion
import com.thona.thonaseguros.ui.theme.merchantId
import mx.openpay.android.Openpay
import mx.openpay.android.OperationCallBack
import mx.openpay.android.OperationResult
import mx.openpay.android.exceptions.OpenpayServiceException
import mx.openpay.android.exceptions.ServiceUnavailableException
import mx.openpay.android.model.Card
import mx.openpay.android.model.Token

fun open(pantalla: Activity): String {
    val openpay = Openpay(merchantId, apiKey, esProduccion)
    return openpay.deviceCollectorDefaultImpl.setup(pantalla)
}

fun tokenTarjeta(funciones: Funciones, nombre: String, tarjeta: String, mes: Number, anio: Number, cvv: String) {
    var tarjetaToken by mutableStateOf(value = AltaTarjetaOpenPay("",
        TarjetaOpenPay("","","",""), Control("98","No se obtuvo respuesta")
    )
    )
    val openpay = Openpay(merchantId, apiKey, esProduccion)
    val card = Card()
    card.holderName(nombre)
    card.cardNumber(tarjeta)
    card.expirationMonth(mes as Int?)
    card.expirationYear(anio as Int?)
    card.cvv2(cvv)
    openpay.createToken(card, object: OperationCallBack<Token> {
        override fun onSuccess(operationResult: OperationResult<Token>?) {
            if (operationResult != null) {
                tarjetaToken = AltaTarjetaOpenPay(
                    id = operationResult.result.id,
                    card = TarjetaOpenPay(
                        cardNumber = operationResult.result.card.cardNumber,
                        nombre = operationResult.result.card.holderName,
                        mes = operationResult.result.card.expirationMonth,
                        anio = operationResult.result.card.expirationYear
                    ),
                    control = Control(
                        numeroRespuesta = "1",
                        textoRespuesta = "La tarjeta de ${operationResult.result.card.type} se creo con el id ${operationResult.result.card.id}"
                    )
                )
            }
            if (operationResult != null) {
                funciones.tokenPago.value = operationResult.result.id.toString()
            }
        }
        override fun onError(arg0: OpenpayServiceException) {
            //Handle Error
            /*TODO AGREGAR QUE SE HARA EN CASO DE NO SER EXITOSO EL ALTA DE LA TARJETA*/
        }
        override fun onCommunicationError(arg0: ServiceUnavailableException) {
            //Handle communication error
            /*TODO AGREGAR ACCION EN CASO DE HABER ERROR DE COMUNICACIÓN*/
        }
    })
}*/